# WayBook — GST Billing & Accounting Software

A full-featured GST billing, invoicing, and accounting desktop application built with **Electron + Next.js + Express + SQLite**.

---

## Project Architecture

```
waybook/
├── electron/           # Electron main process
│   ├── main.js         # App entry point — starts backend, creates window
│   └── preload.js      # Context bridge for renderer ↔ main IPC
├── frontend/           # Next.js (React) frontend
│   └── src/
│       ├── app/        # Next.js App Router pages
│       └── components/
│           └── WayBook.tsx   # Main application component (~3000 lines)
├── backend/            # Express + SQLite backend API
│   └── src/
│       ├── server.ts         # Express server entry
│       ├── lib/
│       │   ├── db.ts         # SQLite init + schema migrations
│       │   ├── gst.ts        # GSTR-1 / GSTR-3B computation engine
│       │   ├── ledger.ts     # Ledger/accounting logic
│       │   ├── moduleSettings.ts  # Feature toggles + module visibility
│       │   └── validators.ts # GSTIN / mobile validators
│       └── routes/           # Express route handlers (18 modules)
├── assets/             # App icons (icon.ico, icon.png, tray-icon.png)
├── package.json        # Root: Electron + electron-builder config
├── README.md           # This file
└── install.sh          # Quick install script (Linux/Mac)
```

---

## Prerequisites

- **Node.js** v18+ (v20 or v22 recommended)
- **npm** v9+
- **Windows** for packaging (or Linux with patches — see Packaging section)
- **Python 3** + build tools for `better-sqlite3` native compilation
  - Windows: `npm install -g windows-build-tools` or Visual Studio Build Tools
  - Linux/Mac: `python3`, `make`, `g++`

---

## 1. Install Dependencies

```bash
# Install all dependencies (root + backend + frontend)
npm run install:all

# Or manually:
npm install
cd backend && npm install && cd ..
cd frontend && npm install && cd ..
```

---

## 2. Run in Development Mode

```bash
# Starts backend (port 4100) + frontend dev server (port 3000) + Electron window
npm run dev

# Or start each separately:
npm run dev:backend    # Express API at http://localhost:4100
npm run dev:frontend   # Next.js at http://localhost:3000
npm run dev:electron   # Electron (waits for frontend to be ready)
```

**Dev URLs:**
- Frontend (browser): http://localhost:3000
- Backend API: http://localhost:4100
- API Health: http://localhost:4100/ → `{"status":"running"}`

---

## 3. Production Build

```bash
# Build backend (TypeScript → dist/) AND frontend (Next.js → out/)
npm run build

# Or individually:
npm run build:backend    # Compiles backend/src/*.ts → backend/dist/
npm run build:frontend   # Exports frontend/src → frontend/out/ (static HTML)
```

---

## 4. Create Windows EXE — NSIS Installer

> **Recommended:** Run this on a Windows machine for best results.
> On Linux, apply the patches described in the "Building on Linux" section below.

```bash
# Build everything then package as Windows installer
npm run build
npm run package:win
```

Output: `dist-electron/WayBook Setup 1.0.0.exe`  
This is a full NSIS installer with:
- Install/uninstall wizard
- Custom install directory selection
- Desktop + Start Menu shortcuts
- Auto-start of the backend on launch

---

## 5. Create Portable EXE (no install required)

```bash
# Edit package.json — change the win.target to "portable", then:
npm run build
npx electron-builder --win --x64
```

Output: `dist-electron/WayBook 1.0.0.exe`  
Single self-contained EXE — users double-click and run. No installation needed.

To switch target, in `package.json` under `build.win.target`, change:
```json
[{ "target": "nsis", "arch": ["x64"] }]
```
to:
```json
[{ "target": "portable", "arch": ["x64"] }]
```

---

## 6. MSI Installer

MSI support can be added via electron-builder's `msi` target:

```json
"win": {
  "target": [
    { "target": "nsis", "arch": ["x64"] },
    { "target": "msi",  "arch": ["x64"] }
  ]
}
```

Then run:
```bash
npm run package:win
```

> Note: MSI target also requires Wine on Linux. Run on Windows for best results.

---

## Building on Linux (Cross-compile to Windows)

The following patches were applied to enable NSIS builds on Linux without Wine.
**These patches must be re-applied after every `npm install` in the root.**

### Patch 1 — `node_modules/app-builder-lib/out/wine.js`

Make `execWine` a no-op on Linux (skip code signing):

```js
// Add this branch BEFORE the existing wine call:
if (process.platform === "linux") {
    return Promise.resolve("");
}
```

### Patch 2 — `node_modules/app-builder-lib/out/targets/nsis/NsisTarget.js`

Use `UninstallerReader` (pure-JS PE parser) instead of Wine for uninstaller extraction:

```js
// Replace:
else {
    await (0, wine_1.execWine)(installerPath, ...);
}
// With:
else if (process.platform === "linux") {
    try {
        await nsisUtil_1.UninstallerReader.exec(installerPath, uninstallerPath);
    } catch (error) {
        builder_util_1.log.warn("UninstallerReader failed: " + error.message);
    }
}
else {
    await (0, wine_1.execWine)(installerPath, ...);
}
```

### better-sqlite3 Windows binary (cross-compile)

When building on Linux, replace the Linux `.node` binary with the Windows prebuilt:

```bash
# Download Windows binary for better-sqlite3 v9.6.0, Electron 28 (ABI 116)
curl -L -o /tmp/bsql-win.tar.gz \
  "https://github.com/WiseLibs/better-sqlite3/releases/download/v9.6.0/better-sqlite3-v9.6.0-electron-v116-win32-x64.tar.gz"
tar -xzf /tmp/bsql-win.tar.gz -C /tmp/bsql-win

# Replace Linux binary with Windows binary:
cp /tmp/bsql-win/build/Release/better_sqlite3.node \
   backend/node_modules/better-sqlite3/build/Release/better_sqlite3.node
```

**On Windows:** `npm install` inside `backend/` will automatically compile the correct native binary. No manual steps needed.

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `4100` | Backend API port |
| `DB_PATH` | `./data` (dev) / `userData/data` (prod) | SQLite database directory |
| `NODE_ENV` | `development` | Set to `production` for packaged app |
| `NEXT_PUBLIC_API_URL` | `http://localhost:4100/api` | Frontend API base URL |

In production (packaged Electron app), these are set automatically by `electron/main.js`.

---

## Key Technologies

| Layer | Technology | Version |
|---|---|---|
| Desktop wrapper | Electron | 28.x |
| Frontend | Next.js + React | 14.x / 18.x |
| Styling | Tailwind CSS | 3.x |
| Backend | Express.js | 4.x |
| Database | SQLite (better-sqlite3) | 9.x |
| Language | TypeScript | 5.x |
| Packaging | electron-builder | 24.x |
| Icons | lucide-react | 0.323 |
| Charts | recharts | 2.x |

---

## Features Included

- **Sales:** Invoice, Order, Return, Quotation, Delivery Challan, Payment In
- **Purchase:** Bill, Order, Return, Payment Out
- **GST:** GSTR-1 (B2B/B2C/HSN summary), GSTR-3B, Excel export
- **Reports:** P&L, Stock Summary, Outstanding, Day Book
- **HR:** Employees, Attendance, Payroll
- **Banking:** Bank accounts, reconciliation
- **Inventory:** Items, Units, Godowns/Warehouses
- **Parties:** Customers & Suppliers with GSTIN
- **Settings → Module Management:** Enable/disable any module from sidebar
- **Settings → Feature Toggles:** Multi-series, units, item/bill discounts per module
- **Settings → Multiple Series:** Custom invoice numbering series

---

## Database

- SQLite file stored at:
  - **Dev:** `backend/data/waybook.db`
  - **Prod (installed):** `%APPDATA%\WayBook\data\waybook.db` (Windows)
- Schema is auto-created and migrated on first run via `db.ts`
- No manual migration steps needed

---

## Giving This Project Back for Changes

To request code changes and rebuild the EXE:

1. Hand back this ZIP to your developer/AI
2. Specify exactly what to change
3. Run `npm run build && npm run package:win` after changes
4. New `dist-electron/WayBook Setup 1.0.0.exe` will be generated

The entire application UI is in **`frontend/src/components/WayBook.tsx`**.  
All backend API logic is in **`backend/src/routes/`** and **`backend/src/lib/`**.

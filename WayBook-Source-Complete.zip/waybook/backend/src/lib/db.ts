import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';

const DB_DIR = process.env.DB_PATH || path.join(process.cwd(), 'data');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const DB_PATH = path.join(DB_DIR, 'waybook.db');
console.log('[DB] Database at:', DB_PATH);

export const db = new Database(DB_PATH);
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

export function initializeDatabase() {
  db.exec(`
    -- Firms
    CREATE TABLE IF NOT EXISTS firms (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      legalName TEXT,
      phone TEXT,
      email TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      country TEXT DEFAULT 'India',
      gstin TEXT,
      pan TEXT,
      tan TEXT,
      logoUrl TEXT,
      currency TEXT DEFAULT 'INR',
      financialYear TEXT DEFAULT '2024-25',
      invoicePrefix TEXT DEFAULT 'INV',
      invoiceNumber INTEGER DEFAULT 1,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    );

    -- Categories
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT CHECK(type IN ('item', 'party', 'expense')) DEFAULT 'item',
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Units
    CREATE TABLE IF NOT EXISTS units (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      shortName TEXT NOT NULL,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Items (Products & Services)
    CREATE TABLE IF NOT EXISTS items (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT CHECK(type IN ('PRODUCT', 'SERVICE')) NOT NULL DEFAULT 'PRODUCT',
      hsnCode TEXT,
      itemCode TEXT,
      description TEXT,
      imageUrl TEXT,
      categoryId TEXT,
      unitId TEXT,
      secondaryUnitId TEXT,
      conversionFactor REAL NOT NULL DEFAULT 1,
      salePrice REAL NOT NULL DEFAULT 0,
      salePriceTaxInclusive INTEGER DEFAULT 0,
      saleDiscount REAL DEFAULT 0,
      saleDiscountType TEXT CHECK(saleDiscountType IN ('percentage', 'amount')) DEFAULT 'percentage',
      purchasePrice REAL DEFAULT 0,
      purchasePriceTaxInclusive INTEGER DEFAULT 0,
      taxRate TEXT DEFAULT '0',
      openingStock REAL DEFAULT 0,
      currentStock REAL DEFAULT 0,
      minStockLevel REAL DEFAULT 0,
      location TEXT,
      batchNumber TEXT,
      expiryDate TEXT,
      enableBatchTracking INTEGER DEFAULT 0,
      enableSerialTracking INTEGER DEFAULT 0,
      isActive INTEGER DEFAULT 1,
      isFavorite INTEGER DEFAULT 0,
      allowNegativeStock INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (categoryId) REFERENCES categories(id)
    );

    -- Groups (Party groups)
    CREATE TABLE IF NOT EXISTS groups (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Parties (Customers & Suppliers)
    CREATE TABLE IF NOT EXISTS parties (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT CHECK(type IN ('customer', 'supplier', 'both')) DEFAULT 'customer',
      phone TEXT,
      email TEXT,
      gstin TEXT,
      pan TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      groupId TEXT,
      creditLimit REAL DEFAULT 0,
      openingBalance REAL DEFAULT 0,
      openingBalanceType TEXT CHECK(type IN ('debit', 'credit')) DEFAULT 'debit',
      loyaltyPoints INTEGER DEFAULT 0,
      isActive INTEGER DEFAULT 1,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (groupId) REFERENCES groups(id)
    );

    -- Documents (Sales, Purchases, Expenses)
    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      documentType TEXT NOT NULL CHECK(documentType IN (
        'sale_invoice', 'sale_order', 'sale_return', 'sale_quotation', 'delivery_challan',
        'purchase_invoice', 'purchase_order', 'purchase_return', 'expense', 'other_income'
      )),
      documentNumber TEXT NOT NULL,
      documentDate TEXT NOT NULL,
      documentTime TEXT,
      partyId TEXT,
      partyName TEXT NOT NULL,
      partyType TEXT CHECK(partyType IN ('customer', 'supplier')) NOT NULL,
      phone TEXT,
      billingAddress TEXT,
      shippingAddress TEXT,
      transactionType TEXT CHECK(transactionType IN ('credit', 'cash')) DEFAULT 'cash',
      status TEXT DEFAULT 'draft',
      stateOfSupply TEXT,
      subtotal REAL DEFAULT 0,
      discountAmount REAL DEFAULT 0,
      discountPercentage REAL DEFAULT 0,
      taxAmount REAL DEFAULT 0,
      shippingCharges REAL DEFAULT 0,
      packagingCharges REAL DEFAULT 0,
      adjustment REAL DEFAULT 0,
      roundOff REAL DEFAULT 0,
      total REAL NOT NULL DEFAULT 0,
      paidAmount REAL DEFAULT 0,
      balanceAmount REAL DEFAULT 0,
      paymentType TEXT DEFAULT 'cash',
      bankId TEXT,
      poNumber TEXT,
      poDate TEXT,
      description TEXT,
      ewaybillNo TEXT,
      vehicleNumber TEXT,
      transportName TEXT,
      deliveryDate TEXT,
      isDeleted INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (partyId) REFERENCES parties(id)
    );

    -- Document Items
    CREATE TABLE IF NOT EXISTS document_items (
      id TEXT PRIMARY KEY,
      documentId TEXT NOT NULL,
      firmId TEXT NOT NULL,
      itemId TEXT,
      name TEXT NOT NULL,
      description TEXT,
      hsnCode TEXT,
      quantity REAL NOT NULL DEFAULT 1,
      unit TEXT,
      unitId TEXT,
      isSecondaryUnit INTEGER DEFAULT 0,
      baseQuantity REAL NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      discount REAL DEFAULT 0,
      discountType TEXT DEFAULT 'percentage',
      taxRate REAL DEFAULT 0,
      taxAmount REAL DEFAULT 0,
      amount REAL NOT NULL DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (documentId) REFERENCES documents(id) ON DELETE CASCADE,
      FOREIGN KEY (itemId) REFERENCES items(id)
    );

    -- Payments
    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      type TEXT CHECK(type IN ('payment_in', 'payment_out')) NOT NULL,
      partyId TEXT,
      partyName TEXT NOT NULL,
      amount REAL NOT NULL,
      paymentMethod TEXT DEFAULT 'cash',
      bankId TEXT,
      receiptNumber TEXT,
      paymentDate TEXT NOT NULL,
      reference TEXT,
      description TEXT,
      linkedDocumentId TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (partyId) REFERENCES parties(id)
    );

    -- Bank Accounts
    CREATE TABLE IF NOT EXISTS bank_accounts (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      accountName TEXT NOT NULL,
      bankName TEXT NOT NULL,
      accountNumber TEXT,
      ifscCode TEXT,
      branchName TEXT,
      openingBalance REAL DEFAULT 0,
      currentBalance REAL DEFAULT 0,
      upiId TEXT,
      isActive INTEGER DEFAULT 1,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Expenses
    CREATE TABLE IF NOT EXISTS expenses (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      categoryId TEXT,
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      paymentMethod TEXT DEFAULT 'cash',
      bankId TEXT,
      description TEXT,
      partyId TEXT,
      partyName TEXT,
      receiptUrl TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Godowns (Warehouses)
    CREATE TABLE IF NOT EXISTS godowns (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      address TEXT,
      isDefault INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Inventory Stock
    CREATE TABLE IF NOT EXISTS inventory_stock (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      itemId TEXT NOT NULL,
      godownId TEXT,
      quantity REAL DEFAULT 0,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (itemId) REFERENCES items(id) ON DELETE CASCADE
    );

    -- Employees (HR)
    CREATE TABLE IF NOT EXISTS employees (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      employeeCode TEXT,
      firstName TEXT NOT NULL,
      lastName TEXT,
      phone TEXT,
      email TEXT,
      department TEXT,
      designation TEXT,
      joiningDate TEXT,
      salary REAL DEFAULT 0,
      salaryType TEXT DEFAULT 'monthly',
      bankAccountName TEXT,
      bankAccountNumber TEXT,
      ifscCode TEXT,
      panNumber TEXT,
      aadharNumber TEXT,
      address TEXT,
      status TEXT DEFAULT 'active',
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Attendance
    CREATE TABLE IF NOT EXISTS attendance (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      employeeId TEXT NOT NULL,
      date TEXT NOT NULL,
      status TEXT CHECK(status IN ('present', 'absent', 'half_day', 'holiday', 'leave')) DEFAULT 'present',
      checkIn TEXT,
      checkOut TEXT,
      notes TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (employeeId) REFERENCES employees(id) ON DELETE CASCADE
    );

    -- Payroll Runs
    CREATE TABLE IF NOT EXISTS payroll_runs (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      month TEXT NOT NULL,
      year TEXT NOT NULL,
      status TEXT DEFAULT 'draft',
      totalAmount REAL DEFAULT 0,
      paidAt TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Payroll Items
    CREATE TABLE IF NOT EXISTS payroll_items (
      id TEXT PRIMARY KEY,
      payrollRunId TEXT NOT NULL,
      employeeId TEXT NOT NULL,
      employeeName TEXT NOT NULL,
      basicSalary REAL DEFAULT 0,
      totalDays INTEGER DEFAULT 0,
      presentDays REAL DEFAULT 0,
      earnedSalary REAL DEFAULT 0,
      allowances REAL DEFAULT 0,
      deductions REAL DEFAULT 0,
      netSalary REAL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (payrollRunId) REFERENCES payroll_runs(id) ON DELETE CASCADE,
      FOREIGN KEY (employeeId) REFERENCES employees(id)
    );

    -- Projects
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT,
      partyId TEXT,
      partyName TEXT,
      startDate TEXT,
      endDate TEXT,
      status TEXT DEFAULT 'active',
      budget REAL DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Commission Agents
    CREATE TABLE IF NOT EXISTS agents (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      commissionRate REAL DEFAULT 0,
      commissionType TEXT DEFAULT 'percentage',
      isActive INTEGER DEFAULT 1,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Reminders
    CREATE TABLE IF NOT EXISTS reminders (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      partyId TEXT,
      partyName TEXT,
      amount REAL,
      phone TEXT,
      message TEXT,
      scheduledDate TEXT,
      isCompleted INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Firm Settings
    CREATE TABLE IF NOT EXISTS firm_settings (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      settingType TEXT NOT NULL,
      settingKey TEXT,
      settingValue TEXT,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Number Series (Multiple Series feature)
    CREATE TABLE IF NOT EXISTS series (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      name TEXT NOT NULL,
      prefix TEXT NOT NULL,
      transactionType TEXT NOT NULL CHECK(transactionType IN (
        'sale_invoice', 'sale_order', 'sale_return', 'sale_quotation', 'delivery_challan',
        'purchase_invoice', 'purchase_order', 'purchase_return', 'expense'
      )),
      startingNumber INTEGER NOT NULL DEFAULT 1,
      currentNumber INTEGER NOT NULL DEFAULT 1,
      numberLength INTEGER NOT NULL DEFAULT 4,
      financialYear TEXT,
      includeFinancialYearInNumber INTEGER DEFAULT 0,
      resetYearly INTEGER DEFAULT 0,
      isActive INTEGER DEFAULT 1,
      isDefault INTEGER DEFAULT 0,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Payment Allocations (bill-wise linking of a Payment In/Out against one or more documents)
    CREATE TABLE IF NOT EXISTS payment_allocations (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      paymentId TEXT NOT NULL,
      documentId TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      createdAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE,
      FOREIGN KEY (paymentId) REFERENCES payments(id) ON DELETE CASCADE,
      FOREIGN KEY (documentId) REFERENCES documents(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_alloc_payment ON payment_allocations(paymentId);
    CREATE INDEX IF NOT EXISTS idx_alloc_document ON payment_allocations(documentId);

    -- Cheques
    CREATE TABLE IF NOT EXISTS cheques (
      id TEXT PRIMARY KEY,
      firmId TEXT NOT NULL,
      paymentId TEXT,
      chequeNumber TEXT NOT NULL,
      bankName TEXT,
      amount REAL NOT NULL,
      date TEXT NOT NULL,
      partyName TEXT,
      status TEXT DEFAULT 'pending',
      depositedAt TEXT,
      createdAt TEXT NOT NULL,
      updatedAt TEXT NOT NULL,
      FOREIGN KEY (firmId) REFERENCES firms(id) ON DELETE CASCADE
    );

    -- Indexes
    CREATE INDEX IF NOT EXISTS idx_items_firmId ON items(firmId);
    CREATE INDEX IF NOT EXISTS idx_parties_firmId ON parties(firmId);
    CREATE INDEX IF NOT EXISTS idx_documents_firmId ON documents(firmId);
    CREATE INDEX IF NOT EXISTS idx_documents_type ON documents(firmId, documentType);
    CREATE INDEX IF NOT EXISTS idx_document_items_doc ON document_items(documentId);
    CREATE INDEX IF NOT EXISTS idx_payments_firmId ON payments(firmId);
    CREATE INDEX IF NOT EXISTS idx_employees_firmId ON employees(firmId);
    CREATE INDEX IF NOT EXISTS idx_attendance_emp ON attendance(firmId, employeeId, date);
    CREATE INDEX IF NOT EXISTS idx_series_firmId ON series(firmId);
    CREATE INDEX IF NOT EXISTS idx_series_type ON series(firmId, transactionType);
  `);
  // Note: intentionally NOT adding a hard UNIQUE constraint on (firmId, documentNumber) here —
  // older installs upgrading from pre-series versions may already have edge-case duplicates from
  // manual document numbers, and a migration that fails to apply would block the whole upgrade.
  // Duplicate prevention for series-generated numbers is instead enforced at generation time
  // via a synchronous DB transaction (see routes/series.routes.ts -> generateSeriesNumber).

  // In-place migration: add seriesId to documents if upgrading from a pre-series database.
  // CREATE TABLE IF NOT EXISTS above only applies to brand-new databases, so existing
  // installs need this explicit ALTER TABLE to gain the new column without any data loss.
  try {
    const documentCols = (db.prepare("PRAGMA table_info(documents)").all() as any[]).map(c => c.name);
    if (!documentCols.includes('seriesId')) {
      db.exec('ALTER TABLE documents ADD COLUMN seriesId TEXT');
      console.log('[DB] Migrated: added documents.seriesId');
    }
  } catch (e) {
    console.warn('[DB] documents.seriesId migration skipped:', (e as any).message);
  }

  // In-place migration: Two Units + Conversion feature.
  // items gains secondaryUnitId (Unit 2) + conversionFactor (how many Unit 1 = 1 Unit 2).
  // document_items gains unitId (which unit was picked on that line), isSecondaryUnit flag,
  // and baseQuantity (quantity converted into Unit 1 terms — this is what stock math uses).
  // All additive, nullable/defaulted — existing rows and installs are unaffected.
  try {
    const itemCols = (db.prepare("PRAGMA table_info(items)").all() as any[]).map(c => c.name);
    if (!itemCols.includes('secondaryUnitId')) {
      db.exec('ALTER TABLE items ADD COLUMN secondaryUnitId TEXT');
      console.log('[DB] Migrated: added items.secondaryUnitId');
    }
    if (!itemCols.includes('conversionFactor')) {
      db.exec('ALTER TABLE items ADD COLUMN conversionFactor REAL NOT NULL DEFAULT 1');
      console.log('[DB] Migrated: added items.conversionFactor');
    }
  } catch (e) {
    console.warn('[DB] items unit-conversion migration skipped:', (e as any).message);
  }
  try {
    const diCols = (db.prepare("PRAGMA table_info(document_items)").all() as any[]).map(c => c.name);
    if (!diCols.includes('unitId')) {
      db.exec('ALTER TABLE document_items ADD COLUMN unitId TEXT');
      console.log('[DB] Migrated: added document_items.unitId');
    }
    if (!diCols.includes('isSecondaryUnit')) {
      db.exec('ALTER TABLE document_items ADD COLUMN isSecondaryUnit INTEGER DEFAULT 0');
      console.log('[DB] Migrated: added document_items.isSecondaryUnit');
    }
    if (!diCols.includes('baseQuantity')) {
      db.exec('ALTER TABLE document_items ADD COLUMN baseQuantity REAL NOT NULL DEFAULT 0');
      console.log('[DB] Migrated: added document_items.baseQuantity');
      // Backfill: for pre-existing rows, baseQuantity was never tracked separately —
      // the old behavior always treated `quantity` as base-unit quantity (no Unit 2
      // existed yet), so backfilling baseQuantity = quantity is exactly correct and
      // keeps historical stock math identical to what already happened.
      db.exec('UPDATE document_items SET baseQuantity = quantity WHERE baseQuantity = 0');
    }
  } catch (e) {
    console.warn('[DB] document_items unit-conversion migration skipped:', (e as any).message);
  }

  // In-place migration: Cash in Hand per firm (mirrors bank_accounts.currentBalance but for cash).
  try {
    const firmCols = (db.prepare("PRAGMA table_info(firms)").all() as any[]).map(c => c.name);
    if (!firmCols.includes('cashInHand')) {
      db.exec('ALTER TABLE firms ADD COLUMN cashInHand REAL NOT NULL DEFAULT 0');
      console.log('[DB] Migrated: added firms.cashInHand');
    }
  } catch (e) {
    console.warn('[DB] firms.cashInHand migration skipped:', (e as any).message);
  }

  console.log('[DB] Tables initialized successfully');
}

// Seed default data for a new firm
export function seedDefaultData(firmId: string) {
  const now = new Date().toISOString();
  
  // Default units
  const units = [
    { id: `${firmId}-unit-1`, name: 'Pieces', shortName: 'PCS' },
    { id: `${firmId}-unit-2`, name: 'Kilograms', shortName: 'KG' },
    { id: `${firmId}-unit-3`, name: 'Meters', shortName: 'MTR' },
    { id: `${firmId}-unit-4`, name: 'Liters', shortName: 'LTR' },
    { id: `${firmId}-unit-5`, name: 'Box', shortName: 'BOX' },
    { id: `${firmId}-unit-6`, name: 'Dozen', shortName: 'DZ' },
  ];

  const insertUnit = db.prepare('INSERT OR IGNORE INTO units (id, firmId, name, shortName, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)');
  for (const unit of units) {
    insertUnit.run(unit.id, firmId, unit.name, unit.shortName, now, now);
  }

  // Default categories
  const categories = [
    { id: `${firmId}-cat-1`, name: 'General', type: 'item' },
    { id: `${firmId}-cat-2`, name: 'Electronics', type: 'item' },
    { id: `${firmId}-cat-3`, name: 'Food & Beverages', type: 'item' },
    { id: `${firmId}-cat-4`, name: 'Customer', type: 'party' },
    { id: `${firmId}-cat-5`, name: 'Supplier', type: 'party' },
  ];

  const insertCat = db.prepare('INSERT OR IGNORE INTO categories (id, firmId, name, type, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)');
  for (const cat of categories) {
    insertCat.run(cat.id, firmId, cat.name, cat.type, now, now);
  }
}

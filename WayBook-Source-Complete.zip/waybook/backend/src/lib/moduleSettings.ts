import { db } from './db';
import { v4 as uuidv4 } from 'uuid';

/**
 * Module Settings (per firm, per module)
 * Reuses the existing generic `firm_settings` table (settingType/settingKey/settingValue).
 *
 * Two categories of settings:
 *
 * A) FEATURE TOGGLES (settingType = moduleKey, e.g. 'sale_invoice')
 *    Controls per-billing-module behaviour:
 *    - multiSeriesEnabled   – independent numbering series
 *    - unitsEnabled         – Unit 2 / Unit Conversion on line items
 *    - itemDiscountEnabled  – item-wise discount column on billing lines
 *    - billDiscountEnabled  – bill-level discount on billing totals
 *
 * B) VISIBILITY TOGGLES (settingType = 'module_visibility')
 *    Controls which entire sections are shown in the sidebar/nav:
 *    - items, godowns, sale_invoice, sale_order, sale_return, sale_quotation,
 *      delivery_challan, payment_in, purchase_invoice, purchase_order,
 *      purchase_return, payment_out, expenses, accounting_entries, bank,
 *      employees, attendance, payroll, report_pl, report_stock,
 *      report_outstanding, report_daybook, report_gst, parties, ledger
 *
 * All default to ENABLED (true) on upgrade so nothing is silently disabled.
 */

// ── A. Feature-toggle types ──────────────────────────────────────────────────

export const DOCUMENT_MODULES = [
  'sale_invoice', 'sale_order', 'sale_return', 'sale_quotation', 'delivery_challan',
  'purchase_invoice', 'purchase_order', 'purchase_return',
] as const;

export type ModuleKey = typeof DOCUMENT_MODULES[number] | 'items';

export interface ModuleSettings {
  multiSeriesEnabled: boolean;
  unitsEnabled: boolean;
  itemDiscountEnabled: boolean;
  billDiscountEnabled: boolean;
}

const FEATURE_DEFAULTS: ModuleSettings = {
  multiSeriesEnabled: true,
  unitsEnabled: true,
  itemDiscountEnabled: true,
  billDiscountEnabled: true,
};

export function getModuleSettings(firmId: string, moduleKey: string): ModuleSettings {
  const rows = db.prepare(
    'SELECT settingKey, settingValue FROM firm_settings WHERE firmId = ? AND settingType = ?'
  ).all(firmId, moduleKey) as any[];

  const out: ModuleSettings = { ...FEATURE_DEFAULTS };
  for (const r of rows) {
    if (r.settingKey === 'multiSeriesEnabled')  out.multiSeriesEnabled  = r.settingValue === 'true';
    if (r.settingKey === 'unitsEnabled')         out.unitsEnabled         = r.settingValue === 'true';
    if (r.settingKey === 'itemDiscountEnabled')  out.itemDiscountEnabled  = r.settingValue === 'true';
    if (r.settingKey === 'billDiscountEnabled')  out.billDiscountEnabled  = r.settingValue === 'true';
  }
  return out;
}

export function getAllModuleSettings(firmId: string): Record<string, ModuleSettings> {
  const modules: string[] = [...DOCUMENT_MODULES, 'items'];
  const out: Record<string, ModuleSettings> = {};
  for (const m of modules) out[m] = getModuleSettings(firmId, m);
  return out;
}

// ── B. Visibility-toggle types ───────────────────────────────────────────────

/**
 * Every nav item that can be independently shown/hidden.
 * Groups (sales_group, purchase_group, hr_group, etc.) are derived in the
 * frontend from their children — they cannot be toggled independently here;
 * toggle individual children instead.
 */
export const VISIBILITY_MODULES = [
  // Items & Stock
  'items',
  'godowns',
  // Sales
  'sale_invoice',
  'sale_order',
  'sale_return',
  'sale_quotation',
  'delivery_challan',
  'payment_in',
  // Purchase
  'purchase_invoice',
  'purchase_order',
  'purchase_return',
  'payment_out',
  // Other transactional
  'expenses',
  'accounting_entries',
  'bank',
  // HR
  'employees',
  'attendance',
  'payroll',
  // Reports
  'report_pl',
  'report_stock',
  'report_outstanding',
  'report_daybook',
  'report_gst',
  // Other
  'parties',
  'ledger',
] as const;

export type VisibilityKey = typeof VISIBILITY_MODULES[number];

export type VisibilityMap = Record<VisibilityKey, boolean>;

const VISIBILITY_TYPE = 'module_visibility';

export function getVisibilitySettings(firmId: string): VisibilityMap {
  const rows = db.prepare(
    'SELECT settingKey, settingValue FROM firm_settings WHERE firmId = ? AND settingType = ?'
  ).all(firmId, VISIBILITY_TYPE) as any[];

  // Default: all visible
  const out = Object.fromEntries(VISIBILITY_MODULES.map(k => [k, true])) as VisibilityMap;
  for (const r of rows) {
    if (r.settingKey in out) {
      (out as any)[r.settingKey] = r.settingValue === 'true';
    }
  }
  return out;
}

export function setVisibility(firmId: string, moduleKey: string, visible: boolean): void {
  const now = new Date().toISOString();
  const existing = db.prepare(
    'SELECT id FROM firm_settings WHERE firmId = ? AND settingType = ? AND settingKey = ?'
  ).get(firmId, VISIBILITY_TYPE, moduleKey);

  if (existing) {
    db.prepare(
      'UPDATE firm_settings SET settingValue = ?, updatedAt = ? WHERE firmId = ? AND settingType = ? AND settingKey = ?'
    ).run(String(visible), now, firmId, VISIBILITY_TYPE, moduleKey);
  } else {
    db.prepare(
      'INSERT INTO firm_settings (id, firmId, settingType, settingKey, settingValue, updatedAt) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(uuidv4(), firmId, VISIBILITY_TYPE, moduleKey, String(visible), now);
  }
}

export function setVisibilityBulk(firmId: string, updates: Partial<VisibilityMap>): void {
  const txn = db.transaction(() => {
    for (const [key, val] of Object.entries(updates)) {
      setVisibility(firmId, key, !!val);
    }
  });
  txn();
}

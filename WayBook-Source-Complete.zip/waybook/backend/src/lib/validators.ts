// Shared validation helpers — GSTIN and Indian mobile numbers.
// Used by both parties.routes.ts and firms.routes.ts so validation can never
// be bypassed by hitting the API directly (frontend validation alone is not enough).

// Standard 15-character GSTIN pattern:
// 2 digits state code, 10-char PAN, 1 entity code digit, 'Z' by default, 1 checksum alphanumeric.
const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;

export interface ValidationResult {
  valid: boolean;
  value?: string;
  error?: string;
}

/**
 * Validates + normalizes a GSTIN: trims whitespace, uppercases, then checks
 * exact 15-char length and the standard alphanumeric GSTIN format.
 * Returns { valid: true, value } with the normalized value, or { valid: false, error }.
 * Empty/undefined GSTIN is treated as valid (GSTIN is optional on most forms) —
 * callers that require it should check presence separately.
 */
export function validateGSTIN(raw: unknown): ValidationResult {
  if (raw === undefined || raw === null || String(raw).trim() === '') {
    return { valid: true, value: '' };
  }
  const value = String(raw).trim().toUpperCase();
  if (value.length !== 15) {
    return { valid: false, error: `GSTIN must be exactly 15 characters (got ${value.length})` };
  }
  if (!GSTIN_REGEX.test(value)) {
    return { valid: false, error: 'GSTIN format is invalid. Expected format: 22AAAAA0000A1Z5' };
  }
  return { valid: true, value };
}

/**
 * Validates + normalizes an Indian mobile number.
 * Accepts either exactly 10 digits ("9876543210") or +91 followed by exactly
 * 10 digits ("+919876543210"). Strips spaces/hyphens before checking.
 * Stored/returned normalized form is always "+91XXXXXXXXXX" for consistency,
 * except when the input was empty (optional field on most forms).
 */
export function validateMobile(raw: unknown): ValidationResult {
  if (raw === undefined || raw === null || String(raw).trim() === '') {
    return { valid: true, value: '' };
  }
  // Strip common separators (spaces, hyphens, parens) before checking digits.
  const cleaned = String(raw).trim().replace(/[\s\-()]/g, '');

  let digits: string;
  if (cleaned.startsWith('+91')) {
    digits = cleaned.slice(3);
  } else if (cleaned.startsWith('91') && cleaned.length === 12) {
    // Allow "919876543210" without the plus, normalize the same way.
    digits = cleaned.slice(2);
  } else {
    digits = cleaned;
  }

  if (!/^[0-9]{10}$/.test(digits)) {
    return { valid: false, error: 'Mobile number must be exactly 10 digits, optionally prefixed with +91' };
  }
  // Indian mobile numbers start with 6, 7, 8, or 9.
  if (!/^[6-9]/.test(digits)) {
    return { valid: false, error: 'Mobile number must start with 6, 7, 8, or 9' };
  }

  return { valid: true, value: `+91${digits}` };
}

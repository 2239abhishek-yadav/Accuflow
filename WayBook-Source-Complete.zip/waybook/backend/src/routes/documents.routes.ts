import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
import { generateSeriesNumber } from './series.routes';
import { getModuleSettings } from '../lib/moduleSettings';
import { recalcDocumentStatus, applyFunds } from '../lib/ledger';

const router = Router();

/**
 * Two Units + Conversion
 * -----------------------
 * A document line may be sold/purchased in an item's base unit (Unit 1) or its
 * secondary/larger unit (Unit 2) — e.g. sell in Strips while stock is tracked in
 * Tablets. This resolves whichever unit was picked on the line into a base-unit
 * quantity, which is what all stock math (items.currentStock) is keyed on — so
 * stock stays accurate regardless of which unit a given sale/purchase used.
 *
 * Respects the module's `unitsEnabled` setting: when a module has Units &
 * Conversion disabled, every line is treated as base-unit quantity (legacy
 * behavior), even if a secondary unit was somehow supplied.
 */
function resolveLineUnit(firmId: string, documentType: string, item: any, line: any) {
  const quantity = parseFloat(line.quantity) || 0;
  const unitsEnabled = getModuleSettings(firmId, documentType).unitsEnabled;

  if (!unitsEnabled || !item || !item.secondaryUnitId || !line.unitId || line.unitId === item.unitId) {
    return { baseQuantity: quantity, isSecondaryUnit: 0, unitId: item?.unitId || line.unitId || null };
  }
  if (line.unitId === item.secondaryUnitId) {
    const factor = parseFloat(item.conversionFactor) || 1;
    return { baseQuantity: +(quantity * factor).toFixed(4), isSecondaryUnit: 1, unitId: item.secondaryUnitId };
  }
  // Unrecognized unitId for this item — fall back to treating quantity as base-unit.
  return { baseQuantity: quantity, isSecondaryUnit: 0, unitId: item?.unitId || null };
}

// GET paginated documents
router.get('/', (req: Request, res: Response) => {
  try {
    const { firmId, documentType, partyId, search, startDate, endDate, status, page = '1', limit = '50' } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    let query = 'SELECT * FROM documents WHERE firmId = ? AND isDeleted = 0';
    const params: any[] = [firmId];

    if (documentType) { query += ' AND documentType = ?'; params.push(documentType); }
    if (partyId) { query += ' AND partyId = ?'; params.push(partyId); }
    if (status) { query += ' AND status = ?'; params.push(status); }
    if (startDate) { query += ' AND documentDate >= ?'; params.push(startDate); }
    if (endDate) { query += ' AND documentDate <= ?'; params.push(endDate); }
    if (search) { query += ' AND (documentNumber LIKE ? OR partyName LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

    // Count
    const countResult = db.prepare(`SELECT COUNT(*) as total FROM documents WHERE firmId = ? AND isDeleted = 0${
      documentType ? ' AND documentType = ?' : ''
    }`).get(documentType ? [firmId, documentType] : [firmId]) as any;

    query += ' ORDER BY documentDate DESC, createdAt DESC LIMIT ? OFFSET ?';
    params.push(Number(limit), (Number(page) - 1) * Number(limit));

    const documents = db.prepare(query).all(params);
    res.json({ success: true, data: documents, total: countResult?.total || 0 });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET document by id with items
router.get('/:id', (req: Request, res: Response) => {
  try {
    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Document not found' });
    const items = db.prepare('SELECT * FROM document_items WHERE documentId = ?').all(req.params.id);
    res.json({ success: true, data: { ...doc as any, items } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST create document (invoice, order, etc)
router.post('/', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    const {
      firmId, documentType, documentNumber, seriesId, documentDate, documentTime,
      partyId, partyName, partyType, phone, billingAddress, shippingAddress,
      transactionType = 'cash', status = 'active', stateOfSupply,
      subtotal = 0, discountAmount = 0, discountPercentage = 0,
      taxAmount = 0, shippingCharges = 0, packagingCharges = 0,
      adjustment = 0, roundOff = 0, total = 0, paidAmount = 0, balanceAmount = 0,
      paymentType = 'cash', bankId, poNumber, poDate, description,
      ewaybillNo, vehicleNumber, transportName, deliveryDate,
      items = []
    } = req.body;

    if (!firmId || !documentType || !partyName) {
      return res.status(400).json({ error: 'firmId, documentType, partyName are required' });
    }

    // Auto-generate document number if not explicitly provided.
    // Priority: explicit seriesId (Multiple Series feature) > firm's default active series
    // for this documentType > legacy per-firm single counter (backward compatible — untouched
    // for firms that never set up series, so existing numbering/reports/prints keep working).
    const multiSeriesEnabled = getModuleSettings(firmId, documentType).multiSeriesEnabled;

    let docNumber = documentNumber;
    let usedSeriesId: string | null = null;
    if (!docNumber) {
      let resolvedSeriesId = multiSeriesEnabled ? seriesId : null;
      if (!resolvedSeriesId && multiSeriesEnabled) {
        const defaultSeries = db.prepare(
          'SELECT id FROM series WHERE firmId = ? AND transactionType = ? AND isActive = 1 AND isDefault = 1'
        ).get(firmId, documentType) as any;
        if (defaultSeries) resolvedSeriesId = defaultSeries.id;
      }

      if (resolvedSeriesId) {
        const generated = generateSeriesNumber(resolvedSeriesId);
        docNumber = generated.documentNumber;
        usedSeriesId = generated.seriesId;
      } else {
        // Legacy fallback — unchanged from the original single-counter behavior.
        const firm = db.prepare('SELECT * FROM firms WHERE id = ?').get(firmId) as any;
        const prefix = firm?.invoicePrefix || 'INV';
        const num = firm?.invoiceNumber || 1;
        docNumber = `${prefix}-${String(num).padStart(4, '0')}`;
        db.prepare('UPDATE firms SET invoiceNumber = invoiceNumber + 1 WHERE id = ?').run(firmId);
      }
    } else if (seriesId && multiSeriesEnabled) {
      // A manual number was given but a series was still selected (e.g. edit flow) — keep the link.
      usedSeriesId = seriesId;
    }

    // Insert document
    db.prepare(`
      INSERT INTO documents (
        id, firmId, documentType, documentNumber, seriesId, documentDate, documentTime,
        partyId, partyName, partyType, phone, billingAddress, shippingAddress,
        transactionType, status, stateOfSupply,
        subtotal, discountAmount, discountPercentage, taxAmount,
        shippingCharges, packagingCharges, adjustment, roundOff,
        total, paidAmount, balanceAmount, paymentType, bankId,
        poNumber, poDate, description, ewaybillNo, vehicleNumber,
        transportName, deliveryDate, createdAt, updatedAt
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id, firmId, documentType, docNumber, usedSeriesId, documentDate, documentTime,
      partyId, partyName, partyType, phone, billingAddress, shippingAddress,
      transactionType, status, stateOfSupply,
      subtotal, discountAmount, discountPercentage, taxAmount,
      shippingCharges, packagingCharges, adjustment, roundOff,
      total, paidAmount, balanceAmount, paymentType, bankId,
      poNumber, poDate, description, ewaybillNo, vehicleNumber,
      transportName, deliveryDate, now, now
    );

    // Insert items
    if (items.length > 0) {
      const insertItem = db.prepare(`
        INSERT INTO document_items (id, documentId, firmId, itemId, name, description, hsnCode,
          quantity, unit, unitId, isSecondaryUnit, baseQuantity, price, discount, discountType,
          taxRate, taxAmount, amount, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const item of items) {
        const dbItem = item.itemId ? db.prepare('SELECT unitId, secondaryUnitId, conversionFactor FROM items WHERE id = ?').get(item.itemId) as any : null;
        const { baseQuantity, isSecondaryUnit, unitId: resolvedUnitId } = resolveLineUnit(firmId, documentType, dbItem, item);

        insertItem.run(
          uuidv4(), id, firmId, item.itemId, item.name, item.description, item.hsnCode,
          item.quantity || 1, item.unit, resolvedUnitId, isSecondaryUnit, baseQuantity,
          item.price || 0, item.discount || 0,
          item.discountType || 'percentage', item.taxRate || 0, item.taxAmount || 0,
          item.amount || 0, now, now
        );

        // Update stock for products — always in base-unit (Unit 1) terms, regardless
        // of which unit the line was sold/purchased in.
        if (item.itemId) {
          const isSale = ['sale_invoice', 'sale_order', 'delivery_challan'].includes(documentType);
          const isPurchase = ['purchase_invoice', 'purchase_order'].includes(documentType);
          const isSaleReturn = documentType === 'sale_return';
          const isPurchaseReturn = documentType === 'purchase_return';

          if (isSale || isPurchaseReturn) {
            db.prepare('UPDATE items SET currentStock = currentStock - ?, updatedAt = ? WHERE id = ?')
              .run(baseQuantity, now, item.itemId);
          } else if (isPurchase || isSaleReturn) {
            db.prepare('UPDATE items SET currentStock = currentStock + ?, updatedAt = ? WHERE id = ?')
              .run(baseQuantity, now, item.itemId);
          }
        }
      }
    }

    // Only sale/purchase invoices carry a receivable/payable balance — link any amount
    // collected/paid at billing time into the same payment_allocations ledger that
    // Payment Out/Receipt use, so cash/bank, ledger and status stay one source of truth.
    if (['sale_invoice', 'purchase_invoice'].includes(documentType) && status !== 'draft' && status !== 'cancelled') {
      if (paidAmount > 0 && partyId) {
        const payId = uuidv4();
        const payType = documentType === 'sale_invoice' ? 'payment_in' : 'payment_out';
        db.prepare(`INSERT INTO payments (id, firmId, type, partyId, partyName, amount, paymentMethod, bankId,
            receiptNumber, paymentDate, reference, description, linkedDocumentId, createdAt, updatedAt)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
          .run(payId, firmId, payType, partyId, partyName, paidAmount, paymentType || 'cash', bankId,
            null, documentDate, `Auto: ${docNumber}`, 'Collected at billing', id, now, now);
        db.prepare('INSERT INTO payment_allocations (id, firmId, paymentId, documentId, amount, createdAt) VALUES (?, ?, ?, ?, ?, ?)')
          .run(uuidv4(), firmId, payId, id, paidAmount, now);
        applyFunds(firmId, paymentType || 'cash', bankId, paidAmount, payType === 'payment_in' ? 1 : -1, now);
      }
      recalcDocumentStatus(id, now);
    }

    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(id);
    const docItems = db.prepare('SELECT * FROM document_items WHERE documentId = ?').all(id);
    res.status(201).json({ success: true, data: { ...doc as any, items: docItems } });
  } catch (err: any) {
    console.error('[Documents] Create error:', err);
    res.status(500).json({ error: err.message });
  }
});

// PUT update document
router.put('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const {
      documentDate, documentTime, partyId, partyName, partyType, phone,
      billingAddress, shippingAddress, transactionType, status, stateOfSupply,
      subtotal, discountAmount, discountPercentage, taxAmount,
      shippingCharges, packagingCharges, adjustment, roundOff,
      total, paidAmount, balanceAmount, paymentType, bankId,
      poNumber, poDate, description, ewaybillNo, vehicleNumber,
      transportName, deliveryDate, items = []
    } = req.body;

    // Get old items to reverse stock
    const oldItems = db.prepare('SELECT * FROM document_items WHERE documentId = ?').all(req.params.id);
    const oldDoc = db.prepare('SELECT documentType FROM documents WHERE id = ?').get(req.params.id) as any;

    // Reverse old stock changes — use the baseQuantity that was stored on the line at the
    // time (correct even if the item's unit/conversion has since changed), falling back to
    // the raw quantity for legacy rows saved before Two Units + Conversion existed.
    if (oldDoc) {
      const isSale = ['sale_invoice', 'sale_order', 'delivery_challan'].includes(oldDoc.documentType);
      const isPurchase = ['purchase_invoice', 'purchase_order'].includes(oldDoc.documentType);
      const isSaleReturn = oldDoc.documentType === 'sale_return';
      const isPurchaseReturn = oldDoc.documentType === 'purchase_return';
      for (const oldItem of oldItems as any[]) {
        if (oldItem.itemId) {
          const qty = oldItem.baseQuantity || oldItem.quantity;
          if (isSale || isPurchaseReturn) db.prepare('UPDATE items SET currentStock = currentStock + ?, updatedAt = ? WHERE id = ?').run(qty, now, oldItem.itemId);
          else if (isPurchase || isSaleReturn) db.prepare('UPDATE items SET currentStock = currentStock - ?, updatedAt = ? WHERE id = ?').run(qty, now, oldItem.itemId);
        }
      }
    }

    db.prepare(`
      UPDATE documents SET documentDate=?, documentTime=?, partyId=?, partyName=?, partyType=?,
        phone=?, billingAddress=?, shippingAddress=?, transactionType=?, status=?, stateOfSupply=?,
        subtotal=?, discountAmount=?, discountPercentage=?, taxAmount=?,
        shippingCharges=?, packagingCharges=?, adjustment=?, roundOff=?,
        total=?, paidAmount=?, balanceAmount=?, paymentType=?, bankId=?,
        poNumber=?, poDate=?, description=?, ewaybillNo=?, vehicleNumber=?,
        transportName=?, deliveryDate=?, updatedAt=? WHERE id=?
    `).run(
      documentDate, documentTime, partyId, partyName, partyType, phone,
      billingAddress, shippingAddress, transactionType, status, stateOfSupply,
      subtotal, discountAmount, discountPercentage, taxAmount,
      shippingCharges, packagingCharges, adjustment, roundOff,
      total, paidAmount, balanceAmount, paymentType, bankId,
      poNumber, poDate, description, ewaybillNo, vehicleNumber,
      transportName, deliveryDate, now, req.params.id
    );

    // Delete and re-insert items
    db.prepare('DELETE FROM document_items WHERE documentId = ?').run(req.params.id);
    
    const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id) as any;
    const insertItem = db.prepare(`
      INSERT INTO document_items (id, documentId, firmId, itemId, name, description, hsnCode,
        quantity, unit, unitId, isSecondaryUnit, baseQuantity, price, discount, discountType,
        taxRate, taxAmount, amount, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    for (const item of items) {
      const dbItem = item.itemId ? db.prepare('SELECT unitId, secondaryUnitId, conversionFactor FROM items WHERE id = ?').get(item.itemId) as any : null;
      const { baseQuantity, isSecondaryUnit, unitId: resolvedUnitId } = resolveLineUnit(doc.firmId, doc.documentType, dbItem, item);

      insertItem.run(
        uuidv4(), req.params.id, doc.firmId, item.itemId, item.name, item.description, item.hsnCode,
        item.quantity || 1, item.unit, resolvedUnitId, isSecondaryUnit, baseQuantity,
        item.price || 0, item.discount || 0,
        item.discountType || 'percentage', item.taxRate || 0, item.taxAmount || 0,
        item.amount || 0, now, now
      );

      // Apply new stock changes — base-unit terms.
      if (item.itemId && doc.documentType) {
        const isSale = ['sale_invoice', 'sale_order', 'delivery_challan'].includes(doc.documentType);
        const isPurchase = ['purchase_invoice', 'purchase_order'].includes(doc.documentType);
        const isSaleReturn = doc.documentType === 'sale_return';
        const isPurchaseReturn = doc.documentType === 'purchase_return';
        if (isSale || isPurchaseReturn) db.prepare('UPDATE items SET currentStock = currentStock - ?, updatedAt = ? WHERE id = ?').run(baseQuantity, now, item.itemId);
        else if (isPurchase || isSaleReturn) db.prepare('UPDATE items SET currentStock = currentStock + ?, updatedAt = ? WHERE id = ?').run(baseQuantity, now, item.itemId);
      }
    }

    // Re-derive paidAmount/balanceAmount/status from actual payment_allocations rather than
    // trusting client-sent values, so edits (e.g. total changing) can't desync billing from cash.
    if (['sale_invoice', 'purchase_invoice'].includes(doc.documentType) && status !== 'draft' && status !== 'cancelled') {
      recalcDocumentStatus(req.params.id, now);
    }

    const updatedDoc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
    const docItems = db.prepare('SELECT * FROM document_items WHERE documentId = ?').all(req.params.id);
    res.json({ success: true, data: { ...updatedDoc as any, items: docItems } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH trash/delete document
router.patch('/:id/trash', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE documents SET isDeleted = 1, updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true, message: 'Document trashed' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH restore document
router.patch('/:id/restore', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE documents SET isDeleted = 0, updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true, message: 'Document restored' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET next document number (preview only — does not consume the number).
// If seriesId is given, previews that series; otherwise falls back to the
// firm's default series for this type, then to the legacy per-firm counter.
router.get('/next-number/:type', (req: Request, res: Response) => {
  try {
    const { firmId, seriesId } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    const multiSeriesEnabled = getModuleSettings(String(firmId), req.params.type).multiSeriesEnabled;

    let series: any = null;
    if (multiSeriesEnabled && seriesId) {
      series = db.prepare('SELECT * FROM series WHERE id = ?').get(seriesId);
    } else if (multiSeriesEnabled) {
      series = db.prepare(
        'SELECT * FROM series WHERE firmId = ? AND transactionType = ? AND isActive = 1 AND isDefault = 1'
      ).get(firmId, req.params.type);
    }

    if (series) {
      const padded = String(series.currentNumber).padStart(series.numberLength, '0');
      const preview = series.includeFinancialYearInNumber && series.financialYear
        ? `${series.prefix}/${series.financialYear}/${padded}`
        : `${series.prefix}-${padded}`;
      return res.json({ success: true, data: preview, seriesId: series.id });
    }

    // Legacy fallback
    const firm = db.prepare('SELECT * FROM firms WHERE id = ?').get(firmId) as any;
    if (!firm) return res.status(404).json({ error: 'Firm not found' });
    const prefix = firm.invoicePrefix || 'INV';
    const num = firm.invoiceNumber || 1;
    res.json({ success: true, data: `${prefix}-${String(num).padStart(4, '0')}`, seriesId: null });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE document permanently
router.delete('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    // Reverse any payment_allocations against this document (and the auto-payment created
    // at billing time, if its entire amount was against this one document) so cash/bank and
    // other bills' balances don't silently retain a link to a document that no longer exists.
    const allocs = db.prepare('SELECT pa.paymentId, pa.amount, p.firmId, p.type, p.paymentMethod, p.bankId, p.amount as paymentAmount FROM payment_allocations pa JOIN payments p ON p.id = pa.paymentId WHERE pa.documentId = ?').all(req.params.id) as any[];
    for (const a of allocs) {
      applyFunds(a.firmId, a.paymentMethod, a.bankId, a.amount, a.type === 'payment_in' ? -1 : 1, now);
      db.prepare('DELETE FROM payment_allocations WHERE paymentId = ? AND documentId = ?').run(a.paymentId, req.params.id);
      const remaining = (db.prepare('SELECT COUNT(*) as c FROM payment_allocations WHERE paymentId = ?').get(a.paymentId) as any).c;
      if (remaining === 0 && Math.abs(a.amount - a.paymentAmount) < 0.01) {
        db.prepare('DELETE FROM payments WHERE id = ?').run(a.paymentId);
      }
    }
    db.prepare('DELETE FROM document_items WHERE documentId = ?').run(req.params.id);
    db.prepare('DELETE FROM documents WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Document deleted' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

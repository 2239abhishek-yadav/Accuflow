/**
 * Excel Import Routes — Items & Parties
 * POST /import/items/template   → download Excel template for items
 * POST /import/parties/template → download Excel template for parties
 * POST /import/items/preview    → parse + validate, return row results (no DB write)
 * POST /import/parties/preview  → parse + validate, return row results (no DB write)
 * POST /import/items/commit     → commit a validated preview to DB
 * POST /import/parties/commit   → commit a validated preview to DB
 */
import { Router, Request, Response } from 'express';
import multer from 'multer';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
import { validateGSTIN, validateMobile } from '../lib/validators';

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

/* ─── GSTIN rate slab lookup ────────────────────────────────────────────── */
const VALID_GST = ['0', '5', '12', '18', '28'];

/* ─── helper: coerce any cell value to a trimmed string ─────────────────── */
function cellStr(v: any): string {
  if (v === null || v === undefined) return '';
  return String(v).trim();
}

/* ─── ITEMS TEMPLATE ────────────────────────────────────────────────────── */
router.get('/items/template', (_req: Request, res: Response) => {
  try {
    const wb = XLSX.utils.book_new();
    const headers = [
      'Name*', 'Type (PRODUCT/SERVICE)', 'HSN/SAC Code', 'Item Code/SKU',
      'Category Name', 'Unit 1 (Short Name)', 'Unit 2 (Short Name, optional)',
      'Unit Conversion (how many Unit1 = 1 Unit2)', 'Sale Price*',
      'Sale Price Tax Inclusive (YES/NO)', 'Purchase Price',
      'Purchase Price Tax Inclusive (YES/NO)', 'GST Rate (0/5/12/18/28)',
      'Opening Stock', 'Min Stock Level', 'Storage Location', 'Brand/Description'
    ];
    const sample = [
      'Basmati Rice 5kg', 'PRODUCT', '1006', 'SKU-001',
      'Grocery', 'KG', 'BAG', '5', '450',
      'NO', '380', 'NO', '5',
      '100', '10', 'Shelf A-1', 'Premium brand'
    ];
    const ws = XLSX.utils.aoa_to_sheet([headers, sample]);
    ws['!cols'] = headers.map(() => ({ wch: 28 }));
    XLSX.utils.book_append_sheet(wb, ws, 'Items');

    // Instructions sheet
    const instr = [
      ['WayBook — Items Import Template'],
      [''],
      ['INSTRUCTIONS:'],
      ['1. Columns marked * are required.'],
      ['2. Type must be PRODUCT or SERVICE.'],
      ['3. Unit Short Names (e.g. KG, PCS, LTR) must already exist in WayBook.'],
      ['4. If Unit 2 is given, Unit Conversion must be > 0.'],
      ['5. GST Rate must be 0, 5, 12, 18, or 28.'],
      ['6. Do NOT change column headers.'],
      ['7. Remove this sheet before importing (or the importer ignores it automatically).'],
    ];
    const ws2 = XLSX.utils.aoa_to_sheet(instr);
    ws2['!cols'] = [{ wch: 70 }];
    XLSX.utils.book_append_sheet(wb, ws2, 'Instructions');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', 'attachment; filename="waybook_items_template.xlsx"');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

/* ─── PARTIES TEMPLATE ──────────────────────────────────────────────────── */
router.get('/parties/template', (_req: Request, res: Response) => {
  try {
    const wb = XLSX.utils.book_new();
    const headers = [
      'Name*', 'Type* (customer/supplier/both)', 'Phone', 'Email',
      'GSTIN', 'PAN', 'Address', 'City', 'State', 'Pincode',
      'Credit Limit', 'Opening Balance'
    ];
    const sample = [
      'Ramesh Traders', 'customer', '9876543210', 'ramesh@example.com',
      '22AAAAA0000A1Z5', 'AAAAA0000A', '123 Market Road', 'Mumbai', 'Maharashtra', '400001',
      '50000', '0'
    ];
    const ws = XLSX.utils.aoa_to_sheet([headers, sample]);
    ws['!cols'] = headers.map(() => ({ wch: 26 }));
    XLSX.utils.book_append_sheet(wb, ws, 'Parties');

    const instr = [
      ['WayBook — Parties Import Template'],
      [''],
      ['INSTRUCTIONS:'],
      ['1. Columns marked * are required.'],
      ['2. Type must be: customer, supplier, or both.'],
      ['3. Phone: 10-digit Indian mobile (optional).'],
      ['4. GSTIN: 15-character standard format (optional).'],
      ['5. State must match WayBook state list exactly.'],
      ['6. Do NOT change column headers.'],
    ];
    const ws2 = XLSX.utils.aoa_to_sheet(instr);
    ws2['!cols'] = [{ wch: 70 }];
    XLSX.utils.book_append_sheet(wb, ws2, 'Instructions');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Disposition', 'attachment; filename="waybook_parties_template.xlsx"');
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.send(buf);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

/* ─── ITEMS PREVIEW ─────────────────────────────────────────────────────── */
router.post('/items/preview', upload.single('file'), (req: Request, res: Response) => {
  try {
    const { firmId } = req.body;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });
    if (!req.file) return res.status(400).json({ error: 'Excel file required' });

    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    // Use the first sheet that isn't "Instructions"
    const sheetName = wb.SheetNames.find(n => n.toLowerCase() !== 'instructions') || wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    const rows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

    if (rows.length < 2) return res.json({ success: true, data: { rows: [], summary: { total: 0, ok: 0, errors: 0 } } });

    // Load lookup tables
    const units = db.prepare('SELECT id, shortName FROM units WHERE firmId = ?').all(firmId) as any[];
    const categories = db.prepare('SELECT id, name FROM categories WHERE firmId = ? AND type = ?').all(firmId, 'item') as any[];
    const existingItems = db.prepare('SELECT name, itemCode FROM items WHERE firmId = ? AND isActive = 1').all(firmId) as any[];

    const unitMap: Record<string, string> = {};
    for (const u of units) unitMap[u.shortName.trim().toUpperCase()] = u.id;

    const catMap: Record<string, string> = {};
    for (const c of categories) catMap[c.name.trim().toLowerCase()] = c.id;

    const existingNames = new Set(existingItems.map((i: any) => i.name.trim().toLowerCase()));
    const existingCodes = new Set(existingItems.map((i: any) => (i.itemCode || '').trim().toLowerCase()).filter(Boolean));

    const dataRows = rows.slice(1); // skip header
    const results: any[] = [];
    let ok = 0, errors = 0;

    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i];
      const rowNum = i + 2; // 1-based, header=1
      const errs: string[] = [];

      const name       = cellStr(row[0]);
      const type       = cellStr(row[1]).toUpperCase() || 'PRODUCT';
      const hsnCode    = cellStr(row[2]);
      const itemCode   = cellStr(row[3]);
      const catName    = cellStr(row[4]);
      const unit1Short = cellStr(row[5]).toUpperCase();
      const unit2Short = cellStr(row[6]).toUpperCase();
      const convFactor = parseFloat(cellStr(row[7])) || 0;
      const salePrice  = parseFloat(cellStr(row[8])) || 0;
      const saleTaxInc = cellStr(row[9]).toUpperCase() === 'YES' ? 1 : 0;
      const purPrice   = parseFloat(cellStr(row[10])) || 0;
      const purTaxInc  = cellStr(row[11]).toUpperCase() === 'YES' ? 1 : 0;
      const taxRate    = cellStr(row[12]) || '0';
      const openStock  = parseFloat(cellStr(row[13])) || 0;
      const minStock   = parseFloat(cellStr(row[14])) || 0;
      const location   = cellStr(row[15]);
      const description= cellStr(row[16]);

      // Skip completely empty rows
      if (!name && !unit1Short && !cellStr(row[8])) continue;

      // Validations
      if (!name) errs.push('Name is required');
      if (!['PRODUCT', 'SERVICE'].includes(type)) errs.push(`Type must be PRODUCT or SERVICE (got "${type}")`);
      if (name && existingNames.has(name.toLowerCase())) errs.push(`Item "${name}" already exists`);
      if (itemCode && existingCodes.has(itemCode.toLowerCase())) errs.push(`Item code "${itemCode}" already exists`);
      if (salePrice < 0) errs.push('Sale Price cannot be negative');
      if (!VALID_GST.includes(taxRate)) errs.push(`GST Rate must be 0, 5, 12, 18, or 28 (got "${taxRate}")`);

      let unitId: string | undefined;
      if (unit1Short) {
        unitId = unitMap[unit1Short];
        if (!unitId) errs.push(`Unit "${unit1Short}" not found in WayBook. Add it first.`);
      }

      let secondaryUnitId: string | undefined;
      if (unit2Short) {
        secondaryUnitId = unitMap[unit2Short];
        if (!secondaryUnitId) errs.push(`Unit 2 "${unit2Short}" not found in WayBook. Add it first.`);
        if (secondaryUnitId && secondaryUnitId === unitId) errs.push('Unit 1 and Unit 2 must be different');
        if (!convFactor || convFactor <= 0) errs.push('Unit Conversion must be > 0 when Unit 2 is specified');
      }

      let categoryId: string | undefined;
      if (catName) {
        categoryId = catMap[catName.toLowerCase()];
        if (!categoryId) errs.push(`Category "${catName}" not found. Create it first or leave blank.`);
      }

      const status = errs.length === 0 ? 'ok' : 'error';
      if (status === 'ok') ok++; else errors++;

      results.push({
        rowNum, status, errors: errs,
        data: { name, type, hsnCode, itemCode, catName, unit1Short, unit2Short,
          convFactor, salePrice, saleTaxInc, purPrice, purTaxInc, taxRate,
          openStock, minStock, location, description,
          unitId, secondaryUnitId, categoryId }
      });
    }

    res.json({ success: true, data: { rows: results, summary: { total: results.length, ok, errors } } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ─── ITEMS COMMIT ──────────────────────────────────────────────────────── */
router.post('/items/commit', (req: Request, res: Response) => {
  try {
    const { firmId, rows, overwriteExisting = false } = req.body;
    if (!firmId || !Array.isArray(rows)) return res.status(400).json({ error: 'firmId and rows required' });

    const now = new Date().toISOString();
    let inserted = 0, updated = 0, skipped = 0;

    const insertStmt = db.prepare(`
      INSERT INTO items (id, firmId, name, type, hsnCode, itemCode, description,
        categoryId, unitId, secondaryUnitId, conversionFactor,
        salePrice, salePriceTaxInclusive, purchasePrice, purchasePriceTaxInclusive,
        taxRate, openingStock, currentStock, minStockLevel, location,
        isActive, isFavorite, allowNegativeStock, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, 0, ?, ?)
    `);

    const updateStmt = db.prepare(`
      UPDATE items SET type=?, hsnCode=?, itemCode=?, description=?,
        categoryId=?, unitId=?, secondaryUnitId=?, conversionFactor=?,
        salePrice=?, salePriceTaxInclusive=?, purchasePrice=?, purchasePriceTaxInclusive=?,
        taxRate=?, minStockLevel=?, location=?, updatedAt=?
      WHERE firmId=? AND LOWER(name)=LOWER(?)
    `);

    const importRows = db.transaction(() => {
      for (const row of rows) {
        if (row.status !== 'ok') { skipped++; continue; }
        const d = row.data;
        const existing = db.prepare('SELECT id FROM items WHERE firmId = ? AND LOWER(name) = LOWER(?)').get(firmId, d.name) as any;

        if (existing) {
          if (!overwriteExisting) { skipped++; continue; }
          updateStmt.run(
            d.type, d.hsnCode, d.itemCode, d.description,
            d.categoryId || null, d.unitId || null, d.secondaryUnitId || null,
            d.secondaryUnitId ? (d.convFactor || 1) : 1,
            d.salePrice, d.saleTaxInc, d.purPrice, d.purTaxInc,
            d.taxRate, d.minStock, d.location, now,
            firmId, d.name
          );
          updated++;
        } else {
          insertStmt.run(
            uuidv4(), firmId, d.name, d.type, d.hsnCode, d.itemCode, d.description,
            d.categoryId || null, d.unitId || null, d.secondaryUnitId || null,
            d.secondaryUnitId ? (d.convFactor || 1) : 1,
            d.salePrice, d.saleTaxInc, d.purPrice, d.purTaxInc,
            d.taxRate, d.openStock, d.openStock, d.minStock, d.location,
            now, now
          );
          inserted++;
        }
      }
    });

    importRows();
    res.json({ success: true, data: { inserted, updated, skipped } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ─── PARTIES PREVIEW ───────────────────────────────────────────────────── */
router.post('/parties/preview', upload.single('file'), (req: Request, res: Response) => {
  try {
    const { firmId } = req.body;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });
    if (!req.file) return res.status(400).json({ error: 'Excel file required' });

    const wb = XLSX.read(req.file.buffer, { type: 'buffer' });
    const sheetName = wb.SheetNames.find(n => n.toLowerCase() !== 'instructions') || wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    const rows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });

    if (rows.length < 2) return res.json({ success: true, data: { rows: [], summary: { total: 0, ok: 0, errors: 0 } } });

    const existingParties = db.prepare('SELECT name, gstin FROM parties WHERE firmId = ? AND isActive = 1').all(firmId) as any[];
    const existingNames = new Set(existingParties.map((p: any) => p.name.trim().toLowerCase()));
    const existingGSTINs = new Set(existingParties.map((p: any) => (p.gstin || '').trim().toUpperCase()).filter(Boolean));

    const dataRows = rows.slice(1);
    const results: any[] = [];
    let ok = 0, errors = 0;

    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i];
      const rowNum = i + 2;
      const errs: string[] = [];

      const name     = cellStr(row[0]);
      const type     = cellStr(row[1]).toLowerCase() || 'customer';
      const phone    = cellStr(row[2]);
      const email    = cellStr(row[3]);
      const gstin    = cellStr(row[4]);
      const pan      = cellStr(row[5]);
      const address  = cellStr(row[6]);
      const city     = cellStr(row[7]);
      const state    = cellStr(row[8]);
      const pincode  = cellStr(row[9]);
      const creditLimit     = parseFloat(cellStr(row[10])) || 0;
      const openingBalance  = parseFloat(cellStr(row[11])) || 0;

      if (!name && !type) continue;

      // Validations
      if (!name) errs.push('Name is required');
      if (!['customer', 'supplier', 'both'].includes(type)) errs.push(`Type must be customer, supplier, or both (got "${type}")`);
      if (name && existingNames.has(name.toLowerCase())) errs.push(`Party "${name}" already exists`);

      let normalizedPhone = phone;
      if (phone) {
        const mCheck = validateMobile(phone);
        if (!mCheck.valid) errs.push(`Phone: ${mCheck.error}`);
        else normalizedPhone = mCheck.value || '';
      }

      let normalizedGstin = gstin;
      if (gstin) {
        const gCheck = validateGSTIN(gstin);
        if (!gCheck.valid) errs.push(`GSTIN: ${gCheck.error}`);
        else {
          normalizedGstin = gCheck.value || '';
          if (normalizedGstin && existingGSTINs.has(normalizedGstin)) errs.push(`GSTIN "${normalizedGstin}" already exists for another party`);
        }
      }

      const status = errs.length === 0 ? 'ok' : 'error';
      if (status === 'ok') ok++; else errors++;

      results.push({
        rowNum, status, errors: errs,
        data: { name, type, phone: normalizedPhone, email, gstin: normalizedGstin,
          pan, address, city, state, pincode, creditLimit, openingBalance }
      });
    }

    res.json({ success: true, data: { rows: results, summary: { total: results.length, ok, errors } } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

/* ─── PARTIES COMMIT ────────────────────────────────────────────────────── */
router.post('/parties/commit', (req: Request, res: Response) => {
  try {
    const { firmId, rows, overwriteExisting = false } = req.body;
    if (!firmId || !Array.isArray(rows)) return res.status(400).json({ error: 'firmId and rows required' });

    const now = new Date().toISOString();
    let inserted = 0, updated = 0, skipped = 0;

    const insertStmt = db.prepare(`
      INSERT INTO parties (id, firmId, name, type, phone, email, gstin, pan,
        address, city, state, pincode, creditLimit, openingBalance, isActive, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);
    const updateStmt = db.prepare(`
      UPDATE parties SET type=?, phone=?, email=?, gstin=?, pan=?,
        address=?, city=?, state=?, pincode=?, creditLimit=?, openingBalance=?, updatedAt=?
      WHERE firmId=? AND LOWER(name)=LOWER(?)
    `);

    const importRows = db.transaction(() => {
      for (const row of rows) {
        if (row.status !== 'ok') { skipped++; continue; }
        const d = row.data;
        const existing = db.prepare('SELECT id FROM parties WHERE firmId = ? AND LOWER(name) = LOWER(?)').get(firmId, d.name) as any;

        if (existing) {
          if (!overwriteExisting) { skipped++; continue; }
          updateStmt.run(
            d.type, d.phone, d.email, d.gstin, d.pan,
            d.address, d.city, d.state, d.pincode, d.creditLimit, d.openingBalance, now,
            firmId, d.name
          );
          updated++;
        } else {
          insertStmt.run(
            uuidv4(), firmId, d.name, d.type, d.phone, d.email, d.gstin, d.pan,
            d.address, d.city, d.state, d.pincode, d.creditLimit, d.openingBalance, now, now
          );
          inserted++;
        }
      }
    });

    importRows();
    res.json({ success: true, data: { inserted, updated, skipped } });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';

const router = Router();

// === EMPLOYEES ===
router.get('/employees', (req: Request, res: Response) => {
  try {
    const { firmId, status, search } = req.query;
    let q = 'SELECT * FROM employees WHERE firmId = ?';
    const p: any[] = [firmId];
    if (status) { q += ' AND status = ?'; p.push(status); }
    if (search) { q += ' AND (firstName LIKE ? OR lastName LIKE ? OR employeeCode LIKE ?)'; p.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    q += ' ORDER BY firstName ASC';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get('/employees/:id', (req: Request, res: Response) => {
  try {
    const emp = db.prepare('SELECT * FROM employees WHERE id = ?').get(req.params.id);
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    res.json({ success: true, data: emp });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post('/employees', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    const { firmId, employeeCode, firstName, lastName, phone, email, department, designation, joiningDate, salary = 0, salaryType = 'monthly', bankAccountName, bankAccountNumber, ifscCode, panNumber, aadharNumber, address } = req.body;
    db.prepare('INSERT INTO employees (id, firmId, employeeCode, firstName, lastName, phone, email, department, designation, joiningDate, salary, salaryType, bankAccountName, bankAccountNumber, ifscCode, panNumber, aadharNumber, address, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, \'active\', ?, ?)').run(id, firmId, employeeCode, firstName, lastName, phone, email, department, designation, joiningDate, salary, salaryType, bankAccountName, bankAccountNumber, ifscCode, panNumber, aadharNumber, address, now, now);
    res.status(201).json({ success: true, data: db.prepare('SELECT * FROM employees WHERE id = ?').get(id) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put('/employees/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const { firstName, lastName, phone, email, department, designation, joiningDate, salary, salaryType, bankAccountName, bankAccountNumber, ifscCode, panNumber, aadharNumber, address, status } = req.body;
    db.prepare('UPDATE employees SET firstName=?, lastName=?, phone=?, email=?, department=?, designation=?, joiningDate=?, salary=?, salaryType=?, bankAccountName=?, bankAccountNumber=?, ifscCode=?, panNumber=?, aadharNumber=?, address=?, status=?, updatedAt=? WHERE id=?').run(firstName, lastName, phone, email, department, designation, joiningDate, salary, salaryType, bankAccountName, bankAccountNumber, ifscCode, panNumber, aadharNumber, address, status, now, req.params.id);
    res.json({ success: true, data: db.prepare('SELECT * FROM employees WHERE id = ?').get(req.params.id) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete('/employees/:id', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE employees SET status = \'inactive\', updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// === ATTENDANCE ===
router.get('/attendance', (req: Request, res: Response) => {
  try {
    const { firmId, employeeId, month, year } = req.query;
    let q = 'SELECT a.*, e.firstName, e.lastName FROM attendance a JOIN employees e ON a.employeeId = e.id WHERE a.firmId = ?';
    const p: any[] = [firmId];
    if (employeeId) { q += ' AND a.employeeId = ?'; p.push(employeeId); }
    if (month && year) { q += ' AND strftime(\'%m\', a.date) = ? AND strftime(\'%Y\', a.date) = ?'; p.push(String(month).padStart(2, '0'), year); }
    q += ' ORDER BY a.date DESC';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post('/attendance', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    const { firmId, employeeId, date, status = 'present', checkIn, checkOut, notes } = req.body;
    // Upsert
    const existing = db.prepare('SELECT id FROM attendance WHERE firmId = ? AND employeeId = ? AND date = ?').get(firmId, employeeId, date);
    if (existing) {
      db.prepare('UPDATE attendance SET status=?, checkIn=?, checkOut=?, notes=?, updatedAt=? WHERE firmId=? AND employeeId=? AND date=?').run(status, checkIn, checkOut, notes, now, firmId, employeeId, date);
    } else {
      db.prepare('INSERT INTO attendance (id, firmId, employeeId, date, status, checkIn, checkOut, notes, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(id, firmId, employeeId, date, status, checkIn, checkOut, notes, now, now);
    }
    res.status(201).json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// === PAYROLL ===
router.get('/payroll', (req: Request, res: Response) => {
  try {
    res.json({ success: true, data: db.prepare('SELECT * FROM payroll_runs WHERE firmId = ? ORDER BY year DESC, month DESC').all([req.query.firmId]) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post('/payroll/run', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const runId = uuidv4();
    const { firmId, month, year } = req.body;
    
    // Get all active employees
    const employees = db.prepare('SELECT * FROM employees WHERE firmId = ? AND status = \'active\'').all(firmId) as any[];
    
    let totalAmount = 0;
    const items = [];
    
    for (const emp of employees) {
      // Calculate attendance
      const attResult = db.prepare('SELECT COUNT(*) as total, SUM(CASE WHEN status = \'present\' THEN 1 WHEN status = \'half_day\' THEN 0.5 ELSE 0 END) as present FROM attendance WHERE firmId = ? AND employeeId = ? AND strftime(\'%m\', date) = ? AND strftime(\'%Y\', date) = ?').get(firmId, emp.id, String(month).padStart(2, '0'), String(year)) as any;
      
      const totalDays = 26; // Working days
      const presentDays = attResult?.present || totalDays; // Default full if no attendance
      const earnedSalary = (emp.salary / totalDays) * presentDays;
      const netSalary = earnedSalary;
      totalAmount += netSalary;
      
      items.push({ id: uuidv4(), payrollRunId: runId, employeeId: emp.id, employeeName: `${emp.firstName} ${emp.lastName || ''}`, basicSalary: emp.salary, totalDays, presentDays, earnedSalary, allowances: 0, deductions: 0, netSalary, status: 'pending' });
    }
    
    db.prepare('INSERT INTO payroll_runs (id, firmId, month, year, status, totalAmount, createdAt, updatedAt) VALUES (?, ?, ?, ?, \'draft\', ?, ?, ?)').run(runId, firmId, month, year, totalAmount, now, now);
    
    const insertItem = db.prepare('INSERT INTO payroll_items (id, payrollRunId, employeeId, employeeName, basicSalary, totalDays, presentDays, earnedSalary, allowances, deductions, netSalary, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    for (const item of items) {
      insertItem.run(item.id, item.payrollRunId, item.employeeId, item.employeeName, item.basicSalary, item.totalDays, item.presentDays, item.earnedSalary, item.allowances, item.deductions, item.netSalary, item.status, now, now);
    }
    
    res.status(201).json({ success: true, data: { id: runId, items, totalAmount } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get('/payroll/:id', (req: Request, res: Response) => {
  try {
    const run = db.prepare('SELECT * FROM payroll_runs WHERE id = ?').get(req.params.id);
    const items = db.prepare('SELECT * FROM payroll_items WHERE payrollRunId = ?').all(req.params.id);
    res.json({ success: true, data: { ...run as any, items } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post('/payroll/:id/lock', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE payroll_runs SET status = \'locked\', updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete('/payroll/:id', (req: Request, res: Response) => {
  try {
    db.prepare('DELETE FROM payroll_items WHERE payrollRunId = ?').run(req.params.id);
    db.prepare('DELETE FROM payroll_runs WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;

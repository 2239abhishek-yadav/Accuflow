import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
const router = Router();
router.get('/', (req: Request, res: Response) => { try { const { firmId, type } = req.query; let q = 'SELECT * FROM categories WHERE firmId = ?'; const p: any[] = [firmId]; if (type) { q += ' AND type = ?'; p.push(type); } q += ' ORDER BY name'; res.json({ success: true, data: db.prepare(q).all(p) }); } catch (err: any) { res.status(500).json({ error: err.message }); } });
router.post('/', (req: Request, res: Response) => { try { const now = new Date().toISOString(); const id = uuidv4(); const { firmId, name, type = 'item' } = req.body; db.prepare('INSERT INTO categories (id, firmId, name, type, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?)').run(id, firmId, name, type, now, now); res.status(201).json({ success: true, data: db.prepare('SELECT * FROM categories WHERE id = ?').get(id) }); } catch (err: any) { res.status(500).json({ error: err.message }); } });
router.put('/:id', (req: Request, res: Response) => { try { const { name } = req.body; db.prepare('UPDATE categories SET name=?, updatedAt=? WHERE id=?').run(name, new Date().toISOString(), req.params.id); res.json({ success: true }); } catch (err: any) { res.status(500).json({ error: err.message }); } });
router.delete('/:id', (req: Request, res: Response) => { try { db.prepare('DELETE FROM categories WHERE id = ?').run(req.params.id); res.json({ success: true }); } catch (err: any) { res.status(500).json({ error: err.message }); } });
export default router;

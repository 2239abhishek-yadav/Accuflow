import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
import { recalcDocumentStatus, applyFunds } from '../lib/ledger';

const router = Router();

router.get('/', (req: Request, res: Response) => {
  try {
    const { firmId, type, partyId } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });
    let q = 'SELECT * FROM payments WHERE firmId = ?';
    const p: any[] = [firmId];
    if (type) { q += ' AND type = ?'; p.push(type); }
    if (partyId) { q += ' AND partyId = ?'; p.push(partyId); }
    q += ' ORDER BY paymentDate DESC';
    const payments = db.prepare(q).all(p) as any[];
    const allocStmt = db.prepare('SELECT documentId, amount FROM payment_allocations WHERE paymentId = ?');
    for (const pay of payments) pay.allocations = allocStmt.all(pay.id);
    res.json({ success: true, data: payments });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Unpaid/partially-paid bills for a party, to drive bill-wise Payment Out / Receipt selection.
router.get('/unpaid-bills', (req: Request, res: Response) => {
  try {
    const { firmId, partyId, partyType } = req.query;
    if (!firmId || !partyId) return res.status(400).json({ error: 'firmId and partyId required' });
    const documentType = partyType === 'supplier' ? 'purchase_invoice' : 'sale_invoice';
    const bills = db.prepare(
      `SELECT id, documentNumber, documentDate, total, paidAmount, balanceAmount, status
       FROM documents
       WHERE firmId = ? AND partyId = ? AND documentType = ? AND isDeleted = 0
         AND status NOT IN ('paid', 'cancelled', 'draft')
       ORDER BY documentDate ASC`
    ).all(firmId, partyId, documentType);
    res.json({ success: true, data: bills });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', (req: Request, res: Response) => {
  try {
    const p = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id) as any;
    if (!p) return res.status(404).json({ error: 'Payment not found' });
    p.allocations = db.prepare('SELECT documentId, amount FROM payment_allocations WHERE paymentId = ?').all(p.id);
    res.json({ success: true, data: p });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Create a Payment In (Receipt) or Payment Out, optionally allocated bill-wise against
// one or more documents. Unallocated balance is treated as advance/unadjusted.
router.post('/', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    const {
      firmId, type, partyId, partyName, amount, paymentMethod = 'cash', bankId,
      receiptNumber, paymentDate, reference, description, allocations = []
    } = req.body;
    if (!firmId || !type || !partyName || !amount || !paymentDate) {
      return res.status(400).json({ error: 'Required fields missing' });
    }
    const allocTotal = allocations.reduce((s: number, a: any) => s + (parseFloat(a.amount) || 0), 0);
    if (allocTotal - parseFloat(amount) > 0.004) {
      return res.status(400).json({ error: 'Allocated amount cannot exceed payment amount' });
    }

    const run = db.transaction(() => {
      db.prepare(`INSERT INTO payments (id, firmId, type, partyId, partyName, amount, paymentMethod, bankId,
          receiptNumber, paymentDate, reference, description, linkedDocumentId, createdAt, updatedAt)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(id, firmId, type, partyId, partyName, amount, paymentMethod, bankId, receiptNumber, paymentDate,
          reference, description, allocations[0]?.documentId || null, now, now);

      const insertAlloc = db.prepare('INSERT INTO payment_allocations (id, firmId, paymentId, documentId, amount, createdAt) VALUES (?, ?, ?, ?, ?, ?)');
      for (const a of allocations) {
        const allocAmt = parseFloat(a.amount) || 0;
        if (allocAmt <= 0) continue;
        insertAlloc.run(uuidv4(), firmId, id, a.documentId, allocAmt, now);
        recalcDocumentStatus(a.documentId, now);
      }

      // payment_in (Receipt) increases cash/bank; payment_out decreases it.
      applyFunds(firmId, paymentMethod, bankId, parseFloat(amount), type === 'payment_in' ? 1 : -1, now);
    });
    run();

    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(id) as any;
    payment.allocations = db.prepare('SELECT documentId, amount FROM payment_allocations WHERE paymentId = ?').all(id);
    res.status(201).json({ success: true, data: payment });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Non-financial edit only (financial fields are immutable — delete and re-create to change amount/allocations,
// so cash/bank and bill balances never drift out of sync).
router.put('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const { partyId, partyName, receiptNumber, paymentDate, reference, description } = req.body;
    db.prepare('UPDATE payments SET partyId=?, partyName=?, receiptNumber=?, paymentDate=?, reference=?, description=?, updatedAt=? WHERE id=?')
      .run(partyId, partyName, receiptNumber, paymentDate, reference, description, now, req.params.id);
    res.json({ success: true, data: db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const payment = db.prepare('SELECT * FROM payments WHERE id = ?').get(req.params.id) as any;
    if (!payment) return res.status(404).json({ error: 'Payment not found' });

    const run = db.transaction(() => {
      const allocs = db.prepare('SELECT documentId FROM payment_allocations WHERE paymentId = ?').all(req.params.id) as any[];
      db.prepare('DELETE FROM payment_allocations WHERE paymentId = ?').run(req.params.id);
      for (const a of allocs) recalcDocumentStatus(a.documentId, now);
      applyFunds(payment.firmId, payment.paymentMethod, payment.bankId, payment.amount, payment.type === 'payment_in' ? -1 : 1, now);
      db.prepare('DELETE FROM payments WHERE id = ?').run(req.params.id);
    });
    run();

    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;

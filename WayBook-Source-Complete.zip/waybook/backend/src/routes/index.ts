import { Router } from 'express';
import firmsRouter from './firms.routes';
import itemsRouter from './items.routes';
import partiesRouter from './parties.routes';
import documentsRouter from './documents.routes';
import paymentsRouter from './payments.routes';
import bankRouter from './bank.routes';
import reportsRouter from './reports.routes';
import hrRouter from './hr.routes';
import categoriesRouter from './categories.routes';
import unitsRouter from './units.routes';
import agentsRouter from './agents.routes';
import settingsRouter from './settings.routes';
import godownsRouter from './godowns.routes';
import expensesRouter from './expenses.routes';
import seriesRouter from './series.routes';
import importRouter from './import.routes';

const router = Router();

router.use('/firms', firmsRouter);
router.use('/items', itemsRouter);
router.use('/parties', partiesRouter);
router.use('/documents', documentsRouter);
router.use('/payments', paymentsRouter);
router.use('/bank', bankRouter);
router.use('/reports', reportsRouter);
router.use('/hr', hrRouter);
router.use('/categories', categoriesRouter);
router.use('/units', unitsRouter);
// Projects module removed from active use (dev-scope removal, per request) — route
// file and DB table left intact (data safety), just no longer mounted or in the UI.
router.use('/agents', agentsRouter);
router.use('/settings', settingsRouter);
router.use('/godowns', godownsRouter);
router.use('/expenses', expensesRouter);
router.use('/series', seriesRouter);
router.use('/import', importRouter);

export default router;

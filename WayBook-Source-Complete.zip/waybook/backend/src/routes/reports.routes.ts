import { Router, Request, Response } from 'express';
import * as XLSX from 'xlsx';
import { db } from '../lib/db';
import { computeGstr1, computeGstr3b } from '../lib/gst';

const router = Router();

// Dashboard summary
router.get('/dashboard', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    const dateFilter = startDate && endDate ? `AND documentDate BETWEEN '${startDate}' AND '${endDate}'` : '';

    const salesTotal = (db.prepare(`SELECT COALESCE(SUM(total),0) as total, COUNT(*) as count FROM documents WHERE firmId=? AND documentType='sale_invoice' AND isDeleted=0 ${dateFilter}`).get(firmId) as any);
    const purchasesTotal = (db.prepare(`SELECT COALESCE(SUM(total),0) as total, COUNT(*) as count FROM documents WHERE firmId=? AND documentType='purchase_invoice' AND isDeleted=0 ${dateFilter}`).get(firmId) as any);
    const expensesTotal = (db.prepare(`SELECT COALESCE(SUM(amount),0) as total FROM expenses WHERE firmId=? ${startDate ? `AND date BETWEEN '${startDate}' AND '${endDate}'` : ''}`).get(firmId) as any);
    const outstandingReceivable = (db.prepare(`SELECT COALESCE(SUM(balanceAmount),0) as total FROM documents WHERE firmId=? AND partyType='customer' AND balanceAmount>0 AND isDeleted=0`).get(firmId) as any);
    const outstandingPayable = (db.prepare(`SELECT COALESCE(SUM(balanceAmount),0) as total FROM documents WHERE firmId=? AND partyType='supplier' AND balanceAmount>0 AND isDeleted=0`).get(firmId) as any);
    const lowStockItems = (db.prepare(`SELECT COUNT(*) as count FROM items WHERE firmId=? AND type='PRODUCT' AND isActive=1 AND currentStock<=minStockLevel AND minStockLevel>0`).get(firmId) as any);
    const totalItems = (db.prepare(`SELECT COUNT(*) as count FROM items WHERE firmId=? AND isActive=1`).get(firmId) as any);
    const totalParties = (db.prepare(`SELECT COUNT(*) as count FROM parties WHERE firmId=? AND isActive=1`).get(firmId) as any);
    const firm = (db.prepare(`SELECT cashInHand FROM firms WHERE id=?`).get(firmId) as any);
    const bankTotal = (db.prepare(`SELECT COALESCE(SUM(currentBalance),0) as total FROM bank_accounts WHERE firmId=? AND isActive=1`).get(firmId) as any);
    const inventoryValue = (db.prepare(`SELECT COALESCE(SUM(currentStock * purchasePrice),0) as total FROM items WHERE firmId=? AND type='PRODUCT' AND isActive=1`).get(firmId) as any);
    const todaySales = (db.prepare(`SELECT COALESCE(SUM(total),0) as total FROM documents WHERE firmId=? AND documentType='sale_invoice' AND isDeleted=0 AND documentDate = date('now')`).get(firmId) as any);
    const todayPurchases = (db.prepare(`SELECT COALESCE(SUM(total),0) as total FROM documents WHERE firmId=? AND documentType='purchase_invoice' AND isDeleted=0 AND documentDate = date('now')`).get(firmId) as any);
    
    // Recent transactions
    const recentDocs = db.prepare(`SELECT documentNumber, documentType, partyName, total, documentDate FROM documents WHERE firmId=? AND isDeleted=0 ORDER BY createdAt DESC LIMIT 5`).all(firmId);

    // Monthly sales for chart.
    // Bug fix: this previously ignored the selected date filter and always showed the
    // last 6 calendar months regardless of the Dashboard's period selector. It now
    // respects startDate/endDate when given, and only falls back to "last 6 months"
    // when no explicit range is selected (e.g. first load).
    const monthlySales = startDate && endDate
      ? db.prepare(`
          SELECT strftime('%Y-%m', documentDate) as month, SUM(total) as total
          FROM documents WHERE firmId=? AND documentType='sale_invoice' AND isDeleted=0 ${dateFilter}
          GROUP BY month ORDER BY month ASC
        `).all(firmId)
      : db.prepare(`
          SELECT strftime('%Y-%m', documentDate) as month, SUM(total) as total
          FROM documents WHERE firmId=? AND documentType='sale_invoice' AND isDeleted=0
          GROUP BY month ORDER BY month DESC LIMIT 6
        `).all(firmId).reverse();

    // Same period logic as monthlySales, for Purchases and Expenses, so the combo
    // Sales/Purchase/Profit trend chart on the dashboard has matching buckets.
    const monthlyPurchases = startDate && endDate
      ? db.prepare(`SELECT strftime('%Y-%m', documentDate) as month, SUM(total) as total FROM documents WHERE firmId=? AND documentType='purchase_invoice' AND isDeleted=0 ${dateFilter} GROUP BY month ORDER BY month ASC`).all(firmId)
      : db.prepare(`SELECT strftime('%Y-%m', documentDate) as month, SUM(total) as total FROM documents WHERE firmId=? AND documentType='purchase_invoice' AND isDeleted=0 GROUP BY month ORDER BY month DESC LIMIT 6`).all(firmId).reverse();
    const monthlyExpenses = startDate && endDate
      ? db.prepare(`SELECT strftime('%Y-%m', date) as month, SUM(amount) as total FROM expenses WHERE firmId=? AND date BETWEEN ? AND ? GROUP BY month ORDER BY month ASC`).all(firmId, startDate, endDate)
      : db.prepare(`SELECT strftime('%Y-%m', date) as month, SUM(amount) as total FROM expenses WHERE firmId=? GROUP BY month ORDER BY month DESC LIMIT 6`).all(firmId).reverse();

    const salesByMonth: Record<string, number> = {};
    (monthlySales as any[]).forEach(r => salesByMonth[r.month] = r.total || 0);
    const purchByMonth: Record<string, number> = {};
    (monthlyPurchases as any[]).forEach(r => purchByMonth[r.month] = r.total || 0);
    const expByMonth: Record<string, number> = {};
    (monthlyExpenses as any[]).forEach(r => expByMonth[r.month] = r.total || 0);
    const months = Array.from(new Set([...Object.keys(salesByMonth), ...Object.keys(purchByMonth), ...Object.keys(expByMonth)])).sort();
    const monthlyTrends = months.map(month => ({
      month,
      sales: salesByMonth[month] || 0,
      purchases: purchByMonth[month] || 0,
      expenses: expByMonth[month] || 0,
      profit: (salesByMonth[month] || 0) - (purchByMonth[month] || 0) - (expByMonth[month] || 0),
    }));

    res.json({
      success: true,
      data: {
        sales: { total: salesTotal?.total || 0, count: salesTotal?.count || 0 },
        purchases: { total: purchasesTotal?.total || 0, count: purchasesTotal?.count || 0 },
        expenses: { total: expensesTotal?.total || 0 },
        outstanding: {
          receivable: outstandingReceivable?.total || 0,
          payable: outstandingPayable?.total || 0
        },
        stock: { lowStock: lowStockItems?.count || 0, inventoryValue: inventoryValue?.total || 0 },
        totals: { items: totalItems?.count || 0, parties: totalParties?.count || 0 },
        cashInHand: firm?.cashInHand || 0,
        bankBalance: bankTotal?.total || 0,
        today: { sales: todaySales?.total || 0, purchases: todayPurchases?.total || 0 },
        recentDocs,
        monthlySales,
        monthlyTrends,
        grossProfit: (salesTotal?.total || 0) - (purchasesTotal?.total || 0),
        profit: (salesTotal?.total || 0) - (purchasesTotal?.total || 0) - (expensesTotal?.total || 0)
      }
    });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Top 5 Selling Items (by quantity sold, within the selected date range)
router.get('/top-items', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, limit = '5' } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    const dateFilter = startDate && endDate ? `AND d.documentDate BETWEEN '${startDate}' AND '${endDate}'` : '';

    const rows = db.prepare(`
      SELECT
        di.itemId,
        di.name as itemName,
        SUM(di.quantity) as quantitySold,
        SUM(di.amount) as salesValue
      FROM document_items di
      JOIN documents d ON d.id = di.documentId
      WHERE d.firmId = ? AND d.documentType = 'sale_invoice' AND d.isDeleted = 0 ${dateFilter}
      GROUP BY COALESCE(di.itemId, di.name)
      ORDER BY salesValue DESC
      LIMIT ?
    `).all(firmId, Number(limit));

    const ranked = (rows as any[]).map((r, i) => ({ rank: i + 1, ...r }));
    res.json({ success: true, data: ranked });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Top 5 Transactions (by total value, within the selected date range, across sale + purchase docs)
router.get('/top-transactions', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, limit = '5' } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    const dateFilter = startDate && endDate ? `AND documentDate BETWEEN '${startDate}' AND '${endDate}'` : '';

    const rows = db.prepare(`
      SELECT documentNumber, documentDate, partyName, documentType, total
      FROM documents
      WHERE firmId = ? AND isDeleted = 0 ${dateFilter}
      ORDER BY total DESC
      LIMIT ?
    `).all(firmId, Number(limit));

    const ranked = (rows as any[]).map((r, i) => ({ rank: i + 1, ...r }));
    res.json({ success: true, data: ranked });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Profit & Loss
router.get('/profit-loss', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate } = req.query;
    const dateFilter = startDate && endDate ? `AND documentDate BETWEEN '${startDate}' AND '${endDate}'` : '';

    const sales = db.prepare(`SELECT COALESCE(SUM(total),0) as total FROM documents WHERE firmId=? AND documentType='sale_invoice' AND isDeleted=0 ${dateFilter}`).get(firmId) as any;
    const saleReturns = db.prepare(`SELECT COALESCE(SUM(total),0) as total FROM documents WHERE firmId=? AND documentType='sale_return' AND isDeleted=0 ${dateFilter}`).get(firmId) as any;
    const purchases = db.prepare(`SELECT COALESCE(SUM(total),0) as total FROM documents WHERE firmId=? AND documentType='purchase_invoice' AND isDeleted=0 ${dateFilter}`).get(firmId) as any;
    const expenses = db.prepare(`SELECT COALESCE(SUM(amount),0) as total FROM expenses WHERE firmId=? ${startDate ? `AND date BETWEEN '${startDate}' AND '${endDate}'` : ''}`).get(firmId) as any;

    const netSales = (sales?.total || 0) - (saleReturns?.total || 0);
    const grossProfit = netSales - (purchases?.total || 0);
    const netProfit = grossProfit - (expenses?.total || 0);

    res.json({ success: true, data: { sales: sales?.total || 0, saleReturns: saleReturns?.total || 0, netSales, purchases: purchases?.total || 0, grossProfit, expenses: expenses?.total || 0, netProfit } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Stock Summary
router.get('/stock-summary', (req: Request, res: Response) => {
  try {
    const { firmId, search } = req.query;
    let q = 'SELECT i.*, c.name as categoryName FROM items i LEFT JOIN categories c ON i.categoryId = c.id WHERE i.firmId = ? AND i.type = \'PRODUCT\' AND i.isActive = 1';
    const p: any[] = [firmId];
    if (search) { q += ' AND i.name LIKE ?'; p.push(`%${search}%`); }
    q += ' ORDER BY i.name';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Sales Report
router.get('/sales', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, partyId } = req.query;
    let q = 'SELECT d.*, di.name as itemName, di.quantity, di.price, di.amount FROM documents d LEFT JOIN document_items di ON d.id = di.documentId WHERE d.firmId=? AND d.documentType=\'sale_invoice\' AND d.isDeleted=0';
    const p: any[] = [firmId];
    if (startDate) { q += ' AND d.documentDate >= ?'; p.push(startDate); }
    if (endDate) { q += ' AND d.documentDate <= ?'; p.push(endDate); }
    if (partyId) { q += ' AND d.partyId = ?'; p.push(partyId); }
    q += ' ORDER BY d.documentDate DESC';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Purchase Report
router.get('/purchases', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, partyId } = req.query;
    let q = 'SELECT * FROM documents WHERE firmId=? AND documentType=\'purchase_invoice\' AND isDeleted=0';
    const p: any[] = [firmId];
    if (startDate) { q += ' AND documentDate >= ?'; p.push(startDate); }
    if (endDate) { q += ' AND documentDate <= ?'; p.push(endDate); }
    if (partyId) { q += ' AND partyId = ?'; p.push(partyId); }
    q += ' ORDER BY documentDate DESC';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// GST Report (Tax Summary)
router.get('/gst', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate } = req.query;
    let q = 'SELECT documentType, SUM(taxAmount) as totalTax, SUM(total) as total, COUNT(*) as count FROM documents WHERE firmId=? AND isDeleted=0';
    const p: any[] = [firmId];
    if (startDate) { q += ' AND documentDate >= ?'; p.push(startDate); }
    if (endDate) { q += ' AND documentDate <= ?'; p.push(endDate); }
    q += ' GROUP BY documentType';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// GSTR-1 — outward supplies return (B2B, B2C Large, B2C Small, Credit Notes, HSN summary)
router.get('/gstr1', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate } = req.query;
    if (!firmId || !startDate || !endDate) return res.status(400).json({ error: 'firmId, startDate and endDate required' });
    res.json({ success: true, data: computeGstr1(String(firmId), String(startDate), String(endDate)) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// GSTR-3B — summary return (net outward tax vs input tax credit)
router.get('/gstr3b', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate } = req.query;
    if (!firmId || !startDate || !endDate) return res.status(400).json({ error: 'firmId, startDate and endDate required' });
    res.json({ success: true, data: computeGstr3b(String(firmId), String(startDate), String(endDate)) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Sheet helper: XLSX chokes on a truly empty json_to_sheet() in some versions,
// so an empty section still gets a one-row placeholder instead of no sheet at all.
function sheetOrPlaceholder(rows: any[], emptyNote: string) {
  return XLSX.utils.json_to_sheet(rows.length ? rows : [{ Note: emptyNote }]);
}

// GSTR-1 export — Excel (multi-sheet, matches the GSTR-1 tables) or JSON (raw computed data)
router.get('/gstr1/export', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, format = 'xlsx' } = req.query;
    if (!firmId || !startDate || !endDate) return res.status(400).json({ error: 'firmId, startDate and endDate required' });
    const data = computeGstr1(String(firmId), String(startDate), String(endDate));
    const filenameBase = `GSTR1_${startDate}_to_${endDate}`;

    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.json"`);
      return res.send(JSON.stringify(data, null, 2));
    }

    const wb = XLSX.utils.book_new();
    const summaryRows = [
      { Field: 'Firm', Value: data.firm.name || '' },
      { Field: 'GSTIN', Value: data.firm.gstin || '' },
      { Field: 'Period', Value: `${data.period.startDate} to ${data.period.endDate}` },
      { Field: 'Total Invoices', Value: data.summary.totalInvoices },
      { Field: 'Taxable Value', Value: data.summary.taxableValue },
      { Field: 'IGST', Value: data.summary.igst },
      { Field: 'CGST', Value: data.summary.cgst },
      { Field: 'SGST', Value: data.summary.sgst },
      { Field: 'Total Tax', Value: data.summary.totalTax },
      { Field: 'Credit Note Value', Value: data.summary.creditNoteValue },
      { Field: 'Credit Note Tax', Value: data.summary.creditNoteTax },
    ];
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(summaryRows), 'Summary');
    XLSX.utils.book_append_sheet(wb, sheetOrPlaceholder(data.b2b, 'No B2B invoices in this period.'), 'B2B (4A)');
    XLSX.utils.book_append_sheet(wb, sheetOrPlaceholder(data.b2cLarge, 'No B2C Large invoices in this period.'), 'B2C Large (5)');
    XLSX.utils.book_append_sheet(wb, sheetOrPlaceholder(data.b2cSmall, 'No B2C Small supplies in this period.'), 'B2C Small (7)');
    XLSX.utils.book_append_sheet(wb, sheetOrPlaceholder(data.creditNotes, 'No credit notes in this period.'), 'Credit Notes (9B)');
    XLSX.utils.book_append_sheet(wb, sheetOrPlaceholder(data.hsnSummary, 'No items in this period.'), 'HSN Summary (12)');

    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.xlsx"`);
    res.send(buf);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// GSTR-3B export — Excel (one sheet, table 3.1 / 4 / 6.1) or JSON (raw computed data)
router.get('/gstr3b/export', (req: Request, res: Response) => {
  try {
    const { firmId, startDate, endDate, format = 'xlsx' } = req.query;
    if (!firmId || !startDate || !endDate) return res.status(400).json({ error: 'firmId, startDate and endDate required' });
    const data = computeGstr3b(String(firmId), String(startDate), String(endDate));
    const filenameBase = `GSTR3B_${startDate}_to_${endDate}`;

    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.json"`);
      return res.send(JSON.stringify(data, null, 2));
    }

    const rows = [
      { Section: 'Firm', Field: 'Name', Value: data.firm.name || '' },
      { Section: 'Firm', Field: 'GSTIN', Value: data.firm.gstin || '' },
      { Section: 'Firm', Field: 'Period', Value: `${data.period.startDate} to ${data.period.endDate}` },
      { Section: '3.1 Outward Taxable Supplies', Field: 'Taxable Value', Value: data.outwardSupplies.taxableValue },
      { Section: '3.1 Outward Taxable Supplies', Field: 'IGST', Value: data.outwardSupplies.igst },
      { Section: '3.1 Outward Taxable Supplies', Field: 'CGST', Value: data.outwardSupplies.cgst },
      { Section: '3.1 Outward Taxable Supplies', Field: 'SGST', Value: data.outwardSupplies.sgst },
      { Section: '4. Eligible ITC', Field: 'Taxable Value', Value: data.itc.taxableValue },
      { Section: '4. Eligible ITC', Field: 'IGST', Value: data.itc.igst },
      { Section: '4. Eligible ITC', Field: 'CGST', Value: data.itc.cgst },
      { Section: '4. Eligible ITC', Field: 'SGST', Value: data.itc.sgst },
      { Section: '6.1 Net Tax Payable', Field: 'IGST', Value: data.netTaxPayable.igst },
      { Section: '6.1 Net Tax Payable', Field: 'CGST', Value: data.netTaxPayable.cgst },
      { Section: '6.1 Net Tax Payable', Field: 'SGST', Value: data.netTaxPayable.sgst },
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), 'GSTR-3B');
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filenameBase}.xlsx"`);
    res.send(buf);
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Party Outstanding Report
router.get('/party-outstanding', (req: Request, res: Response) => {
  try {
    const { firmId, partyType } = req.query;
    let q = 'SELECT partyId, partyName, SUM(balanceAmount) as outstanding, COUNT(*) as invoiceCount FROM documents WHERE firmId=? AND balanceAmount>0 AND isDeleted=0';
    const p: any[] = [firmId];
    if (partyType) { q += ' AND partyType=?'; p.push(partyType); }
    q += ' GROUP BY partyId, partyName ORDER BY outstanding DESC';
    res.json({ success: true, data: db.prepare(q).all(p) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Day Book
router.get('/day-book', (req: Request, res: Response) => {
  try {
    const { firmId, date } = req.query;
    const docs = db.prepare('SELECT * FROM documents WHERE firmId=? AND documentDate=? AND isDeleted=0 ORDER BY createdAt').all([firmId, date]);
    const payments = db.prepare('SELECT * FROM payments WHERE firmId=? AND paymentDate=? ORDER BY createdAt').all([firmId, date]);
    const expenses = db.prepare('SELECT * FROM expenses WHERE firmId=? AND date=? ORDER BY createdAt').all([firmId, date]);
    res.json({ success: true, data: { documents: docs, payments, expenses } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;

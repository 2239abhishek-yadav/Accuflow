import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';

const router = Router();

// GET all items
router.get('/', (req: Request, res: Response) => {
  try {
    const { firmId, type, categoryId, search, active } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });

    let query = `SELECT i.*, c.name as categoryName, u.name as unitName, u.shortName as unitShortName,
      su.name as secondaryUnitName, su.shortName as secondaryUnitShortName
      FROM items i LEFT JOIN categories c ON i.categoryId = c.id
      LEFT JOIN units u ON i.unitId = u.id
      LEFT JOIN units su ON i.secondaryUnitId = su.id
      WHERE i.firmId = ?`;
    const params: any[] = [firmId];

    if (type) { query += ' AND i.type = ?'; params.push(type); }
    if (categoryId) { query += ' AND i.categoryId = ?'; params.push(categoryId); }
    if (active !== undefined) { query += ' AND i.isActive = ?'; params.push(active === 'true' ? 1 : 0); }
    if (search) { query += ' AND i.name LIKE ?'; params.push(`%${search}%`); }
    query += ' ORDER BY i.name ASC';

    const items = db.prepare(query).all(params);
    res.json({ success: true, data: items });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET item by id
router.get('/:id', (req: Request, res: Response) => {
  try {
    const item = db.prepare(`SELECT i.*, c.name as categoryName, u.name as unitName, u.shortName as unitShortName,
      su.name as secondaryUnitName, su.shortName as secondaryUnitShortName
      FROM items i LEFT JOIN categories c ON i.categoryId = c.id
      LEFT JOIN units u ON i.unitId = u.id
      LEFT JOIN units su ON i.secondaryUnitId = su.id
      WHERE i.id = ?`).get(req.params.id);
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json({ success: true, data: item });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST create item
router.post('/', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    const {
      firmId, name, type = 'PRODUCT', hsnCode, itemCode, description, imageUrl,
      categoryId, unitId, secondaryUnitId, conversionFactor = 1,
      salePrice = 0, salePriceTaxInclusive = 0,
      saleDiscount = 0, saleDiscountType = 'percentage',
      purchasePrice = 0, purchasePriceTaxInclusive = 0,
      taxRate = '0', openingStock = 0, minStockLevel = 0,
      location, batchNumber, expiryDate,
      enableBatchTracking = 0, enableSerialTracking = 0,
      isActive = 1, isFavorite = 0, allowNegativeStock = 0
    } = req.body;

    if (!firmId || !name) return res.status(400).json({ error: 'firmId and name are required' });

    // Unit 2 (secondary/larger unit) is optional, but if provided it must have a
    // sensible conversion quantity into Unit 1 (base) — e.g. 1 Strip = 10 Tablets.
    const convFactor = secondaryUnitId ? (parseFloat(conversionFactor) || 1) : 1;
    if (secondaryUnitId && convFactor <= 0) {
      return res.status(400).json({ error: 'Conversion quantity must be greater than 0' });
    }

    db.prepare(`
      INSERT INTO items (id, firmId, name, type, hsnCode, itemCode, description, imageUrl,
        categoryId, unitId, secondaryUnitId, conversionFactor,
        salePrice, salePriceTaxInclusive, saleDiscount, saleDiscountType,
        purchasePrice, purchasePriceTaxInclusive, taxRate, openingStock, currentStock,
        minStockLevel, location, batchNumber, expiryDate,
        enableBatchTracking, enableSerialTracking, isActive, isFavorite, allowNegativeStock,
        createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, firmId, name, type, hsnCode, itemCode, description, imageUrl,
      categoryId, unitId, secondaryUnitId || null, convFactor,
      salePrice, salePriceTaxInclusive ? 1 : 0,
      saleDiscount, saleDiscountType, purchasePrice, purchasePriceTaxInclusive ? 1 : 0,
      taxRate, openingStock, openingStock, minStockLevel, location, batchNumber, expiryDate,
      enableBatchTracking ? 1 : 0, enableSerialTracking ? 1 : 0,
      isActive ? 1 : 0, isFavorite ? 1 : 0, allowNegativeStock ? 1 : 0, now, now);

    const item = db.prepare('SELECT * FROM items WHERE id = ?').get(id);
    res.status(201).json({ success: true, data: item });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update item
router.put('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const {
      name, type, hsnCode, itemCode, description, imageUrl,
      categoryId, unitId, secondaryUnitId, conversionFactor,
      salePrice, salePriceTaxInclusive,
      saleDiscount, saleDiscountType, purchasePrice, purchasePriceTaxInclusive,
      taxRate, minStockLevel, location, batchNumber, expiryDate,
      enableBatchTracking, enableSerialTracking, isActive, isFavorite, allowNegativeStock
    } = req.body;

    const convFactor = secondaryUnitId ? (parseFloat(conversionFactor) || 1) : 1;
    if (secondaryUnitId && convFactor <= 0) {
      return res.status(400).json({ error: 'Conversion quantity must be greater than 0' });
    }

    db.prepare(`
      UPDATE items SET name=?, type=?, hsnCode=?, itemCode=?, description=?, imageUrl=?,
        categoryId=?, unitId=?, secondaryUnitId=?, conversionFactor=?,
        salePrice=?, salePriceTaxInclusive=?, saleDiscount=?,
        saleDiscountType=?, purchasePrice=?, purchasePriceTaxInclusive=?, taxRate=?,
        minStockLevel=?, location=?, batchNumber=?, expiryDate=?,
        enableBatchTracking=?, enableSerialTracking=?, isActive=?, isFavorite=?,
        allowNegativeStock=?, updatedAt=? WHERE id=?
    `).run(name, type, hsnCode, itemCode, description, imageUrl,
      categoryId, unitId, secondaryUnitId || null, convFactor,
      salePrice, salePriceTaxInclusive ? 1 : 0,
      saleDiscount, saleDiscountType, purchasePrice, purchasePriceTaxInclusive ? 1 : 0,
      taxRate, minStockLevel, location, batchNumber, expiryDate,
      enableBatchTracking ? 1 : 0, enableSerialTracking ? 1 : 0,
      isActive ? 1 : 0, isFavorite ? 1 : 0, allowNegativeStock ? 1 : 0, now, req.params.id);

    const item = db.prepare('SELECT * FROM items WHERE id = ?').get(req.params.id);
    res.json({ success: true, data: item });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE item
router.delete('/:id', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE items SET isActive = 0, updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true, message: 'Item deactivated' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET stock summary
router.get('/stock/summary', (req: Request, res: Response) => {
  try {
    const { firmId } = req.query;
    const items = db.prepare(`
      SELECT id, name, currentStock, minStockLevel, salePrice, purchasePrice
      FROM items WHERE firmId = ? AND type = 'PRODUCT' AND isActive = 1
      ORDER BY name ASC
    `).all([firmId]);
    res.json({ success: true, data: items });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

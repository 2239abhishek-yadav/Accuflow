import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
import {
  getAllModuleSettings, getModuleSettings,
  getVisibilitySettings, setVisibilityBulk, VISIBILITY_MODULES,
} from '../lib/moduleSettings';

const router = Router();

// GET all settings for a firm
router.get('/:firmId', (req: Request, res: Response) => {
  try {
    const settings = db.prepare('SELECT * FROM firm_settings WHERE firmId = ?').all(req.params.firmId);
    const obj: any = {};
    for (const s of settings as any[]) {
      if (!obj[s.settingType]) obj[s.settingType] = {};
      obj[s.settingType][s.settingKey] = s.settingValue;
    }
    res.json({ success: true, data: obj });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// PUT update general settings
router.put('/:firmId', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const settings = req.body;
    for (const [type, values] of Object.entries(settings)) {
      for (const [key, value] of Object.entries(values as any)) {
        const existing = db.prepare('SELECT id FROM firm_settings WHERE firmId = ? AND settingType = ? AND settingKey = ?').get(req.params.firmId, type, key);
        if (existing) {
          db.prepare('UPDATE firm_settings SET settingValue = ?, updatedAt = ? WHERE firmId = ? AND settingType = ? AND settingKey = ?').run(String(value), now, req.params.firmId, type, key);
        } else {
          db.prepare('INSERT INTO firm_settings (id, firmId, settingType, settingKey, settingValue, updatedAt) VALUES (?, ?, ?, ?, ?, ?)').run(uuidv4(), req.params.firmId, type, key, String(value), now);
        }
      }
    }
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ── Feature-toggle (Multi-Series, Units, Discounts) ──────────────────────────

// GET all module feature settings at once
router.get('/:firmId/modules', (req: Request, res: Response) => {
  try { res.json({ success: true, data: getAllModuleSettings(req.params.firmId) }); }
  catch (err: any) { res.status(500).json({ error: err.message }); }
});

// GET a single module's feature settings
router.get('/:firmId/modules/:moduleKey', (req: Request, res: Response) => {
  try { res.json({ success: true, data: getModuleSettings(req.params.firmId, req.params.moduleKey) }); }
  catch (err: any) { res.status(500).json({ error: err.message }); }
});

// PUT toggle a module's feature settings
router.put('/:firmId/modules/:moduleKey', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const { firmId, moduleKey } = req.params;
    const { multiSeriesEnabled, unitsEnabled, itemDiscountEnabled, billDiscountEnabled } = req.body;

    const upsert = (key: string, value: boolean) => {
      const existing = db.prepare('SELECT id FROM firm_settings WHERE firmId = ? AND settingType = ? AND settingKey = ?').get(firmId, moduleKey, key);
      if (existing) {
        db.prepare('UPDATE firm_settings SET settingValue = ?, updatedAt = ? WHERE firmId = ? AND settingType = ? AND settingKey = ?').run(String(value), now, firmId, moduleKey, key);
      } else {
        db.prepare('INSERT INTO firm_settings (id, firmId, settingType, settingKey, settingValue, updatedAt) VALUES (?, ?, ?, ?, ?, ?)').run(uuidv4(), firmId, moduleKey, key, String(value), now);
      }
    };

    if (multiSeriesEnabled !== undefined)  upsert('multiSeriesEnabled',  !!multiSeriesEnabled);
    if (unitsEnabled !== undefined)         upsert('unitsEnabled',         !!unitsEnabled);
    if (itemDiscountEnabled !== undefined)  upsert('itemDiscountEnabled',  !!itemDiscountEnabled);
    if (billDiscountEnabled !== undefined)  upsert('billDiscountEnabled',  !!billDiscountEnabled);

    res.json({ success: true, data: getModuleSettings(firmId, moduleKey) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// ── Visibility (show/hide entire nav sections) ────────────────────────────────

/**
 * GET /settings/:firmId/visibility
 * Returns a map of moduleKey → boolean (true = visible / enabled).
 * Missing keys default to true (all modules are visible by default).
 */
router.get('/:firmId/visibility', (req: Request, res: Response) => {
  try {
    res.json({ success: true, data: getVisibilitySettings(req.params.firmId) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

/**
 * PUT /settings/:firmId/visibility
 * Body: { moduleKey: boolean, ... }  (partial update — only sent keys are changed)
 * Unknown keys are silently ignored.
 */
router.put('/:firmId/visibility', (req: Request, res: Response) => {
  try {
    const { firmId } = req.params;
    const updates: any = {};
    for (const key of VISIBILITY_MODULES) {
      if (key in req.body && typeof req.body[key] === 'boolean') {
        updates[key] = req.body[key];
      }
    }
    setVisibilityBulk(firmId, updates);
    res.json({ success: true, data: getVisibilitySettings(firmId) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

/**
 * PUT /settings/:firmId/visibility/:moduleKey
 * Body: { visible: boolean }
 * Convenience endpoint for toggling a single module.
 */
router.put('/:firmId/visibility/:moduleKey', (req: Request, res: Response) => {
  try {
    const { firmId, moduleKey } = req.params;
    if (!(VISIBILITY_MODULES as readonly string[]).includes(moduleKey)) {
      return res.status(400).json({ error: `Unknown visibility module: ${moduleKey}` });
    }
    const visible = req.body.visible !== undefined ? !!req.body.visible : !(getVisibilitySettings(firmId) as any)[moduleKey];
    setVisibilityBulk(firmId, { [moduleKey]: visible } as any);
    res.json({ success: true, data: getVisibilitySettings(firmId) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;

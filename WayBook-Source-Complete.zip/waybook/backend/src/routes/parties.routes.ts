import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db } from '../lib/db';
import { validateGSTIN, validateMobile } from '../lib/validators';

const router = Router();

router.get('/', (req: Request, res: Response) => {
  try {
    const { firmId, type, search, groupId } = req.query;
    if (!firmId) return res.status(400).json({ error: 'firmId required' });
    let q = 'SELECT p.*, g.name as groupName FROM parties p LEFT JOIN groups g ON p.groupId = g.id WHERE p.firmId = ? AND p.isActive = 1';
    const params: any[] = [firmId];
    if (type) { q += ' AND p.type = ?'; params.push(type); }
    if (groupId) { q += ' AND p.groupId = ?'; params.push(groupId); }
    if (search) { q += ' AND (p.name LIKE ? OR p.phone LIKE ? OR p.gstin LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    q += ' ORDER BY p.name ASC';
    const parties = db.prepare(q).all(params);
    res.json({ success: true, data: parties });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.get('/:id', (req: Request, res: Response) => {
  try {
    const party = db.prepare('SELECT * FROM parties WHERE id = ?').get(req.params.id);
    if (!party) return res.status(404).json({ error: 'Party not found' });
    // Calculate balance
    const salesTotal = (db.prepare("SELECT COALESCE(SUM(total),0) as total FROM documents WHERE partyId=? AND documentType='sale_invoice' AND isDeleted=0").get(req.params.id) as any)?.total || 0;
    const purchasesTotal = (db.prepare("SELECT COALESCE(SUM(total),0) as total FROM documents WHERE partyId=? AND documentType='purchase_invoice' AND isDeleted=0").get(req.params.id) as any)?.total || 0;
    const paymentsIn = (db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE partyId=? AND type='payment_in'").get(req.params.id) as any)?.total || 0;
    const paymentsOut = (db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE partyId=? AND type='payment_out'").get(req.params.id) as any)?.total || 0;
    res.json({ success: true, data: { ...party as any, salesTotal, purchasesTotal, paymentsIn, paymentsOut } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.post('/', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    let { firmId, name, type = 'customer', phone, email, gstin, pan, address, city, state, pincode, groupId, creditLimit = 0, openingBalance = 0 } = req.body;
    if (!firmId || !name) return res.status(400).json({ error: 'firmId and name required' });

    const gstinCheck = validateGSTIN(gstin);
    if (!gstinCheck.valid) return res.status(400).json({ error: gstinCheck.error });
    gstin = gstinCheck.value;

    const mobileCheck = validateMobile(phone);
    if (!mobileCheck.valid) return res.status(400).json({ error: mobileCheck.error });
    phone = mobileCheck.value;

    db.prepare('INSERT INTO parties (id, firmId, name, type, phone, email, gstin, pan, address, city, state, pincode, groupId, creditLimit, openingBalance, isActive, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)').run(id, firmId, name, type, phone, email, gstin, pan, address, city, state, pincode, groupId, creditLimit, openingBalance, now, now);
    res.status(201).json({ success: true, data: db.prepare('SELECT * FROM parties WHERE id = ?').get(id) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.put('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    let { name, type, phone, email, gstin, pan, address, city, state, pincode, groupId, creditLimit, openingBalance, isActive } = req.body;

    const gstinCheck = validateGSTIN(gstin);
    if (!gstinCheck.valid) return res.status(400).json({ error: gstinCheck.error });
    gstin = gstinCheck.value;

    const mobileCheck = validateMobile(phone);
    if (!mobileCheck.valid) return res.status(400).json({ error: mobileCheck.error });
    phone = mobileCheck.value;

    db.prepare('UPDATE parties SET name=?, type=?, phone=?, email=?, gstin=?, pan=?, address=?, city=?, state=?, pincode=?, groupId=?, creditLimit=?, openingBalance=?, isActive=?, updatedAt=? WHERE id=?').run(name, type, phone, email, gstin, pan, address, city, state, pincode, groupId, creditLimit, openingBalance, isActive ? 1 : 0, now, req.params.id);
    res.json({ success: true, data: db.prepare('SELECT * FROM parties WHERE id = ?').get(req.params.id) });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

router.delete('/:id', (req: Request, res: Response) => {
  try {
    db.prepare('UPDATE parties SET isActive = 0, updatedAt = ? WHERE id = ?').run(new Date().toISOString(), req.params.id);
    res.json({ success: true });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Party statement
router.get('/:id/statement', (req: Request, res: Response) => {
  try {
    const { startDate, endDate } = req.query;
    let q = 'SELECT * FROM documents WHERE partyId = ? AND isDeleted = 0';
    const params: any[] = [req.params.id];
    if (startDate) { q += ' AND documentDate >= ?'; params.push(startDate); }
    if (endDate) { q += ' AND documentDate <= ?'; params.push(endDate); }
    q += ' ORDER BY documentDate ASC';
    const docs = db.prepare(q).all(params);
    const payments = db.prepare('SELECT * FROM payments WHERE partyId = ? ORDER BY paymentDate ASC').all(req.params.id);
    res.json({ success: true, data: { documents: docs, payments } });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

// Party Ledger — opening balance + running balance across all documents & payments, bill-wise.
router.get('/:id/ledger', (req: Request, res: Response) => {
  try {
    const party = db.prepare('SELECT * FROM parties WHERE id = ?').get(req.params.id) as any;
    if (!party) return res.status(404).json({ error: 'Party not found' });

    const docs = (db.prepare(
      `SELECT id, documentType, documentNumber, documentDate as date, total, paidAmount, balanceAmount, status
       FROM documents WHERE partyId = ? AND isDeleted = 0 ORDER BY documentDate ASC, createdAt ASC`
    ).all(req.params.id) as any[]).map(d => ({
      ...d,
      kind: 'document',
      debit: ['sale_invoice', 'purchase_return'].includes(d.documentType) ? d.total : 0,
      credit: ['purchase_invoice', 'sale_return'].includes(d.documentType) ? d.total : 0,
    }));

    const payments = (db.prepare(
      `SELECT id, type, paymentDate as date, amount, paymentMethod, reference, description
       FROM payments WHERE partyId = ? ORDER BY paymentDate ASC, createdAt ASC`
    ).all(req.params.id) as any[]).map(p => ({
      ...p,
      kind: 'payment',
      debit: p.type === 'payment_out' ? p.amount : 0,
      credit: p.type === 'payment_in' ? p.amount : 0,
    }));

    const entries = [...docs, ...payments].sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let running = party.openingBalanceType === 'credit' ? -(party.openingBalance || 0) : (party.openingBalance || 0);
    const ledger = entries.map(e => {
      running = +(running + e.debit - e.credit).toFixed(2);
      return { ...e, runningBalance: running };
    });

    const outstandingBills = db.prepare(
      `SELECT id, documentType, documentNumber, documentDate, total, paidAmount, balanceAmount, status
       FROM documents WHERE partyId = ? AND isDeleted = 0 AND balanceAmount > 0 AND status NOT IN ('cancelled','draft')
       ORDER BY documentDate ASC`
    ).all(req.params.id);

    res.json({
      success: true,
      data: {
        openingBalance: party.openingBalanceType === 'credit' ? -(party.openingBalance || 0) : (party.openingBalance || 0),
        currentBalance: running,
        outstandingBills,
        ledger
      }
    });
  } catch (err: any) { res.status(500).json({ error: err.message }); }
});

export default router;

import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { db, seedDefaultData } from '../lib/db';
import { validateGSTIN, validateMobile } from '../lib/validators';

const router = Router();

// GET all firms
router.get('/', (req: Request, res: Response) => {
  try {
    const firms = db.prepare('SELECT * FROM firms ORDER BY createdAt DESC').all();
    res.json({ success: true, data: firms });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET firm by id
router.get('/:id', (req: Request, res: Response) => {
  try {
    const firm = db.prepare('SELECT * FROM firms WHERE id = ?').get(req.params.id);
    if (!firm) return res.status(404).json({ error: 'Firm not found' });
    res.json({ success: true, data: firm });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST create firm
router.post('/', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    const id = uuidv4();
    let {
      name, legalName, phone, email, address, city, state, pincode,
      gstin, pan, tan, currency, financialYear, invoicePrefix
    } = req.body;

    const gstinCheck = validateGSTIN(gstin);
    if (!gstinCheck.valid) return res.status(400).json({ error: gstinCheck.error });
    gstin = gstinCheck.value;

    const mobileCheck = validateMobile(phone);
    if (!mobileCheck.valid) return res.status(400).json({ error: mobileCheck.error });
    phone = mobileCheck.value;

    db.prepare(`
      INSERT INTO firms (id, name, legalName, phone, email, address, city, state, pincode,
        gstin, pan, tan, currency, financialYear, invoicePrefix, invoiceNumber, createdAt, updatedAt)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(id, name, legalName, phone, email, address, city, state, pincode,
      gstin, pan, tan, currency || 'INR', financialYear || '2024-25', invoicePrefix || 'INV', now, now);

    // Seed default data (units, categories)
    seedDefaultData(id);

    const firm = db.prepare('SELECT * FROM firms WHERE id = ?').get(id);
    res.status(201).json({ success: true, data: firm });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update firm
router.put('/:id', (req: Request, res: Response) => {
  try {
    const now = new Date().toISOString();
    let {
      name, legalName, phone, email, address, city, state, pincode,
      gstin, pan, tan, currency, financialYear, invoicePrefix, logoUrl
    } = req.body;

    const gstinCheck = validateGSTIN(gstin);
    if (!gstinCheck.valid) return res.status(400).json({ error: gstinCheck.error });
    gstin = gstinCheck.value;

    const mobileCheck = validateMobile(phone);
    if (!mobileCheck.valid) return res.status(400).json({ error: mobileCheck.error });
    phone = mobileCheck.value;

    db.prepare(`
      UPDATE firms SET name=?, legalName=?, phone=?, email=?, address=?, city=?, state=?,
        pincode=?, gstin=?, pan=?, tan=?, currency=?, financialYear=?, invoicePrefix=?,
        logoUrl=?, updatedAt=? WHERE id=?
    `).run(name, legalName, phone, email, address, city, state, pincode,
      gstin, pan, tan, currency, financialYear, invoicePrefix, logoUrl, now, req.params.id);

    const firm = db.prepare('SELECT * FROM firms WHERE id = ?').get(req.params.id);
    res.json({ success: true, data: firm });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE firm
router.delete('/:id', (req: Request, res: Response) => {
  try {
    db.prepare('DELETE FROM firms WHERE id = ?').run(req.params.id);
    res.json({ success: true, message: 'Firm deleted' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;

import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { db, initializeDatabase } from './lib/db';
import router from './routes';

const app = express();
const PORT = process.env.PORT || 4100;

// Middleware
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '30mb' }));
app.use(express.urlencoded({ limit: '30mb', extended: true }));

// Uploads directory
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
app.use('/uploads', express.static(uploadDir));

// API Routes
app.use('/api', router);

// Health check
app.get('/', (req, res) => {
  res.json({
    name: 'WayBook',
    status: 'running',
    version: '1.0.0',
    time: new Date().toISOString(),
  });
});

// 404 handler
app.use((req: express.Request, res: express.Response) => {
  res.status(404).json({ error: 'Route not found' });
});

// Error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error('[Error]', err);
  res.status(err.status || 500).json({ error: err.message || 'Internal Server Error' });
});

// Initialize DB and start
try {
  initializeDatabase();
  app.listen(PORT, () => {
    console.log(`✅ WayBook Server running at http://localhost:${PORT}`);
  });
} catch (err) {
  console.error('❌ Failed to initialize:', err);
  process.exit(1);
}

export default app;

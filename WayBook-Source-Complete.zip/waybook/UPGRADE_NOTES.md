# WayBook — Multi-Series, Two Units + Conversion, Module Settings Upgrade

This upgrade builds on the existing Dashboard/Series/Validation upgrade already in this
codebase. Everything below is additive — no existing table, column, report, print format,
or API response shape was removed or renamed.

## 1. What's new

### Multi-Series (already existed, now module-aware)
- The `series` table and `/api/series` CRUD already supported independent numbering
  series per document type (Sales Invoice, Purchase Invoice, Quotation, Sales Order,
  Purchase Order, Challan, Returns, etc.) — at least 2 series per type were already
  possible.
- **New:** each module can now independently **enable/disable** Multi-Series. When
  disabled for a module, that module ignores any `seriesId` and always falls back to
  legacy per-firm numbering — even if series still exist for it.

### Two Units + Conversion (new)
- Every item now supports **Unit 1 (base)** and an optional **Unit 2 (secondary)**,
  with a user-defined **conversion quantity** (e.g. 1 Strip = 10 Tablets, 1 Box = 20
  Bottles).
- Document lines (Sales Invoice, Purchase Invoice, Quotation, Sales Order, Purchase
  Order, Challan, Returns) can be sold/purchased in **either unit**.
- Stock (`items.currentStock`) is always tracked in Unit 1 terms. Whatever unit a line
  used, the backend converts it to base-unit quantity (`baseQuantity`) before touching
  stock — so stock stays accurate regardless of which unit was used on a given
  transaction, and regardless of which unit an item is later re-sold in.
- Editing/re-saving a document correctly reverses the old stock impact (using the
  `baseQuantity` that was stored on the line at save time) and re-applies the new one —
  this now also fixes a pre-existing gap where editing a Sale/Purchase Return never
  updated stock at all.

### Module Settings (new)
- Every relevant module (all document types + Items) now has its own settings area
  where **Multi-Series** and **Units & Conversion** can be toggled independently,
  without affecting any other module.
- Two ways to reach it:
  1. A gear icon inside each module's own screen (Sales Invoice, Items, etc.) — toggle
     without leaving the module.
  2. Settings → **Module Settings** tab — a single table of every module with both
     toggles, for a bird's-eye view.
- Defaults to **enabled** for every module on upgrade, so nothing that already worked
  (e.g. existing Multiple Series) is silently turned off.

## 2. Files changed

Backend:
- `backend/src/lib/db.ts` — added `items.secondaryUnitId`, `items.conversionFactor`;
  added `document_items.unitId`, `document_items.isSecondaryUnit`,
  `document_items.baseQuantity`. All via additive `ALTER TABLE` migrations that run
  automatically on next backend start, with safe backfill for existing rows.
- `backend/src/lib/moduleSettings.ts` — **new** — reads/writes per-module
  `multiSeriesEnabled` / `unitsEnabled` using the existing generic `firm_settings`
  table (no new table needed).
- `backend/src/routes/settings.routes.ts` — added
  `GET /settings/:firmId/modules`, `GET/PUT /settings/:firmId/modules/:moduleKey`.
- `backend/src/routes/items.routes.ts` — Unit 2 + conversion factor on create/update,
  validation, and joined unit names on read.
- `backend/src/routes/documents.routes.ts` — `resolveLineUnit()` converts a line's
  selected unit into base-unit quantity for stock; series resolution now respects the
  `multiSeriesEnabled` module setting; stock reversal/reapply on edit now uses
  `baseQuantity` and also correctly handles Sale/Purchase Returns.

Frontend (`frontend/src/components/WayBook.tsx`):
- `useModuleSettings()` hook + `ModuleSettingsButton` popover (gear icon, per module).
- `Items` — Unit 2 + conversion fields in the item form, units column in the table,
  module settings gear button.
- `Documents` — per-line unit selector (Unit 1 / Unit 2) with automatic price rescaling
  when switching units, series selector now hidden when Multi-Series is disabled for
  that module, module settings gear button.
- `SettingsPage` — new **Module Settings** tab listing every module with Multi-Series /
  Units & Conversion toggles.

## 3. Database changes

- New columns: `items.secondaryUnitId`, `items.conversionFactor`,
  `document_items.unitId`, `document_items.isSecondaryUnit`,
  `document_items.baseQuantity`.
- No existing columns, tables, or data were altered or removed.
- Migrations run automatically on next backend start (`initializeDatabase()` in
  `db.ts`), same pattern as the existing `documents.seriesId` migration.

## 4. APIs added/modified

Added:
- `GET /api/settings/:firmId/modules`
- `GET /api/settings/:firmId/modules/:moduleKey`
- `PUT /api/settings/:firmId/modules/:moduleKey`

Modified (backward compatible):
- `POST/PUT /api/items` — now accepts optional `secondaryUnitId`, `conversionFactor`;
  `GET /api/items` and `GET /api/items/:id` now also return `secondaryUnitName` /
  `secondaryUnitShortName`.
- `POST /api/documents`, `PUT /api/documents/:id` — line items now accept optional
  `unitId`; stock math now uses the resolved base-unit quantity instead of the raw
  line quantity.
- `GET /api/documents/next-number/:type` — now respects the module's
  `multiSeriesEnabled` setting.

## 5. What was NOT touched

- No existing invoice/transaction numbers were changed.
- Firms that never create a series, or that disable Multi-Series for a module, keep
  using the original single-counter numbering exactly as before.
- Items without a Unit 2 configured behave exactly as before (quantity = base-unit
  quantity, unchanged stock math).
- No existing tables, columns, reports, or print formats were removed or renamed.
- Permission/auth system was not modified.

## 6. Manual steps required after unzipping

1. `npm run install:all`
2. `cd backend && npm run build`
3. `npm run dev` (or `npx electron-builder` for a new installer)
4. Existing `data/waybook.db` — back it up before first run of the new backend; all
   migrations are additive-only but backups are cheap insurance.

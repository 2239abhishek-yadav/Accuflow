@echo off
echo ============================================
echo  WayBook - Windows Build Script
echo ============================================
echo.

echo [1/4] Installing root dependencies...
call npm install
if errorlevel 1 goto error

echo.
echo [2/4] Installing and building backend...
cd backend
call npm install
if errorlevel 1 goto error
call npm run build
if errorlevel 1 goto error
cd ..

echo.
echo [3/4] Installing and building frontend...
cd frontend
call npm install
if errorlevel 1 goto error
call npm run build
if errorlevel 1 goto error
cd ..

echo.
echo [4/4] Packaging Windows installer...
call npx electron-builder --win --x64
if errorlevel 1 goto error

echo.
echo ============================================
echo  BUILD COMPLETE!
echo  Installer: dist-electron\WayBook Setup 1.0.0.exe
echo ============================================
goto end

:error
echo.
echo BUILD FAILED. Check errors above.
exit /b 1

:end

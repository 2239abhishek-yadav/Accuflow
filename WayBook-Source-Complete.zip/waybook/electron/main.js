const { app, BrowserWindow, ipcMain, Tray, Menu, nativeImage, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');
const http = require('http');

let mainWindow = null;
let tray = null;
let backendProcess = null;
const BACKEND_PORT = 4100;

const isDev = process.env.NODE_ENV === 'development';

function getResourcePath(...segments) {
  if (isDev) {
    return path.join(__dirname, '..', ...segments);
  }
  // In packaged app, resources are at process.resourcesPath
  return path.join(process.resourcesPath, ...segments);
}

function getUserDataPath(...segments) {
  return path.join(app.getPath('userData'), ...segments);
}

function startBackend() {
  if (isDev) return;

  const backendScript = getResourcePath('backend', 'dist', 'server.js');
  const nodeExec = process.execPath; // Use Electron's bundled Node runtime

  const env = {
    ...process.env,
    PORT: String(BACKEND_PORT),
    NODE_ENV: 'production',
    // Tell the backend where to store its database (writable user data dir)
    DB_PATH: getUserDataPath('data'),
    // Point native module to packaged location
    NODE_PATH: getResourcePath('backend', 'node_modules'),
  };

  console.log('[Main] Starting backend:', backendScript);
  console.log('[Main] Node:', nodeExec);
  console.log('[Main] DB path:', env.DB_PATH);

  backendProcess = spawn(nodeExec, [backendScript], {
    env,
    cwd: getResourcePath('backend'),
  });

  backendProcess.stdout.on('data', d => console.log('[Backend]', d.toString().trim()));
  backendProcess.stderr.on('data', d => console.error('[Backend ERR]', d.toString().trim()));
  backendProcess.on('exit', code => console.log('[Backend] exited', code));
}

function waitForBackend(port, timeout = 15000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const check = () => {
      const req = http.get(`http://localhost:${port}/`, res => {
        res.resume();
        resolve();
      });
      req.on('error', () => {
        if (Date.now() - start > timeout) return reject(new Error('Backend timeout'));
        setTimeout(check, 300);
      });
      req.setTimeout(500, () => { req.destroy(); });
    };
    check();
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#0f172a',
      symbolColor: '#94a3b8',
      height: 36,
    },
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    backgroundColor: '#0f172a',
    show: false,
  });

  try {
    const iconPath = isDev
      ? path.join(__dirname, '../assets/icon.png')
      : path.join(process.resourcesPath, 'assets', 'icon.png');
    mainWindow.setIcon(iconPath);
  } catch (e) { /* icon optional */ }

  const startUrl = isDev
    ? `http://localhost:3000`
    : `file://${getResourcePath('frontend', 'out', 'index.html')}`;

  console.log('[Main] Loading:', startUrl);
  mainWindow.loadURL(startUrl);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

function createTray() {
  try {
    const iconPath = isDev
      ? path.join(__dirname, '../assets/tray-icon.png')
      : path.join(process.resourcesPath, 'assets', 'tray-icon.png');
    const icon = nativeImage.createFromPath(iconPath).resize({ width: 16, height: 16 });
    tray = new Tray(icon);
    tray.setToolTip('WayBook – GST Billing Software');
    tray.setContextMenu(Menu.buildFromTemplate([
      { label: 'Open WayBook', click: () => mainWindow?.show() },
      { type: 'separator' },
      { label: 'Quit', click: () => { app.isQuiting = true; app.quit(); } },
    ]));
    tray.on('double-click', () => mainWindow?.show());
  } catch (e) {
    console.log('[Main] Tray skipped:', e.message);
  }
}

// IPC
ipcMain.handle('get-app-version', () => app.getVersion());
ipcMain.handle('get-app-path', () => app.getPath('userData'));
ipcMain.handle('get-backend-port', () => BACKEND_PORT);
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => mainWindow?.isMaximized() ? mainWindow.unmaximize() : mainWindow?.maximize());
ipcMain.on('window-close', () => mainWindow?.close());
ipcMain.on('window-hide', () => mainWindow?.hide());

app.whenReady().then(async () => {
  startBackend();
  if (!isDev) {
    try { await waitForBackend(BACKEND_PORT); } catch (e) { console.error('[Main] Backend wait failed:', e.message); }
  }
  createWindow();
  createTray();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    if (backendProcess) backendProcess.kill();
    app.quit();
  }
});
app.on('before-quit', () => { if (backendProcess) backendProcess.kill(); });

import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'WayBook - GST Billing Software',
  description: 'Complete GST Billing & Accounting Software',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

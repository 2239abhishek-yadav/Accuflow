'use client';
export { default } from '@/components/WayBook';

'use client';
import React, { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard, Package, Users, FileText, CreditCard, BarChart2,
  Settings, Plus, Search, Menu, ArrowUp, ArrowDown, TrendingUp,
  AlertCircle, ShoppingCart, Truck, Receipt, IndianRupee,
  FileCheck, FileMinus, FileSpreadsheet, Users2,
  ClipboardList, Building2, Wallet, Trash2, Edit, X, BookOpen,
  Boxes, Calculator, PieChart, DollarSign, Calendar, Store,
  ChevronDown, Tag, CheckCircle, Clock, Hash, Star, Layers,
  Award, ListOrdered, Upload, Download, FileUp, AlertTriangle, CheckSquare,
  ToggleLeft, ToggleRight, Eye, EyeOff, Sliders, TrendingDown, RefreshCw
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar
} from 'recharts';
import {
  startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth,
  startOfQuarter, endOfQuarter, subDays, subWeeks, subMonths, subQuarters,
  format as formatDate
} from 'date-fns';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4100/api';

/* ── dashboard date-range presets ───────────────────────────────────────────
   India's financial year runs Apr 1 → Mar 31. All ranges are computed client-side
   and sent to the backend as plain startDate/endDate (YYYY-MM-DD), so every report
   endpoint (dashboard, top-items, top-transactions) filters consistently. */
const ymd = (d: Date) => formatDate(d, 'yyyy-MM-dd');

function financialYearRange(offsetYears: number): { start: Date; end: Date } {
  const now = new Date();
  const currentFyStartYear = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1; // Apr=index 3
  const fyStartYear = currentFyStartYear + offsetYears;
  return { start: new Date(fyStartYear, 3, 1), end: new Date(fyStartYear + 1, 2, 31) };
}

const DATE_PRESETS: Record<string, () => { start: Date; end: Date }> = {
  today:        () => ({ start: startOfDay(new Date()), end: endOfDay(new Date()) }),
  yesterday:    () => ({ start: startOfDay(subDays(new Date(), 1)), end: endOfDay(subDays(new Date(), 1)) }),
  this_week:    () => ({ start: startOfWeek(new Date()), end: endOfWeek(new Date()) }),
  last_week:    () => ({ start: startOfWeek(subWeeks(new Date(), 1)), end: endOfWeek(subWeeks(new Date(), 1)) }),
  this_month:   () => ({ start: startOfMonth(new Date()), end: endOfMonth(new Date()) }),
  last_month:   () => ({ start: startOfMonth(subMonths(new Date(), 1)), end: endOfMonth(subMonths(new Date(), 1)) }),
  this_quarter: () => ({ start: startOfQuarter(new Date()), end: endOfQuarter(new Date()) }),
  last_quarter: () => ({ start: startOfQuarter(subQuarters(new Date(), 1)), end: endOfQuarter(subQuarters(new Date(), 1)) }),
  this_fy:      () => financialYearRange(0),
  last_fy:      () => financialYearRange(-1),
};
const DATE_PRESET_LABELS: [string, string][] = [
  ['today', 'Today'], ['yesterday', 'Yesterday'],
  ['this_week', 'This Week'], ['last_week', 'Last Week'],
  ['this_month', 'This Month'], ['last_month', 'Last Month'],
  ['this_quarter', 'This Quarter'], ['last_quarter', 'Last Quarter'],
  ['this_fy', 'This Financial Year'], ['last_fy', 'Last Financial Year'],
  ['custom', 'Custom Date Range'],
];

/* ── helpers ─────────────────────────────────────────────────────────────── */
const fmt = (n: number = 0) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const fmtN = (n: number = 0) => new Intl.NumberFormat('en-IN').format(n);
const todayStr = () => new Date().toISOString().slice(0, 10);

/* ── validation (mirrors backend/src/lib/validators.ts — frontend gives instant
   feedback, backend is the source of truth and re-validates on every save) ── */
const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
function gstinError(raw: string): string {
  if (!raw || !raw.trim()) return '';
  const v = raw.trim().toUpperCase();
  if (v.length !== 15) return `GSTIN must be exactly 15 characters (currently ${v.length})`;
  if (!GSTIN_REGEX.test(v)) return 'Invalid GSTIN format. Expected: 22AAAAA0000A1Z5';
  return '';
}
function mobileError(raw: string): string {
  if (!raw || !raw.trim()) return '';
  const cleaned = raw.trim().replace(/[\s\-()]/g, '');
  const digits = cleaned.startsWith('+91') ? cleaned.slice(3)
    : (cleaned.startsWith('91') && cleaned.length === 12) ? cleaned.slice(2)
    : cleaned;
  if (!/^[0-9]{10}$/.test(digits)) return 'Mobile number must be exactly 10 digits (optionally with +91)';
  if (!/^[6-9]/.test(digits)) return 'Mobile number must start with 6, 7, 8, or 9';
  return '';
}

interface ApiFetchOpts { method?: string; body?: unknown; headers?: Record<string, string>; }
async function apiFetch(path: string, opts: ApiFetchOpts = {}) {
  try {
    const init: RequestInit = {
      method: opts.method || 'GET',
      headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
      ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
    };
    const res = await fetch(`${API_BASE}${path}`, init);
    return await res.json();
  } catch (e: any) {
    return { error: e.message };
  }
}

/* ── module settings (Multi-Series / Units / Discounts) ─────────────────────
   Every relevant module can independently enable/disable all four features.
   Defaults to enabled to preserve existing behavior on upgrade. */
const MODULE_LABELS: Record<string, string> = {
  sale_invoice: 'Sales Invoice', sale_order: 'Sale Order', sale_return: 'Sales Return',
  sale_quotation: 'Quotation', delivery_challan: 'Delivery Challan',
  purchase_invoice: 'Purchase Invoice', purchase_order: 'Purchase Order', purchase_return: 'Purchase Return',
  items: 'Items',
};
const MODULE_KEYS = Object.keys(MODULE_LABELS);

// ── Visibility keys — every nav item that can be hidden/shown ─────────────
const ALL_VISIBILITY_KEYS = [
  'items', 'godowns',
  'sale_invoice', 'sale_order', 'sale_return', 'sale_quotation', 'delivery_challan', 'payment_in',
  'purchase_invoice', 'purchase_order', 'purchase_return', 'payment_out',
  'expenses', 'accounting_entries', 'bank',
  'employees', 'attendance', 'payroll',
  'report_pl', 'report_stock', 'report_outstanding', 'report_daybook', 'report_gst',
  'parties', 'ledger',
] as const;

type VisibilityKey = typeof ALL_VISIBILITY_KEYS[number];
type VisibilityMap = Record<VisibilityKey, boolean>;

// All modules visible by default
const DEFAULT_VISIBILITY: VisibilityMap = Object.fromEntries(
  ALL_VISIBILITY_KEYS.map(k => [k, true])
) as VisibilityMap;

// Human-readable labels for every visibility module
const VISIBILITY_LABELS: Record<VisibilityKey, string> = {
  items: 'Items', godowns: 'Godowns / Warehouses',
  sale_invoice: 'Sales Invoice', sale_order: 'Sale Order', sale_return: 'Sale Return',
  sale_quotation: 'Quotation', delivery_challan: 'Delivery Challan', payment_in: 'Payment In',
  purchase_invoice: 'Purchase Bill', purchase_order: 'Purchase Order',
  purchase_return: 'Purchase Return', payment_out: 'Payment Out',
  expenses: 'Expenses', accounting_entries: 'Accounting Entries', bank: 'Banking',
  employees: 'Employees', attendance: 'Attendance', payroll: 'Payroll',
  report_pl: 'Profit & Loss', report_stock: 'Stock Summary',
  report_outstanding: 'Outstanding', report_daybook: 'Day Book', report_gst: 'GST Report',
  parties: 'Parties', ledger: 'Ledger',
};

// Groups for display in Module Management
const VISIBILITY_GROUPS: { label: string; color: string; keys: VisibilityKey[] }[] = [
  { label: 'Items & Stock',   color: '#f59e0b', keys: ['items', 'godowns'] },
  { label: 'Sales',           color: '#22c55e', keys: ['sale_invoice', 'sale_order', 'sale_return', 'sale_quotation', 'delivery_challan', 'payment_in'] },
  { label: 'Purchase',        color: '#8b5cf6', keys: ['purchase_invoice', 'purchase_order', 'purchase_return', 'payment_out'] },
  { label: 'Finance',         color: '#0ea5e9', keys: ['expenses', 'accounting_entries', 'bank'] },
  { label: 'HR',              color: '#ec4899', keys: ['employees', 'attendance', 'payroll'] },
  { label: 'Reports',         color: '#14b8a6', keys: ['report_pl', 'report_stock', 'report_outstanding', 'report_daybook', 'report_gst'] },
  { label: 'Other',           color: '#64748b', keys: ['parties', 'ledger'] },
];

function useVisibility(firmId: string) {
  const [visibility, setVisibility] = useState<VisibilityMap>({ ...DEFAULT_VISIBILITY });
  const [loaded, setLoaded] = useState(false);
  const reload = useCallback(() => {
    if (!firmId) return;
    apiFetch(`/settings/${firmId}/visibility`).then(r => {
      if (r.data) setVisibility({ ...DEFAULT_VISIBILITY, ...r.data });
      setLoaded(true);
    });
  }, [firmId]);
  useEffect(() => { reload(); }, [reload]);
  return { visibility, setVisibility, reload, loaded };
}

interface ModuleSettings {
  multiSeriesEnabled: boolean;
  unitsEnabled: boolean;
  itemDiscountEnabled: boolean;
  billDiscountEnabled: boolean;
}

function useModuleSettings(firmId: string, moduleKey: string) {
  const [settings, setSettings] = useState<ModuleSettings>({
    multiSeriesEnabled: true, unitsEnabled: true, itemDiscountEnabled: true, billDiscountEnabled: true,
  });
  const reload = useCallback(() => {
    if (!firmId || !moduleKey) return;
    apiFetch(`/settings/${firmId}/modules/${moduleKey}`).then(r => { if (r.data) setSettings(r.data); });
  }, [firmId, moduleKey]);
  useEffect(() => { reload(); }, [reload]);
  return { settings, reload };
}

/* Small gear button + popover — lets a user flip any module setting without leaving it. */
function ModuleSettingsButton({ firmId, moduleKey, settings, onChange, toast, isBillingModule = false }: any) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const toggle = async (key: keyof ModuleSettings) => {
    setSaving(true);
    const r = await apiFetch(`/settings/${firmId}/modules/${moduleKey}`, {
      method: 'PUT', body: { [key]: !settings[key] },
    });
    setSaving(false);
    if (r.error) { toast?.error(r.error); return; }
    onChange(r.data);
    toast?.success('Module settings updated');
  };

  const toggles: Array<[keyof ModuleSettings, string, string]> = [
    ['multiSeriesEnabled', 'Multi-Series', 'Independent numbering series for this module'],
    ['unitsEnabled', 'Units & Conversion', 'Allow Unit 1 / Unit 2 selection on lines'],
    ...(isBillingModule ? ([
      ['itemDiscountEnabled', 'Item-Wise Discount', 'Discount column on each billing line'],
      ['billDiscountEnabled', 'Bill-Level Discount', 'Overall discount on entire bill'],
    ] as Array<[keyof ModuleSettings, string, string]>) : []),
  ];

  return (
    <div style={{ position: 'relative' }}>
      <Btn variant="ghost" size="sm" onClick={() => setOpen(p => !p)} title="Module Settings">
        <Settings size={13} />
      </Btn>
      {open && (
        <>
          <div onClick={() => setOpen(false)} style={{ position: 'fixed', inset: 0, zIndex: 998 }} />
          <div style={{ position: 'absolute', right: 0, top: '110%', zIndex: 999, width: 280,
            background: '#1e293b', border: '1px solid #334155', borderRadius: 12, padding: 14,
            boxShadow: '0 12px 32px rgba(0,0,0,.5)' }}>
            <div style={{ fontSize: 11, fontWeight: 800, color: '#64748b', textTransform: 'uppercase',
              letterSpacing: '.06em', marginBottom: 10 }}>
              {MODULE_LABELS[moduleKey] || moduleKey} Settings
            </div>
            {toggles.map(([key, label, desc]) => (
              <label key={key} style={{ display: 'flex', alignItems: 'flex-start', gap: 9, marginBottom: 10, cursor: 'pointer' }}>
                <input type="checkbox" checked={!!settings[key]}
                  disabled={saving} onChange={() => toggle(key)}
                  style={{ marginTop: 3 }} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#f8fafc' }}>{label}</div>
                  <div style={{ fontSize: 11, color: '#64748b' }}>{desc}</div>
                </div>
              </label>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ── toast ────────────────────────────────────────────────────────────────── */
type ToastType = 'success' | 'error' | 'info';
interface ToastItem { id: number; msg: string; type: ToastType; }
function useToast() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const add = useCallback((msg: string, type: ToastType = 'info') => {
    const id = Date.now() + Math.random();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500);
  }, []);
  return {
    toasts,
    removeToast: (id: number) => setToasts(p => p.filter(t => t.id !== id)),
    toast: { success: (m: string) => add(m, 'success'), error: (m: string) => add(m, 'error'), info: (m: string) => add(m, 'info') }
  };
}
function Toasts({ toasts, remove }: { toasts: ToastItem[]; remove: (id: number) => void }) {
  const colors: Record<ToastType, string> = { success: '#16a34a', error: '#dc2626', info: '#2563eb' };
  return (
    <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {toasts.map(t => (
        <div key={t.id} onClick={() => remove(t.id)}
          style={{ background: colors[t.type], color: '#fff', padding: '12px 20px', borderRadius: 10,
            cursor: 'pointer', fontSize: 14, fontWeight: 600, boxShadow: '0 4px 20px rgba(0,0,0,.4)',
            animation: 'slideIn .2s ease', maxWidth: 360 }}>
          {t.msg}
        </div>
      ))}
    </div>
  );
}

/* ── modal ───────────────────────────────────────────────────────────────── */
function Modal({ open, onClose, title, children, size = 'md' }: any) {
  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, [open]);
  if (!open) return null;
  const w: Record<string, number> = { sm: 440, md: 600, lg: 860, xl: 1120 };
  return (
    <div onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.75)', zIndex: 1000,
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ background: '#1e293b', borderRadius: 16, width: '100%', maxWidth: w[size] || 600,
        maxHeight: '92vh', overflowY: 'auto', border: '1px solid #334155' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '18px 24px', borderBottom: '1px solid #334155', position: 'sticky', top: 0,
          background: '#1e293b', zIndex: 1 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 800, color: '#f8fafc' }}>{title}</h2>
          <button onClick={onClose}
            style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', lineHeight: 0 }}>
            <X size={20} />
          </button>
        </div>
        <div style={{ padding: 24 }}>{children}</div>
      </div>
    </div>
  );
}

/* ── form primitives ─────────────────────────────────────────────────────── */
const IS: React.CSSProperties = {
  width: '100%', background: '#0f172a', border: '1px solid #334155', borderRadius: 8,
  color: '#f8fafc', padding: '10px 14px', fontSize: 14, outline: 'none', boxSizing: 'border-box',
};
const Inp = (p: React.InputHTMLAttributes<HTMLInputElement>) => <input style={IS} {...p} />;
const Sel = ({ children, ...p }: React.SelectHTMLAttributes<HTMLSelectElement> & { children: React.ReactNode }) =>
  <select style={{ ...IS, cursor: 'pointer' }} {...p}>{children}</select>;
const Txt = (p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) =>
  <textarea style={{ ...IS, resize: 'vertical', minHeight: 72 }} {...p} />;

function Field({ label, children, required, error }: any) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 700, color: '#64748b',
        marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.06em' }}>
        {label}{required && <span style={{ color: '#ef4444' }}> *</span>}
      </label>
      {children}
      {error && <div style={{ fontSize: 11, color: '#f87171', marginTop: 4, fontWeight: 600 }}>{error}</div>}
    </div>
  );
}

/* ── button ──────────────────────────────────────────────────────────────── */
function Btn({ children, variant = 'primary', size = 'md', onClick, disabled, type = 'button', style: s }: any) {
  const V: Record<string, React.CSSProperties> = {
    primary: { background: 'linear-gradient(135deg,#6366f1,#8b5cf6)', color: '#fff', border: 'none' },
    secondary: { background: '#334155', color: '#e2e8f0', border: 'none' },
    danger:  { background: '#dc2626', color: '#fff', border: 'none' },
    ghost:   { background: 'transparent', color: '#94a3b8', border: '1px solid #334155' },
    success: { background: '#16a34a', color: '#fff', border: 'none' },
  };
  const SZ: Record<string, React.CSSProperties> = {
    sm: { padding: '5px 12px', fontSize: 12 }, md: { padding: '9px 18px', fontSize: 14 }, lg: { padding: '12px 24px', fontSize: 15 }
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled}
      style={{ ...V[variant], ...SZ[size], borderRadius: 8, cursor: disabled ? 'not-allowed' : 'pointer',
        fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: 6,
        opacity: disabled ? .5 : 1, transition: 'all .15s', fontFamily: 'inherit', ...s }}>
      {children}
    </button>
  );
}

/* ── badge ───────────────────────────────────────────────────────────────── */
function Badge({ children, color = 'gray' }: { children: React.ReactNode; color?: string }) {
  const C: Record<string, React.CSSProperties> = {
    blue:   { background: '#1e3a5f', color: '#60a5fa' },
    green:  { background: '#14532d', color: '#4ade80' },
    red:    { background: '#450a0a', color: '#f87171' },
    yellow: { background: '#422006', color: '#fbbf24' },
    purple: { background: '#2e1065', color: '#a78bfa' },
    gray:   { background: '#1e293b', color: '#94a3b8' },
    orange: { background: '#431407', color: '#fb923c' },
  };
  return (
    <span style={{ ...C[color] || C.gray, padding: '3px 9px', borderRadius: 20,
      fontSize: 10, fontWeight: 800, textTransform: 'uppercase', letterSpacing: '.05em', whiteSpace: 'nowrap' }}>
      {children}
    </span>
  );
}

/* ── stat card ───────────────────────────────────────────────────────────── */
function StatCard({ label, value, icon: Icon, color, sub, trend, onClick }: any) {
  return (
    <div onClick={onClick} style={{ background: '#1e293b', borderRadius: 14, padding: '18px 20px',
      border: '1px solid #334155', display: 'flex', flexDirection: 'column', gap: 10,
      cursor: onClick ? 'pointer' : 'default', transition: 'border-color .15s' }}
      onMouseEnter={e => { if (onClick) (e.currentTarget as HTMLDivElement).style.borderColor = color; }}
      onMouseLeave={e => { if (onClick) (e.currentTarget as HTMLDivElement).style.borderColor = '#334155'; }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, color: '#64748b', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.05em' }}>{label}</span>
        <div style={{ background: color + '22', borderRadius: 10, padding: 8 }}>
          <Icon size={16} color={color} />
        </div>
      </div>
      <div style={{ fontSize: 22, fontWeight: 900, color: '#f8fafc' }}>{value}</div>
      {sub && (
        <div style={{ fontSize: 12, color: trend > 0 ? '#4ade80' : trend < 0 ? '#f87171' : '#64748b',
          display: 'flex', alignItems: 'center', gap: 3, fontWeight: 600 }}>
          {trend > 0 ? <ArrowUp size={11} /> : trend < 0 ? <ArrowDown size={11} /> : null}
          {sub}
        </div>
      )}
    </div>
  );
}

/* ── data table ──────────────────────────────────────────────────────────── */
interface Col { key: string; label: string; align?: 'left'|'right'|'center'; render?: (v: any, row: any) => React.ReactNode; }
function Table({ cols, rows, onRow, empty = 'No records found.' }: { cols: Col[]; rows: any[]; onRow?: (r: any) => void; empty?: string }) {
  return (
    <div style={{ borderRadius: 12, border: '1px solid #334155', overflow: 'hidden' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ background: '#0f172a' }}>
            {cols.map(c => (
              <th key={c.key} style={{ padding: '10px 14px', textAlign: c.align || 'left',
                fontSize: 10, fontWeight: 800, color: '#475569', textTransform: 'uppercase', letterSpacing: '.06em', whiteSpace: 'nowrap' }}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0
            ? <tr><td colSpan={cols.length} style={{ padding: 40, textAlign: 'center', color: '#475569', fontSize: 14 }}>{empty}</td></tr>
            : rows.map((row, i) => (
                <tr key={row.id || i} onClick={() => onRow?.(row)}
                  style={{ borderTop: '1px solid #1e293b', cursor: onRow ? 'pointer' : 'default',
                    transition: 'background .1s' }}
                  onMouseEnter={e => { if (onRow) (e.currentTarget as HTMLElement).style.background = '#1e293b'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = ''; }}>
                  {cols.map(c => (
                    <td key={c.key} style={{ padding: '11px 14px', fontSize: 13, color: '#e2e8f0', textAlign: c.align || 'left' }}>
                      {c.render ? c.render(row[c.key], row) : (row[c.key] ?? '—')}
                    </td>
                  ))}
                </tr>
              ))}
        </tbody>
      </table>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   SIDEBAR NAV
═══════════════════════════════════════════════════════════════════════════ */
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'ledger',    label: 'Ledger',    icon: BookOpen },
  { id: '_d1' },
  { id: 'items_group', label: 'Items & Stock', icon: Package, children: [
    { id: 'items',   label: 'Items',    icon: Package },
    { id: 'godowns', label: 'Godowns/Warehouses', icon: Store },
  ]},
  { id: 'sales_group', label: 'Sales', icon: TrendingUp, children: [
    { id: 'sale_invoice',       label: 'Sales Invoice',     icon: Receipt },
    { id: 'sale_order',         label: 'Sale Order',        icon: ShoppingCart },
    { id: 'sale_return',        label: 'Sale Return',       icon: FileMinus },
    { id: 'sale_quotation',     label: 'Quotation',         icon: FileText },
    { id: 'delivery_challan',   label: 'Delivery Challan',  icon: Truck },
    { id: 'payment_in',         label: 'Payment In',        icon: CreditCard },
  ]},
  { id: 'purchase_group', label: 'Purchase', icon: ShoppingCart, children: [
    { id: 'purchase_invoice',   label: 'Purchase Bill',     icon: FileSpreadsheet },
    { id: 'purchase_order',     label: 'Purchase Order',    icon: ClipboardList },
    { id: 'purchase_return',    label: 'Purchase Return',   icon: FileMinus },
    { id: 'payment_out',        label: 'Payment Out',       icon: Wallet },
  ]},
  { id: 'expenses', label: 'Expenses', icon: DollarSign },
  { id: 'accounting_entries', label: 'Accounting Entries', icon: FileCheck },
  { id: 'bank',     label: 'Banking', icon: Building2 },
  { id: 'hr_group', label: 'HR', icon: Users2, children: [
    { id: 'employees',  label: 'Employees',  icon: Users },
    { id: 'attendance', label: 'Attendance', icon: Calendar },
    { id: 'payroll',    label: 'Payroll',    icon: Calculator },
  ]},
  { id: '_d2' },
  { id: 'reports_group', label: 'Reports', icon: BarChart2, children: [
    { id: 'report_pl',          label: 'Profit & Loss',    icon: PieChart },
    { id: 'report_stock',       label: 'Stock Summary',    icon: Boxes },
    { id: 'report_outstanding', label: 'Outstanding',      icon: AlertCircle },
    { id: 'report_daybook',     label: 'Day Book',         icon: BookOpen },
  ]},
  { id: 'report_gst', label: 'GST', icon: FileCheck },
  { id: '_d3' },
  { id: 'parties',  label: 'Parties',  icon: Users },
  { id: 'settings', label: 'Settings',    icon: Settings },
];

function Sidebar({ active, setActive, firm, collapsed, visibility }: any) {
  const [open, setOpen] = useState<Record<string, boolean>>({ sales_group: true });
  const toggle = (id: string) => setOpen(p => ({ ...p, [id]: !p[id] }));
  const vis: VisibilityMap = visibility || DEFAULT_VISIBILITY;

  // Filter nav items based on visibility settings.
  // Groups are shown if at least one child is visible; individual items checked directly.
  const isVisible = (id: string): boolean => {
    if (id.startsWith('_d') || id === 'dashboard' || id === 'settings') return true;
    if (id.endsWith('_group')) return true; // group visibility determined by children
    return vis[id as VisibilityKey] !== false;
  };

  const Item = ({ item, depth = 0 }: any) => {
    if (item.id.startsWith('_d')) return <div style={{ height: 1, background: '#1e293b', margin: '6px 10px' }} />;
    // For groups: filter visible children first; hide group if no children visible
    const visibleChildren = item.children?.filter((c: any) => isVisible(c.id)) || [];
    if (!isVisible(item.id) && !item.id.endsWith('_group')) return null;
    if (item.id.endsWith('_group') && visibleChildren.length === 0) return null;
    const isActive = active === item.id;
    const hasKids = visibleChildren.length > 0;
    const isOpen  = open[item.id];
    const Icon = item.icon;
    return (
      <>
        <button
          onClick={() => hasKids ? toggle(item.id) : setActive(item.id)}
          style={{
            display: 'flex', alignItems: 'center', width: '100%', gap: 8,
            padding: `${depth > 0 ? 7 : 9}px ${depth > 0 ? 34 : 10}px`,
            background: isActive ? 'rgba(99,102,241,.18)' : 'transparent',
            border: 'none', borderLeft: `3px solid ${isActive ? '#6366f1' : 'transparent'}`,
            color: isActive ? '#a5b4fc' : '#64748b', borderRadius: '0 8px 8px 0',
            cursor: 'pointer', fontSize: 13, fontWeight: isActive ? 700 : 500,
            textAlign: 'left', transition: 'all .12s', marginBottom: 1, fontFamily: 'inherit',
          }}>
          {Icon && <Icon size={depth > 0 ? 13 : 15} style={{ flexShrink: 0 }} />}
          {!collapsed && <span style={{ flex: 1 }}>{item.label}</span>}
          {!collapsed && hasKids && (
            <ChevronDown size={11} style={{ transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }} />
          )}
        </button>
        {!collapsed && hasKids && isOpen && visibleChildren.map((c: any) => <Item key={c.id} item={c} depth={1} />)}
      </>
    );
  };

  return (
    <div style={{ width: collapsed ? 54 : 218, background: '#0a0f1e', borderRight: '1px solid #1e293b',
      display: 'flex', flexDirection: 'column', height: '100vh', flexShrink: 0, transition: 'width .2s' }}>
      {/* Logo */}
      <div style={{ padding: '16px 14px', display: 'flex', alignItems: 'center', gap: 10,
        borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <div style={{ width: 30, height: 30, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
          borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <BookOpen size={15} color="#fff" />
        </div>
        {!collapsed && (
          <div>
            <div style={{ fontSize: 15, fontWeight: 900, color: '#f8fafc', letterSpacing: '-.02em' }}>WayBook</div>
            <div style={{ fontSize: 9, color: '#6366f1', fontWeight: 800, letterSpacing: '.12em' }}>GST BILLING</div>
          </div>
        )}
      </div>

      {/* Firm pill */}
      {!collapsed && firm && (
        <div style={{ padding: '8px 14px', borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
          <div style={{ fontSize: 10, color: '#334155', fontWeight: 700, marginBottom: 2 }}>ACTIVE FIRM</div>
          <div style={{ fontSize: 12, color: '#94a3b8', fontWeight: 600,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {firm.name}
          </div>
        </div>
      )}

      {/* Nav */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '6px 4px',
        scrollbarWidth: 'thin', scrollbarColor: '#1e293b transparent' }}>
        {NAV_ITEMS.map(item => <Item key={item.id} item={item} />)}
      </div>

      {/* Footer */}
      {!collapsed && (
        <div style={{ padding: '10px 14px', borderTop: '1px solid #1e293b',
          fontSize: 10, color: '#334155', fontWeight: 600 }}>
          WayBook v1.0
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   DASHBOARD
═══════════════════════════════════════════════════════════════════════════ */
function Dashboard({ firmId, onNavigate }: { firmId: string; onNavigate: (page: string) => void }) {
  const [data, setData] = useState<any>(null);
  const [topItems, setTopItems] = useState<any[]>([]);
  const [topTxns, setTopTxns] = useState<any[]>([]);
  const [preset, setPreset] = useState('this_month');
  const [start, setStart] = useState(ymd(startOfMonth(new Date())));
  const [end,   setEnd]   = useState(todayStr());

  // When a named preset is chosen, compute its start/end and store them —
  // this keeps a single source of truth (start/end) that all three sections
  // (stats, Top 5 Items, Top 5 Transactions, Monthly Sales) react to.
  const applyPreset = (key: string) => {
    setPreset(key);
    if (key === 'custom') return; // user will set start/end manually below
    const range = DATE_PRESETS[key]?.();
    if (range) { setStart(ymd(range.start)); setEnd(ymd(range.end)); }
  };

  useEffect(() => {
    if (!firmId) return;
    const qs = `firmId=${firmId}&startDate=${start}&endDate=${end}`;
    apiFetch(`/reports/dashboard?${qs}`).then(r => setData(r.data));
    apiFetch(`/reports/top-items?${qs}`).then(r => setTopItems(r.data || []));
    apiFetch(`/reports/top-transactions?${qs}`).then(r => setTopTxns(r.data || []));
  }, [firmId, start, end]);

  if (!data) return <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>Loading…</div>;

  const typeColor = (t: string) => t?.includes('sale') ? 'green' : t?.includes('purchase') ? 'blue' : 'gray';
  const trends = [...(data.monthlyTrends || [])];

  const MiniBar = ({ title, bars }: { title: string; bars: { label: string; value: number; color: string }[] }) => (
    <div style={{ background: '#1e293b', borderRadius: 14, padding: 20, border: '1px solid #334155' }}>
      <div style={{ fontSize: 12, fontWeight: 800, color: '#64748b', letterSpacing: '.06em',
        textTransform: 'uppercase', marginBottom: 14 }}>{title}</div>
      <ResponsiveContainer width="100%" height={140}>
        <BarChart data={bars}>
          <XAxis dataKey="label" tick={{ fill: '#64748b', fontSize: 10 }} />
          <YAxis tick={{ fill: '#64748b', fontSize: 10 }} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
          <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }}
            formatter={(v: any) => [fmt(Number(v)), '']} />
          <Bar dataKey="value" fill="#6366f1" radius={[6,6,0,0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );

  return (
    <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>
      {/* Period */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 22, alignItems: 'center', flexWrap: 'wrap' }}>
        <span style={{ fontSize: 12, color: '#64748b', fontWeight: 700 }}>PERIOD</span>
        <Sel value={preset} onChange={e => applyPreset(e.target.value)} style={{ ...IS, width: 190 }}>
          {DATE_PRESET_LABELS.map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </Sel>
        {preset === 'custom' && (
          <>
            <Inp type="date" value={start} onChange={e => setStart(e.target.value)} style={{ ...IS, width: 155 }} />
            <span style={{ color: '#475569' }}>→</span>
            <Inp type="date" value={end} onChange={e => setEnd(e.target.value)} style={{ ...IS, width: 155 }} />
          </>
        )}
      </div>

      {/* Top strip — today's snapshot, independent of the period filter */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 14, marginBottom: 14 }}>
        <StatCard label="Today's Sales"     value={fmt(data.today?.sales)}     icon={TrendingUp} color="#6366f1" onClick={() => onNavigate('sale_invoice')} />
        <StatCard label="Today's Purchases" value={fmt(data.today?.purchases)} icon={ShoppingCart} color="#8b5cf6" onClick={() => onNavigate('purchase_invoice')} />
        <StatCard label="Cash in Hand"      value={fmt(data.cashInHand)}       icon={Wallet}     color="#10b981" onClick={() => onNavigate('bank')} />
        <StatCard label="Bank Balance"      value={fmt(data.bankBalance)}      icon={Building2}  color="#0ea5e9" onClick={() => onNavigate('bank')} />
      </div>

      {/* Main stats — respect the selected period */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 14, marginBottom: 22 }}>
        <StatCard label="Total Sales"     value={fmt(data.sales?.total)}     icon={TrendingUp}   color="#6366f1" sub={`${data.sales?.count || 0} invoices`} trend={1} onClick={() => onNavigate('sale_invoice')} />
        <StatCard label="Purchases"       value={fmt(data.purchases?.total)} icon={ShoppingCart} color="#8b5cf6" sub={`${data.purchases?.count || 0} bills`} onClick={() => onNavigate('purchase_invoice')} />
        <StatCard label="Gross Profit"    value={fmt(data.grossProfit)}      icon={PieChart}     color={data.grossProfit >= 0 ? '#10b981' : '#ef4444'} sub="Sales minus purchases" onClick={() => onNavigate('report_pl')} />
        <StatCard label="Net Profit"      value={fmt(data.profit)}           icon={IndianRupee}  color={data.profit >= 0 ? '#10b981' : '#ef4444'} sub="After expenses" trend={data.profit >= 0 ? 1 : -1} onClick={() => onNavigate('report_pl')} />
        <StatCard label="Inventory Value" value={fmt(data.stock?.inventoryValue)} icon={Boxes}   color="#14b8a6" onClick={() => onNavigate('report_stock')} />
        <StatCard label="Receivable"      value={fmt(data.outstanding?.receivable)} icon={CreditCard} color="#f59e0b" sub="Pending from customers" onClick={() => onNavigate('report_outstanding')} />
        <StatCard label="Payable"         value={fmt(data.outstanding?.payable)}    icon={Wallet}      color="#ec4899" sub="Due to suppliers" onClick={() => onNavigate('report_outstanding')} />
        <StatCard label="Low Stock Items" value={String(data.stock?.lowStock || 0)} icon={AlertCircle} color="#ef4444" sub={`of ${data.totals?.items || 0} items`} trend={data.stock?.lowStock > 0 ? -1 : 0} onClick={() => onNavigate('report_stock')} />
      </div>

      {/* Sales / Purchase / Profit trend */}
      <div style={{ background: '#1e293b', borderRadius: 14, padding: 20, border: '1px solid #334155', marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: '#64748b', letterSpacing: '.06em',
          textTransform: 'uppercase', marginBottom: 14 }}>Sales vs Purchase vs Profit</div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={trends} onClick={() => onNavigate('report_pl')} style={{ cursor: 'pointer' }}>
            <defs>
              <linearGradient id="gradSales" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={.35} /><stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gradPurch" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={.3} /><stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="gradProfit" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={.3} /><stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="month" tick={{ fill: '#64748b', fontSize: 10 }} />
            <YAxis tick={{ fill: '#64748b', fontSize: 10 }} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
            <Tooltip contentStyle={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8, fontSize: 12 }}
              formatter={(v: any, name: string) => [fmt(Number(v)), name]} />
            <Area type="monotone" dataKey="sales"     name="Sales"     stroke="#6366f1" strokeWidth={2} fill="url(#gradSales)" />
            <Area type="monotone" dataKey="purchases" name="Purchases" stroke="#8b5cf6" strokeWidth={2} fill="url(#gradPurch)" />
            <Area type="monotone" dataKey="profit"    name="Profit"    stroke="#10b981" strokeWidth={2} fill="url(#gradProfit)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Receivable/Payable, Cash/Bank, Expenses snapshots */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 16, marginBottom: 22 }}>
        <div onClick={() => onNavigate('report_outstanding')} style={{ cursor: 'pointer' }}>
          <MiniBar title="Receivable vs Payable" bars={[
            { label: 'Receivable', value: data.outstanding?.receivable || 0, color: '#f59e0b' },
            { label: 'Payable',    value: data.outstanding?.payable || 0,    color: '#ec4899' },
          ]} />
        </div>
        <div onClick={() => onNavigate('bank')} style={{ cursor: 'pointer' }}>
          <MiniBar title="Cash vs Bank" bars={[
            { label: 'Cash', value: data.cashInHand || 0, color: '#10b981' },
            { label: 'Bank', value: data.bankBalance || 0, color: '#0ea5e9' },
          ]} />
        </div>
        <div onClick={() => onNavigate('expenses')} style={{ cursor: 'pointer' }}>
          <MiniBar title="Expenses" bars={trends.map(t => ({ label: t.month, value: t.expenses, color: '#f59e0b' }))} />
        </div>
      </div>

      {/* Top 5 Items + Top 5 Transactions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 22 }}>
        <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155', display: 'flex', alignItems: 'center', gap: 8 }}>
            <Award size={13} color="#f59e0b" />
            <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
              Top 5 Selling Items
            </span>
          </div>
          <Table
            cols={[
              { key: 'rank', label: '#', render: (v: number) => <span style={{ color: '#64748b', fontWeight: 800 }}>{v}</span> },
              { key: 'itemName', label: 'Item' },
              { key: 'quantitySold', label: 'Qty', align: 'right', render: (v: number) => fmtN(v) },
              { key: 'salesValue', label: 'Sales Value', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            ]}
            rows={topItems}
            empty="No sales in this period."
          />
        </div>
        <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155', display: 'flex', alignItems: 'center', gap: 8 }}>
            <ListOrdered size={13} color="#6366f1" />
            <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
              Top 5 Transactions
            </span>
          </div>
          <Table
            cols={[
              { key: 'rank', label: '#', render: (v: number) => <span style={{ color: '#64748b', fontWeight: 800 }}>{v}</span> },
              { key: 'documentNumber', label: 'No.', render: (v: string) => <span style={{ color: '#a5b4fc', fontWeight: 700 }}>{v}</span> },
              { key: 'partyName', label: 'Party' },
              { key: 'documentType', label: 'Type', render: (v: string) => <Badge color={typeColor(v)}>{v?.replace(/_/g,' ')}</Badge> },
              { key: 'total', label: 'Amount', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            ]}
            rows={topTxns}
            empty="No transactions in this period."
          />
        </div>
      </div>

      {/* Recent */}
      <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
        <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155' }}>
          <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
            Recent Transactions
          </span>
        </div>
        <Table
          cols={[
            { key: 'documentNumber', label: 'No.', render: (v: string) => <span style={{ color: '#a5b4fc', fontWeight: 700 }}>{v}</span> },
            { key: 'documentType',   label: 'Type', render: (v: string) => <Badge color={typeColor(v)}>{v?.replace(/_/g,' ')}</Badge> },
            { key: 'partyName',      label: 'Party' },
            { key: 'total',          label: 'Amount', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            { key: 'documentDate',   label: 'Date' },
          ]}
          rows={data.recentDocs || []}
        />
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   LEDGER — party-wise running balance + bill-wise outstanding (spec §4)
═══════════════════════════════════════════════════════════════════════════ */
function Ledger({ firmId, onNavigate }: { firmId: string; onNavigate?: (page: string) => void }) {
  const [parties, setParties] = useState<any[]>([]);
  const [partyId, setPartyId] = useState('');
  const [data, setData] = useState<any>(null);

  useEffect(() => { if (firmId) apiFetch(`/parties?firmId=${firmId}`).then(r => setParties(r.data || [])); }, [firmId]);
  useEffect(() => {
    if (!partyId) { setData(null); return; }
    apiFetch(`/parties/${partyId}/ledger`).then(r => setData(r.data));
  }, [partyId]);

  const party = parties.find(p => p.id === partyId);

  return (
    <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>
      <div style={{ marginBottom: 20, maxWidth: 360 }}>
        <Field label="Select Party">
          <Sel value={partyId} onChange={e => setPartyId(e.target.value)}>
            <option value="">Choose a customer or supplier…</option>
            {parties.map(p => <option key={p.id} value={p.id}>{p.name} ({p.type})</option>)}
          </Sel>
        </Field>
      </div>

      {!partyId && <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>Select a party to view their ledger.</div>}

      {partyId && data && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', gap: 14, marginBottom: 22 }}>
            <StatCard label="Opening Balance" value={fmt(data.openingBalance)} icon={BookOpen} color="#64748b" />
            <StatCard label="Current Balance" value={fmt(data.currentBalance)} icon={IndianRupee}
              color={data.currentBalance >= 0 ? '#f59e0b' : '#10b981'}
              sub={data.currentBalance >= 0 ? 'They owe you' : 'You owe them'} />
            <StatCard label="Outstanding Bills" value={String(data.outstandingBills?.length || 0)} icon={AlertCircle} color="#ec4899" />
          </div>

          <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden', marginBottom: 22 }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155' }}>
              <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
                Bill-wise Outstanding
              </span>
            </div>
            <Table
              cols={[
                { key: 'documentNumber', label: 'Bill No.', render: (v: string) => <span style={{ color: '#a5b4fc', fontWeight: 700 }}>{v}</span> },
                { key: 'documentDate',   label: 'Date' },
                { key: 'total',          label: 'Total',   align: 'right', render: (v: number) => fmt(v) },
                { key: 'paidAmount',     label: 'Paid',    align: 'right', render: (v: number) => fmt(v) },
                { key: 'balanceAmount',  label: 'Balance', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
                { key: 'status', label: 'Status', render: (v: string) =>
                  <Badge color={v === 'paid' ? 'green' : v === 'partially_paid' ? 'yellow' : 'red'}>{v?.replace(/_/g,' ')}</Badge> },
              ]}
              rows={data.outstandingBills || []}
              empty="No outstanding bills."
              onRow={onNavigate ? (r: any) => onNavigate(party?.type === 'supplier' ? 'purchase_invoice' : 'sale_invoice') : undefined}
            />
          </div>

          <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
            <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155' }}>
              <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
                Full Ledger
              </span>
            </div>
            <Table
              cols={[
                { key: 'date', label: 'Date' },
                { key: 'kind', label: 'Type', render: (v: string, r: any) =>
                  <Badge color={v === 'payment' ? 'purple' : (r.documentType?.includes('sale') ? 'green' : 'blue')}>
                    {v === 'payment' ? r.type?.replace('_',' ') : r.documentType?.replace(/_/g,' ')}
                  </Badge> },
                { key: 'ref', label: 'Reference', render: (_: any, r: any) => r.documentNumber || r.reference || '—' },
                { key: 'debit',  label: 'Debit',  align: 'right', render: (v: number) => v ? fmt(v) : '—' },
                { key: 'credit', label: 'Credit', align: 'right', render: (v: number) => v ? fmt(v) : '—' },
                { key: 'runningBalance', label: 'Balance', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
              ]}
              rows={data.ledger || []}
              empty="No transactions yet."
            />
          </div>
        </>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   ACCOUNTING ENTRIES — unified feed of documents, payments & expenses (spec §11)
═══════════════════════════════════════════════════════════════════════════ */
function AccountingEntries({ firmId }: { firmId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  const [preset, setPreset] = useState('this_month');
  const [start, setStart] = useState(ymd(startOfMonth(new Date())));
  const [end, setEnd] = useState(todayStr());

  const applyPreset = (key: string) => {
    setPreset(key);
    if (key === 'custom') return;
    const range = DATE_PRESETS[key]?.();
    if (range) { setStart(ymd(range.start)); setEnd(ymd(range.end)); }
  };

  useEffect(() => {
    if (!firmId) return;
    Promise.all([
      apiFetch(`/documents?firmId=${firmId}&startDate=${start}&endDate=${end}&limit=200`),
      apiFetch(`/payments?firmId=${firmId}`),
      apiFetch(`/expenses?firmId=${firmId}&startDate=${start}&endDate=${end}`),
    ]).then(([docsR, paysR, expR]) => {
      const docs = (docsR.data || []).map((d: any) => ({
        date: d.documentDate, type: d.documentType, ref: d.documentNumber, party: d.partyName, amount: d.total, kind: 'document'
      }));
      const pays = (paysR.data || []).filter((p: any) => p.paymentDate >= start && p.paymentDate <= end).map((p: any) => ({
        date: p.paymentDate, type: p.type, ref: p.receiptNumber || '—', party: p.partyName, amount: p.amount, kind: 'payment'
      }));
      const exps = (expR.data || []).map((e: any) => ({
        date: e.date, type: 'expense', ref: e.categoryName || '—', party: e.partyName || '—', amount: e.amount, kind: 'expense'
      }));
      setRows([...docs, ...pays, ...exps].sort((a, b) => String(b.date).localeCompare(String(a.date))));
    });
  }, [firmId, start, end]);

  const typeColor = (k: string, t: string) => k === 'payment' ? 'purple' : k === 'expense' ? 'orange' : t?.includes('sale') ? 'green' : 'blue';

  return (
    <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 22, alignItems: 'center', flexWrap: 'wrap' }}>
        <span style={{ fontSize: 12, color: '#64748b', fontWeight: 700 }}>PERIOD</span>
        <Sel value={preset} onChange={e => applyPreset(e.target.value)} style={{ ...IS, width: 190 }}>
          {DATE_PRESET_LABELS.map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </Sel>
        {preset === 'custom' && (
          <>
            <Inp type="date" value={start} onChange={e => setStart(e.target.value)} style={{ ...IS, width: 155 }} />
            <span style={{ color: '#475569' }}>→</span>
            <Inp type="date" value={end} onChange={e => setEnd(e.target.value)} style={{ ...IS, width: 155 }} />
          </>
        )}
      </div>
      <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
        <Table
          cols={[
            { key: 'date', label: 'Date' },
            { key: 'type', label: 'Type', render: (v: string, r: any) => <Badge color={typeColor(r.kind, v)}>{v?.replace(/_/g,' ')}</Badge> },
            { key: 'ref', label: 'Reference' },
            { key: 'party', label: 'Party' },
            { key: 'amount', label: 'Amount', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
          ]}
          rows={rows}
          empty="No entries in this period."
        />
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   EXCEL IMPORT — shared component for Items and Parties
═══════════════════════════════════════════════════════════════════════════ */
function ExcelImportModal({ open, onClose, firmId, type, toast, onDone }: {
  open: boolean; onClose: () => void; firmId: string;
  type: 'items' | 'parties'; toast: any; onDone: () => void;
}) {
  const [step, setStep] = useState<'upload' | 'preview' | 'done'>('upload');
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<any>(null);
  const [overwrite, setOverwrite] = useState(false);
  const [result, setResult] = useState<any>(null);
  const fileRef = React.useRef<HTMLInputElement>(null);

  const reset = () => { setStep('upload'); setFile(null); setPreview(null); setResult(null); setOverwrite(false); };
  const handleClose = () => { reset(); onClose(); };

  const downloadTemplate = () => {
    window.open(`${API_BASE}/import/${type}/template`, '_blank');
  };

  const doPreview = async () => {
    if (!file) { toast.error('Select an Excel file first'); return; }
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('firmId', firmId);
      const res = await fetch(`${API_BASE}/import/${type}/preview`, { method: 'POST', body: fd });
      const data = await res.json();
      if (data.error) { toast.error(data.error); } else {
        setPreview(data.data);
        setStep('preview');
      }
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  };

  const doCommit = async () => {
    if (!preview) return;
    setLoading(true);
    try {
      const r = await apiFetch(`/import/${type}/commit`, {
        method: 'POST',
        body: { firmId, rows: preview.rows, overwriteExisting: overwrite },
      });
      if (r.error) { toast.error(r.error); } else {
        setResult(r.data);
        setStep('done');
        onDone();
        toast.success(`Import complete: ${r.data.inserted} inserted, ${r.data.updated} updated`);
      }
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  };

  const okRows  = preview?.rows?.filter((r: any) => r.status === 'ok') || [];
  const errRows = preview?.rows?.filter((r: any) => r.status === 'error') || [];

  return (
    <Modal open={open} onClose={handleClose}
      title={`Import ${type === 'items' ? 'Items' : 'Parties'} from Excel`} size="xl">

      {/* Step indicator */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 24, background: '#0f172a', borderRadius: 10, padding: 4 }}>
        {(['upload', 'preview', 'done'] as const).map((s, i) => (
          <div key={s} style={{ flex: 1, textAlign: 'center', padding: '8px 0', borderRadius: 8,
            background: step === s ? '#6366f1' : 'transparent',
            color: step === s ? '#fff' : '#475569', fontSize: 12, fontWeight: 700, transition: 'all .15s' }}>
            {i + 1}. {s.charAt(0).toUpperCase() + s.slice(1)}
          </div>
        ))}
      </div>

      {/* STEP 1: Upload */}
      {step === 'upload' && (
        <div>
          <div style={{ background: '#0f172a', borderRadius: 12, padding: 20, marginBottom: 18, border: '1px solid #334155' }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f8fafc', marginBottom: 8 }}>
              Step 1: Download the template
            </div>
            <div style={{ fontSize: 12, color: '#64748b', marginBottom: 12 }}>
              Use the official WayBook template to avoid import errors. Fill it in and upload below.
            </div>
            <Btn variant="ghost" onClick={downloadTemplate}>
              <Download size={13} /> Download Template
            </Btn>
          </div>

          <div style={{ background: '#0f172a', borderRadius: 12, padding: 20, border: '1px solid #334155' }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#f8fafc', marginBottom: 8 }}>
              Step 2: Upload your filled Excel file
            </div>
            <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" style={{ display: 'none' }}
              onChange={e => setFile(e.target.files?.[0] || null)} />
            <div
              onClick={() => fileRef.current?.click()}
              style={{ border: '2px dashed #334155', borderRadius: 10, padding: '28px 20px',
                textAlign: 'center', cursor: 'pointer', marginBottom: 14,
                background: file ? '#1e293b' : 'transparent', transition: 'all .15s' }}>
              {file ? (
                <div>
                  <FileUp size={24} color="#6366f1" style={{ marginBottom: 8 }} />
                  <div style={{ fontSize: 13, color: '#f8fafc', fontWeight: 700 }}>{file.name}</div>
                  <div style={{ fontSize: 11, color: '#64748b' }}>{(file.size / 1024).toFixed(1)} KB · Click to change</div>
                </div>
              ) : (
                <div>
                  <Upload size={24} color="#475569" style={{ marginBottom: 8 }} />
                  <div style={{ fontSize: 13, color: '#94a3b8' }}>Click to select Excel file (.xlsx, .xls)</div>
                </div>
              )}
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', marginBottom: 14 }}>
              <input type="checkbox" checked={overwrite} onChange={e => setOverwrite(e.target.checked)} />
              <span style={{ fontSize: 13, color: '#94a3b8' }}>
                Update/Overwrite existing records with same name
              </span>
            </label>
            <div style={{ display: 'flex', gap: 10 }}>
              <Btn onClick={doPreview} disabled={!file || loading}>
                {loading ? 'Validating…' : 'Preview Import'}
              </Btn>
              <Btn variant="ghost" onClick={handleClose}>Cancel</Btn>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: Preview */}
      {step === 'preview' && preview && (
        <div>
          {/* Summary bar */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            {[
              { label: 'Total Rows', v: preview.summary.total, c: '#94a3b8' },
              { label: 'Ready', v: preview.summary.ok, c: '#4ade80' },
              { label: 'Errors', v: preview.summary.errors, c: '#f87171' },
            ].map(({ label, v, c }) => (
              <div key={label} style={{ background: '#0f172a', borderRadius: 10, padding: '10px 16px',
                border: '1px solid #334155', flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: 22, fontWeight: 900, color: c }}>{v}</div>
                <div style={{ fontSize: 11, color: '#64748b', fontWeight: 700, marginTop: 2 }}>{label}</div>
              </div>
            ))}
          </div>

          {/* Error rows shown first */}
          {errRows.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, fontWeight: 800, color: '#f87171', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <AlertTriangle size={13} /> {errRows.length} rows with errors (will be skipped)
              </div>
              <div style={{ maxHeight: 180, overflowY: 'auto', border: '1px solid #334155', borderRadius: 10 }}>
                {errRows.map((r: any) => (
                  <div key={r.rowNum} style={{ padding: '8px 12px', borderBottom: '1px solid #1e293b',
                    background: '#1e293b' }}>
                    <div style={{ fontSize: 12, fontWeight: 700, color: '#f8fafc', marginBottom: 4 }}>
                      Row {r.rowNum}: {r.data?.name || '(empty)'}
                    </div>
                    {r.errors.map((e: string, i: number) => (
                      <div key={i} style={{ fontSize: 11, color: '#f87171', display: 'flex', alignItems: 'center', gap: 5 }}>
                        <span>•</span> {e}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* OK rows */}
          {okRows.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 800, color: '#4ade80', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <CheckSquare size={13} /> {okRows.length} rows ready to import
              </div>
              <div style={{ maxHeight: 200, overflowY: 'auto', border: '1px solid #334155', borderRadius: 10 }}>
                {okRows.slice(0, 50).map((r: any) => (
                  <div key={r.rowNum} style={{ padding: '7px 12px', borderBottom: '1px solid #1e293b',
                    display: 'flex', alignItems: 'center', gap: 10 }}>
                    <CheckCircle size={12} color="#4ade80" />
                    <span style={{ fontSize: 12, color: '#e2e8f0' }}>Row {r.rowNum}: <strong>{r.data?.name}</strong></span>
                    {type === 'items' && <span style={{ fontSize: 11, color: '#64748b' }}>
                      {r.data.type} · ₹{r.data.salePrice} · GST {r.data.taxRate}%
                    </span>}
                    {type === 'parties' && <span style={{ fontSize: 11, color: '#64748b' }}>
                      {r.data.type} · {r.data.city || r.data.state || '—'}
                    </span>}
                  </div>
                ))}
                {okRows.length > 50 && (
                  <div style={{ padding: '8px 12px', color: '#64748b', fontSize: 12 }}>
                    … and {okRows.length - 50} more rows
                  </div>
                )}
              </div>
            </div>
          )}

          {okRows.length === 0 && (
            <div style={{ padding: 20, textAlign: 'center', color: '#64748b', fontSize: 13 }}>
              No valid rows to import. Fix the errors above and try again.
            </div>
          )}

          <div style={{ display: 'flex', gap: 10 }}>
            {okRows.length > 0 && (
              <Btn onClick={doCommit} disabled={loading} variant="success">
                {loading ? 'Importing…' : `Import ${okRows.length} Row${okRows.length !== 1 ? 's' : ''}`}
              </Btn>
            )}
            <Btn variant="ghost" onClick={() => { setStep('upload'); setPreview(null); }}>← Back</Btn>
            <Btn variant="ghost" onClick={handleClose}>Cancel</Btn>
          </div>
        </div>
      )}

      {/* STEP 3: Done */}
      {step === 'done' && result && (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <CheckCircle size={48} color="#4ade80" style={{ marginBottom: 16 }} />
          <div style={{ fontSize: 20, fontWeight: 900, color: '#f8fafc', marginBottom: 8 }}>Import Complete!</div>
          <div style={{ display: 'flex', gap: 16, justifyContent: 'center', marginBottom: 20 }}>
            {[
              { label: 'Inserted', v: result.inserted, c: '#4ade80' },
              { label: 'Updated', v: result.updated, c: '#60a5fa' },
              { label: 'Skipped', v: result.skipped, c: '#94a3b8' },
            ].map(({ label, v, c }) => (
              <div key={label} style={{ background: '#0f172a', borderRadius: 10, padding: '12px 20px', border: '1px solid #334155' }}>
                <div style={{ fontSize: 28, fontWeight: 900, color: c }}>{v}</div>
                <div style={{ fontSize: 11, color: '#64748b', fontWeight: 700 }}>{label}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
            <Btn onClick={() => { reset(); }}>Import More</Btn>
            <Btn variant="ghost" onClick={handleClose}>Close</Btn>
          </div>
        </div>
      )}
    </Modal>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   ITEMS
═══════════════════════════════════════════════════════════════════════════ */
function Items({ firmId, toast }: any) {
  const [items, setItems]         = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [units, setUnits]         = useState<any[]>([]);
  const [search, setSearch]       = useState('');
  const [modal, setModal]         = useState(false);
  const [importModal, setImportModal] = useState(false);
  const [form, setForm]           = useState<any>({});
  const [saving, setSaving]       = useState(false);
  const { settings: moduleSettings, reload: reloadModuleSettings } = useModuleSettings(firmId, 'items');

  const load = useCallback(() => {
    apiFetch(`/items?firmId=${firmId}&search=${search}`).then(r => setItems(r.data || []));
    apiFetch(`/categories?firmId=${firmId}&type=item`).then(r => setCategories(r.data || []));
    apiFetch(`/units?firmId=${firmId}`).then(r => setUnits(r.data || []));
  }, [firmId, search]);

  useEffect(() => { if (firmId) load(); }, [load]);

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));

  const save = async () => {
    if (!form.name) { toast.error('Item name is required'); return; }
    if (form.secondaryUnitId && (!form.conversionFactor || parseFloat(form.conversionFactor) <= 0)) {
      toast.error('Enter a valid conversion quantity for Unit 2'); return;
    }
    setSaving(true);
    const r = form.id
      ? await apiFetch(`/items/${form.id}`, { method: 'PUT', body: { ...form, firmId } })
      : await apiFetch('/items', { method: 'POST', body: { ...form, firmId } });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success(form.id ? 'Item updated' : 'Item created');
    setModal(false); load();
  };

  const deactivate = async (id: string) => {
    if (!confirm('Deactivate this item?')) return;
    await apiFetch(`/items/${id}`, { method: 'DELETE' });
    toast.success('Item deactivated'); load();
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', display: 'flex', gap: 10, alignItems: 'center',
        borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 380 }}>
          <Search size={13} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: '#475569' }} />
          <Inp placeholder="Search items…" value={search} onChange={e => setSearch(e.target.value)}
            style={{ ...IS, paddingLeft: 33 }} />
        </div>
        <Btn variant="ghost" onClick={() => setImportModal(true)}>
          <Upload size={13} /> Import Excel
        </Btn>
        <Btn onClick={() => { setForm({ type: 'PRODUCT', taxRate: '0', isActive: 1 }); setModal(true); }}>
          <Plus size={13} /> Add Item
        </Btn>
        <ModuleSettingsButton firmId={firmId} moduleKey="items" settings={moduleSettings}
          onChange={reloadModuleSettings} toast={toast} />
      </div>

      <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
        <Table
          cols={[
            { key: 'name', label: 'Item', render: (v: string, r: any) =>
              <div><div style={{ fontWeight: 700 }}>{v}</div>
                <div style={{ fontSize: 11, color: '#475569' }}>{r.itemCode || r.hsnCode || '—'}</div></div> },
            { key: 'type', label: 'Type', render: (v: string) =>
              <Badge color={v === 'PRODUCT' ? 'blue' : 'purple'}>{v}</Badge> },
            { key: 'categoryName', label: 'Category' },
            ...(moduleSettings.unitsEnabled ? [{ key: 'unitShortName', label: 'Units', render: (_: any, r: any) =>
              r.secondaryUnitShortName
                ? <span style={{ fontSize: 12, color: '#94a3b8' }}>{r.unitShortName || '—'} · 1 {r.secondaryUnitShortName} = {r.conversionFactor} {r.unitShortName}</span>
                : <span style={{ fontSize: 12, color: '#94a3b8' }}>{r.unitShortName || '—'}</span> }] : []),
            { key: 'salePrice',    label: 'Sale ₹',     align: 'right', render: (v: number) => fmt(v) },
            { key: 'purchasePrice',label: 'Purchase ₹', align: 'right', render: (v: number) => fmt(v) },
            { key: 'taxRate',      label: 'GST',        align: 'center',render: (v: string) => <Badge color="gray">{v}%</Badge> },
            { key: 'currentStock', label: 'Stock',      align: 'right',
              render: (v: number, r: any) =>
                <span style={{ fontWeight: 800, color: v <= (r.minStockLevel || 0) && r.type === 'PRODUCT' ? '#ef4444' : '#4ade80' }}>
                  {fmtN(v || 0)}
                </span> },
            { key: 'id', label: '', render: (_: any, r: any) =>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); setForm(r); setModal(true); }}>
                  <Edit size={11} />
                </Btn>
                <Btn variant="danger" size="sm" onClick={e => { e.stopPropagation(); deactivate(r.id); }}>
                  <Trash2 size={11} />
                </Btn>
              </div> },
          ]}
          rows={items}
        />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? 'Edit Item' : 'Add Item'} size="lg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="Item Name" required><Inp value={form.name || ''} onChange={f('name')} placeholder="e.g. Basmati Rice 5kg" /></Field>
          <Field label="Type"><Sel value={form.type || 'PRODUCT'} onChange={f('type')}>
            <option value="PRODUCT">Product</option><option value="SERVICE">Service</option>
          </Sel></Field>
          <Field label="Category"><Sel value={form.categoryId || ''} onChange={f('categoryId')}>
            <option value="">— None —</option>
            {categories.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Sel></Field>
          <Field label={moduleSettings.unitsEnabled ? 'Unit 1 (Base)' : 'Unit'}>
            <Sel value={form.unitId || ''} onChange={f('unitId')}>
              <option value="">— None —</option>
              {units.map((u: any) => <option key={u.id} value={u.id}>{u.name} ({u.shortName})</option>)}
            </Sel>
          </Field>
          {moduleSettings.unitsEnabled && (
            <>
              <Field label="Unit 2 (Secondary — optional)">
                <Sel value={form.secondaryUnitId || ''} onChange={f('secondaryUnitId')}>
                  <option value="">— None —</option>
                  {units.filter((u: any) => u.id !== form.unitId).map((u: any) =>
                    <option key={u.id} value={u.id}>{u.name} ({u.shortName})</option>)}
                </Sel>
              </Field>
              {form.secondaryUnitId && (
                <Field label={`Conversion: 1 ${units.find((u: any) => u.id === form.secondaryUnitId)?.shortName || 'Unit 2'} = ? ${units.find((u: any) => u.id === form.unitId)?.shortName || 'Unit 1'}`}>
                  <Inp type="number" min="0.0001" step="any" value={form.conversionFactor ?? ''}
                    onChange={f('conversionFactor')} placeholder="e.g. 10" />
                </Field>
              )}
            </>
          )}
          <Field label="HSN / SAC Code"><Inp value={form.hsnCode || ''} onChange={f('hsnCode')} placeholder="1006" /></Field>
          <Field label="Item Code / SKU"><Inp value={form.itemCode || ''} onChange={f('itemCode')} placeholder="SKU-001" /></Field>
          <Field label="Sale Price (₹)" required><Inp type="number" value={form.salePrice || ''} onChange={f('salePrice')} placeholder="0.00" /></Field>
          <Field label="Purchase Price (₹)"><Inp type="number" value={form.purchasePrice || ''} onChange={f('purchasePrice')} placeholder="0.00" /></Field>
          <Field label="GST Rate"><Sel value={form.taxRate || '0'} onChange={f('taxRate')}>
            {['0','5','12','18','28'].map(r => <option key={r} value={r}>{r}%</option>)}
          </Sel></Field>
          <Field label="Opening Stock"><Inp type="number" value={form.openingStock || ''} onChange={f('openingStock')} placeholder="0" /></Field>
          <Field label="Min Stock Alert"><Inp type="number" value={form.minStockLevel || ''} onChange={f('minStockLevel')} placeholder="0" /></Field>
          <Field label="Storage Location"><Inp value={form.location || ''} onChange={f('location')} placeholder="Shelf A-3" /></Field>
        </div>
        <Field label="Description"><Txt value={form.description || ''} onChange={f('description')} placeholder="Item description or notes" /></Field>
        <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
          <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : form.id ? 'Update Item' : 'Create Item'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>

      <ExcelImportModal open={importModal} onClose={() => setImportModal(false)}
        firmId={firmId} type="items" toast={toast} onDone={load} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PARTIES
═══════════════════════════════════════════════════════════════════════════ */
function Parties({ firmId, toast }: any) {
  const [parties, setParties] = useState<any[]>([]);
  const [search,  setSearch]  = useState('');
  const [typeF,   setTypeF]   = useState('');
  const [modal,   setModal]   = useState(false);
  const [importModal, setImportModal] = useState(false);
  const [form,    setForm]    = useState<any>({});
  const [saving,  setSaving]  = useState(false);

  const load = useCallback(() => {
    apiFetch(`/parties?firmId=${firmId}&search=${search}&type=${typeF}`).then(r => setParties(r.data || []));
  }, [firmId, search, typeF]);

  useEffect(() => { if (firmId) load(); }, [load]);

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));

  const save = async () => {
    if (!form.name) { toast.error('Party name required'); return; }
    const gErr = gstinError(form.gstin || '');
    if (gErr) { toast.error(gErr); return; }
    const mErr = mobileError(form.phone || '');
    if (mErr) { toast.error(mErr); return; }
    setSaving(true);
    const r = form.id
      ? await apiFetch(`/parties/${form.id}`, { method: 'PUT', body: { ...form, firmId } })
      : await apiFetch('/parties', { method: 'POST', body: { ...form, firmId } });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Party saved'); setModal(false); load();
  };

  const STATES = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
    'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur',
    'Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana',
    'Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Delhi','Jammu & Kashmir','Ladakh'];

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', display: 'flex', gap: 10, alignItems: 'center',
        borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 380 }}>
          <Search size={13} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: '#475569' }} />
          <Inp placeholder="Search parties…" value={search} onChange={e => setSearch(e.target.value)}
            style={{ ...IS, paddingLeft: 33 }} />
        </div>
        <Sel value={typeF} onChange={e => setTypeF(e.target.value)} style={{ ...IS, width: 140 }}>
          <option value="">All Types</option><option value="customer">Customers</option>
          <option value="supplier">Suppliers</option><option value="both">Both</option>
        </Sel>
        <Btn variant="ghost" onClick={() => setImportModal(true)}>
          <Upload size={13} /> Import Excel
        </Btn>
        <Btn onClick={() => { setForm({ type: 'customer' }); setModal(true); }}>
          <Plus size={13} /> Add Party
        </Btn>
      </div>

      <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
        <Table
          cols={[
            { key: 'name', label: 'Name', render: (v: string, r: any) =>
              <div><div style={{ fontWeight: 700 }}>{v}</div>
                <div style={{ fontSize: 11, color: '#475569' }}>{r.phone || r.email || '—'}</div></div> },
            { key: 'type', label: 'Type', render: (v: string) =>
              <Badge color={v === 'customer' ? 'green' : v === 'supplier' ? 'blue' : 'purple'}>{v}</Badge> },
            { key: 'city',  label: 'City' },
            { key: 'gstin', label: 'GSTIN' },
            { key: 'openingBalance', label: 'Opening', align: 'right', render: (v: number) => fmt(v) },
            { key: 'id', label: '', render: (_: any, r: any) =>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); setForm(r); setModal(true); }}>
                  <Edit size={11} />
                </Btn>
                <Btn variant="danger" size="sm" onClick={async e => {
                  e.stopPropagation();
                  if (!confirm('Deactivate?')) return;
                  await apiFetch(`/parties/${r.id}`, { method: 'DELETE' });
                  toast.success('Party deactivated'); load();
                }}><Trash2 size={11} /></Btn>
              </div> },
          ]}
          rows={parties}
        />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? 'Edit Party' : 'Add Party'} size="lg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="Name" required><Inp value={form.name || ''} onChange={f('name')} /></Field>
          <Field label="Type"><Sel value={form.type || 'customer'} onChange={f('type')}>
            <option value="customer">Customer</option><option value="supplier">Supplier</option><option value="both">Both</option>
          </Sel></Field>
          <Field label="Phone"><Inp value={form.phone || ''} onChange={f('phone')} placeholder="+91 98765 43210" /></Field>
          <Field label="Email"><Inp value={form.email || ''} onChange={f('email')} placeholder="name@email.com" /></Field>
          <Field label="GSTIN"><Inp value={form.gstin || ''} onChange={f('gstin')} placeholder="22AAAAA0000A1Z5" /></Field>
          <Field label="PAN"><Inp value={form.pan || ''} onChange={f('pan')} placeholder="AAAAA0000A" /></Field>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Address"><Inp value={form.address || ''} onChange={f('address')} /></Field>
          </div>
          <Field label="City"><Inp value={form.city || ''} onChange={f('city')} /></Field>
          <Field label="State"><Sel value={form.state || ''} onChange={f('state')}>
            <option value="">Select state</option>
            {STATES.map(s => <option key={s} value={s}>{s}</option>)}
          </Sel></Field>
          <Field label="Pincode"><Inp value={form.pincode || ''} onChange={f('pincode')} /></Field>
          <Field label="Credit Limit (₹)"><Inp type="number" value={form.creditLimit || ''} onChange={f('creditLimit')} /></Field>
          <Field label="Opening Balance (₹)"><Inp type="number" value={form.openingBalance || ''} onChange={f('openingBalance')} /></Field>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save Party'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>

      <ExcelImportModal open={importModal} onClose={() => setImportModal(false)}
        firmId={firmId} type="parties" toast={toast} onDone={load} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   QUICK CREATE — Customer / Vendor / Item, inline from any document (spec §6)
═══════════════════════════════════════════════════════════════════════════ */
function QuickCreateModal({ open, onClose, kind, firmId, toast, onCreated }:
  { open: boolean; onClose: () => void; kind: 'customer' | 'supplier' | 'item'; firmId: string; toast: any; onCreated: (rec: any) => void }) {
  const [form, setForm] = useState<any>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) setForm(kind === 'item' ? { type: 'PRODUCT', taxRate: '0' } : { type: kind }); }, [open, kind]);

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));

  const save = async () => {
    if (!form.name) { toast.error('Name is required'); return; }
    setSaving(true);
    const r = kind === 'item'
      ? await apiFetch('/items', { method: 'POST', body: { ...form, firmId } })
      : await apiFetch('/parties', { method: 'POST', body: { ...form, firmId } });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success(kind === 'item' ? 'Item created' : `${kind === 'supplier' ? 'Vendor' : 'Customer'} created`);
    onCreated(r.data);
    onClose();
  };

  return (
    <Modal open={open} onClose={onClose}
      title={kind === 'item' ? 'Create Item' : kind === 'supplier' ? 'Create Vendor' : 'Create Customer'} size="md">
      {kind === 'item' ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Item Name" required><Inp value={form.name || ''} onChange={f('name')} placeholder="e.g. Basmati Rice 5kg" /></Field>
          </div>
          <Field label="Sale Price (₹)"><Inp type="number" value={form.salePrice || ''} onChange={f('salePrice')} placeholder="0.00" /></Field>
          <Field label="Purchase Price (₹)"><Inp type="number" value={form.purchasePrice || ''} onChange={f('purchasePrice')} placeholder="0.00" /></Field>
          <Field label="GST Rate"><Sel value={form.taxRate || '0'} onChange={f('taxRate')}>
            {['0','5','12','18','28'].map(r => <option key={r} value={r}>{r}%</option>)}
          </Sel></Field>
          <Field label="Opening Stock"><Inp type="number" value={form.openingStock || ''} onChange={f('openingStock')} placeholder="0" /></Field>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Name" required><Inp value={form.name || ''} onChange={f('name')} /></Field>
          </div>
          <Field label="Phone"><Inp value={form.phone || ''} onChange={f('phone')} placeholder="+91 98765 43210" /></Field>
          <Field label="GSTIN"><Inp value={form.gstin || ''} onChange={f('gstin')} placeholder="22AAAAA0000A1Z5" /></Field>
          <Field label="Opening Balance (₹)"><Inp type="number" value={form.openingBalance || ''} onChange={f('openingBalance')} /></Field>
        </div>
      )}
      <div style={{ display: 'flex', gap: 10, marginTop: 16 }}>
        <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Create & Select'}</Btn>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
      </div>
    </Modal>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   DOCUMENTS  (invoices, orders, returns, etc.)
═══════════════════════════════════════════════════════════════════════════ */
const DOC_LABELS: Record<string, string> = {
  sale_invoice:'Sales Invoice', sale_order:'Sale Order', sale_return:'Sale Return',
  sale_quotation:'Quotation', delivery_challan:'Delivery Challan',
  purchase_invoice:'Purchase Bill', purchase_order:'Purchase Order', purchase_return:'Purchase Return',
};

function Documents({ firmId, docType, toast }: any) {
  const [docs,    setDocs]    = useState<any[]>([]);
  const [parties, setParties] = useState<any[]>([]);
  const [items,   setItems]   = useState<any[]>([]);
  const [units,   setUnits]   = useState<any[]>([]);
  const [series,  setSeries]  = useState<any[]>([]);
  const [search,  setSearch]  = useState('');
  const [modal,   setModal]   = useState(false);
  const [form,    setForm]    = useState<any>({});
  const [lines,   setLines]   = useState<any[]>([]);
  const [saving,  setSaving]  = useState(false);
  const [quickCreate, setQuickCreate] = useState<{ kind: 'customer' | 'supplier' | 'item'; lineIdx?: number } | null>(null);
  const { settings: moduleSettings, reload: reloadModuleSettings } = useModuleSettings(firmId, docType);

  // Sales-side documents (Invoice, Order, Return, Quotation, Challan) only ever
  // deal with Customers; Purchase-side documents only ever deal with Vendors —
  // a party flagged 'both' shows up in either list (spec §5).
  const isSalesDoc = docType.startsWith('sale_') || docType === 'delivery_challan';
  const partyKind: 'customer' | 'supplier' = isSalesDoc ? 'customer' : 'supplier';
  const scopedParties = parties.filter((p: any) => p.type === partyKind || p.type === 'both');

  const load = useCallback(() => {
    apiFetch(`/documents?firmId=${firmId}&documentType=${docType}&search=${search}`).then(r => setDocs(r.data || []));
    apiFetch(`/parties?firmId=${firmId}`).then(r => setParties(r.data || []));
    apiFetch(`/items?firmId=${firmId}`).then(r => setItems(r.data || []));
    apiFetch(`/units?firmId=${firmId}`).then(r => setUnits(r.data || []));
    apiFetch(`/series?firmId=${firmId}&transactionType=${docType}`).then(r => setSeries((r.data || []).filter((s: any) => s.isActive)));
  }, [firmId, docType, search]);

  useEffect(() => { if (firmId) load(); }, [load]);

  // When a series is picked (or a default exists), preview its next number for display only —
  // the real number is generated atomically on the backend at save time, so this preview can
  // never cause a duplicate even if two users have the same preview open simultaneously.
  const selectSeries = async (seriesId: string) => {
    setForm((p: any) => ({ ...p, seriesId }));
    if (!seriesId) { setForm((p: any) => ({ ...p, documentNumber: '' })); return; }
    const r = await apiFetch(`/series/${seriesId}/preview`);
    if (r.data) setForm((p: any) => ({ ...p, documentNumber: r.data }));
  };

  const blank = () => ({ _k: Date.now() + Math.random(), itemId:'', name:'', hsnCode:'', quantity:1, unit:'', unitId:'', price:0, discount:0, discountType:'percentage', taxRate:0, taxAmount:0, amount:0 });

  const selectItem = (idx: number, itemId: string) => {
    const item = items.find(i => i.id === itemId);
    if (!item) return;
    const u = units.find(u => u.id === item.unitId);
    recalc(idx, { itemId: item.id, name: item.name, hsnCode: item.hsnCode || '',
      price: item.salePrice, unit: u?.shortName || '', unitId: item.unitId || '',
      taxRate: parseFloat(item.taxRate) || 0 });
  };

  // Two Units + Conversion: switching a line between an item's Unit 1 (base) and
  // Unit 2 (secondary) rescales the unit price so the line total stays sensible
  // (e.g. price-per-Strip = price-per-Tablet × conversion) — the user can still
  // edit the price afterwards. Quantity is left as-is (it's "how many of the
  // selected unit"); the backend converts it to base-unit terms for stock.
  const selectLineUnit = (idx: number, unitId: string) => {
    setLines(prev => prev.map((l, i) => {
      if (i !== idx) return l;
      const item = items.find((it: any) => it.id === l.itemId);
      if (!item) return { ...l, unitId };
      const u = units.find((u: any) => u.id === unitId);
      const factor = parseFloat(item.conversionFactor) || 1;
      const wasSecondary = l.unitId === item.secondaryUnitId;
      const isSecondary = unitId === item.secondaryUnitId;
      let price = parseFloat(l.price) || 0;
      if (!wasSecondary && isSecondary) price = +(price * factor).toFixed(2);
      else if (wasSecondary && !isSecondary) price = +(price / factor).toFixed(2);
      return recalcLine({ ...l, unitId, unit: u?.shortName || l.unit, price }, moduleSettings.itemDiscountEnabled);
    }));
  };

  const recalcLine = (m: any, itemDiscOn = true) => {
    const base = m.price * m.quantity;
    const disc = itemDiscOn
      ? (m.discountType === 'percentage' ? base * ((m.discount || 0) / 100) : (m.discount || 0))
      : 0;
    const after = Math.max(0, base - disc);
    const tax   = after * ((m.taxRate || 0) / 100);
    return { ...m, taxAmount: +tax.toFixed(2), amount: +(after + tax).toFixed(2) };
  };

  const recalc = (idx: number, patch: any) => {
    setLines(prev => prev.map((l, i) => i !== idx ? l : recalcLine({ ...l, ...patch }, moduleSettings.itemDiscountEnabled)));
  };

  const totals = (() => {
    const subtotal   = lines.reduce((s, l) => s + l.price * l.quantity, 0);
    // Item-wise discount total
    const itemDisc   = lines.reduce((s, l) => {
      if (!moduleSettings.itemDiscountEnabled) return s;
      const b = l.price * l.quantity;
      return s + (l.discountType === 'percentage' ? b * (l.discount / 100) : (l.discount || 0));
    }, 0);
    // Lines total after item discounts (before GST)
    const linesAfterItemDisc = lines.reduce((s, l) => {
      if (!moduleSettings.itemDiscountEnabled) return s + l.price * l.quantity;
      const b = l.price * l.quantity;
      const d = l.discountType === 'percentage' ? b * (l.discount / 100) : (l.discount || 0);
      return s + (b - d);
    }, 0);
    // Bill-level discount
    const billDiscPct = moduleSettings.billDiscountEnabled ? (parseFloat(form.billDiscountPercentage) || 0) : 0;
    const billDiscAmt = moduleSettings.billDiscountEnabled ? (parseFloat(form.billDiscountAmount) || 0) : 0;
    const billDiscountAmount = billDiscPct > 0
      ? linesAfterItemDisc * (billDiscPct / 100)
      : billDiscAmt;
    const taxableAmount = Math.max(0, linesAfterItemDisc - billDiscountAmount);
    // GST applied on taxable amount
    const tax   = lines.reduce((s, l) => {
      const b = l.price * l.quantity;
      const itemD = moduleSettings.itemDiscountEnabled ? (l.discountType === 'percentage' ? b * (l.discount / 100) : (l.discount || 0)) : 0;
      const afterItem = b - itemD;
      // pro-rate bill discount across lines
      const lineFraction = linesAfterItemDisc > 0 ? afterItem / linesAfterItemDisc : 0;
      const lineAfterBillDisc = afterItem - billDiscountAmount * lineFraction;
      return s + lineAfterBillDisc * ((l.taxRate || 0) / 100);
    }, 0);
    const extra = (parseFloat(form.shippingCharges) || 0) + (parseFloat(form.packagingCharges) || 0) + (parseFloat(form.adjustment) || 0);
    const total = taxableAmount + tax + extra;
    return {
      subtotal,
      discountAmount: itemDisc + billDiscountAmount,
      discountPercentage: subtotal > 0 ? ((itemDisc + billDiscountAmount) / subtotal) * 100 : 0,
      itemDiscountTotal: itemDisc,
      billDiscountAmount,
      billDiscountPercentage: billDiscPct,
      taxableAmount,
      tax, extra, total,
      roundOff: Math.round(total) - total,
    };
  })();

  const openEdit = async (r: any) => {
    const d = await apiFetch(`/documents/${r.id}`);
    setForm(d.data || r);
    setLines(d.data?.items || []);
    setModal(true);
  };

  const save = async () => {
    if (!form.partyName) { toast.error('Select a party'); return; }
    setSaving(true);
    const paid = parseFloat(form.paidAmount) || 0;
    const body = {
      ...form, firmId, documentType: docType,
      items: lines.filter(l => l.name),
      subtotal: totals.subtotal,
      discountAmount: totals.discountAmount,
      discountPercentage: totals.discountPercentage,
      taxAmount: totals.tax,
      shippingCharges: parseFloat(form.shippingCharges) || 0,
      packagingCharges: parseFloat(form.packagingCharges) || 0,
      adjustment: parseFloat(form.adjustment) || 0,
      roundOff: totals.roundOff,
      total: Math.round(totals.total),
      paidAmount: paid,
      balanceAmount: Math.round(totals.total) - paid,
    };
    const r = form.id
      ? await apiFetch(`/documents/${form.id}`, { method: 'PUT', body })
      : await apiFetch('/documents', { method: 'POST', body });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success(form.id ? 'Updated' : 'Created'); setModal(false); load();
  };

  const trash = async (id: string) => {
    if (!confirm('Move to trash?')) return;
    await apiFetch(`/documents/${id}/trash`, { method: 'PATCH' });
    toast.success('Moved to trash'); load();
  };

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));
  const selectParty = (id: string) => {
    const p = parties.find((x: any) => x.id === id);
    if (p) setForm((prev: any) => ({ ...prev, partyId: p.id, partyName: p.name,
      partyType: p.type === 'supplier' ? 'supplier' : 'customer', phone: p.phone, billingAddress: p.address }));
  };

  const badgeColor = (s: string) => ({ active: 'green', draft: 'gray', cancelled: 'red', paid: 'blue' } as any)[s] || 'gray';

  // Quick-create (spec §6): save the new master, add it to local state, select it
  // into the open document, and never touch the rest of `form`/`lines` — so the
  // document the user was mid-way through filling stays exactly as it was.
  const handlePartyCreated = (rec: any) => {
    setParties(prev => [...prev, rec]);
    setForm((prev: any) => ({ ...prev, partyId: rec.id, partyName: rec.name,
      partyType: rec.type === 'supplier' ? 'supplier' : 'customer', phone: rec.phone, billingAddress: rec.address }));
  };
  const handleItemCreated = (rec: any, lineIdx?: number) => {
    setItems(prev => [...prev, rec]);
    if (lineIdx === undefined) return;
    const u = units.find((u: any) => u.id === rec.unitId);
    recalc(lineIdx, { itemId: rec.id, name: rec.name, hsnCode: rec.hsnCode || '',
      price: rec.salePrice, unit: u?.shortName || '', unitId: rec.unitId || '', taxRate: parseFloat(rec.taxRate) || 0 });
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', display: 'flex', gap: 10, alignItems: 'center',
        borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <div style={{ position: 'relative', flex: 1, maxWidth: 380 }}>
          <Search size={13} style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: '#475569' }} />
          <Inp placeholder={`Search ${DOC_LABELS[docType] || 'documents'}…`} value={search}
            onChange={e => setSearch(e.target.value)} style={{ ...IS, paddingLeft: 33 }} />
        </div>
        <Btn onClick={() => {
          const defaultSeries = moduleSettings.multiSeriesEnabled ? series.find((s: any) => s.isDefault) : null;
          setForm({ documentType: docType, documentDate: todayStr(), transactionType: 'cash', paymentType: 'cash', status: 'active',
            seriesId: defaultSeries?.id || '' });
          setLines([blank()]); setModal(true);
          if (defaultSeries) selectSeries(defaultSeries.id);
        }}>
          <Plus size={13} /> New {DOC_LABELS[docType]}
        </Btn>
        <ModuleSettingsButton firmId={firmId} moduleKey={docType} settings={moduleSettings}
          onChange={reloadModuleSettings} toast={toast} isBillingModule={true} />
      </div>

      <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
        <Table
          cols={[
            { key: 'documentNumber', label: 'No.', render: (v: string) => <span style={{ color: '#a5b4fc', fontWeight: 700 }}>{v}</span> },
            { key: 'documentDate',   label: 'Date' },
            { key: 'partyName',      label: 'Party' },
            { key: 'total',          label: 'Total',   align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            { key: 'balanceAmount',  label: 'Balance', align: 'right',
              render: (v: number) => <span style={{ color: v > 0 ? '#f87171' : '#4ade80', fontWeight: 700 }}>{fmt(v)}</span> },
            { key: 'status', label: 'Status', render: (v: string) => <Badge color={badgeColor(v)}>{v}</Badge> },
            { key: 'id', label: '', render: (_: any, r: any) =>
              <div style={{ display: 'flex', gap: 6 }}>
                <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); openEdit(r); }}><Edit size={11} /></Btn>
                <Btn variant="danger" size="sm" onClick={e => { e.stopPropagation(); trash(r.id); }}><Trash2 size={11} /></Btn>
              </div> },
          ]}
          rows={docs}
        />
      </div>

      {/* ── Document Form ── */}
      <Modal open={modal} onClose={() => setModal(false)}
        title={`${form.id ? 'Edit' : 'New'} ${DOC_LABELS[docType]}`} size="xl">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 18 }}>
          {moduleSettings.multiSeriesEnabled && series.length > 0 && (
            <Field label="Series">
              <Sel value={form.seriesId || ''} onChange={e => selectSeries(e.target.value)}>
                <option value="">— Manual / legacy numbering —</option>
                {series.map((s: any) => <option key={s.id} value={s.id}>{s.name} ({s.prefix})</option>)}
              </Sel>
            </Field>
          )}
          <Field label="Doc Number">
            <Inp value={form.documentNumber || 'Auto'} onChange={f('documentNumber')}
              disabled={!!form.seriesId} />
          </Field>
          <Field label="Date" required><Inp type="date" value={form.documentDate || todayStr()} onChange={f('documentDate')} /></Field>
          <Field label="Payment"><Sel value={form.transactionType || 'cash'} onChange={f('transactionType')}>
            <option value="cash">Cash</option><option value="credit">Credit</option>
          </Sel></Field>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Party" required>
              <div style={{ display: 'flex', gap: 8 }}>
                <Sel value={form.partyId || ''} onChange={e => selectParty(e.target.value)} style={{ flex: 1 }}>
                  <option value="">— Select {isSalesDoc ? 'customer' : 'vendor'} —</option>
                  {scopedParties.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </Sel>
                <Btn variant="ghost" size="sm" onClick={() => setQuickCreate({ kind: partyKind })} style={{ flexShrink: 0 }}>
                  <Plus size={12} /> {isSalesDoc ? 'Create Customer' : 'Create Vendor'}
                </Btn>
              </div>
            </Field>
          </div>
          <Field label="Phone"><Inp value={form.phone || ''} onChange={f('phone')} /></Field>
          <div style={{ gridColumn: 'span 3' }}>
            <Field label="Billing Address"><Inp value={form.billingAddress || ''} onChange={f('billingAddress')} /></Field>
          </div>
        </div>

        {/* Line items */}
        <div style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: '#64748b', textTransform: 'uppercase',
            letterSpacing: '.06em', marginBottom: 8 }}>Items</div>
          <div style={{ border: '1px solid #334155', borderRadius: 10, overflow: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: moduleSettings.itemDiscountEnabled ? 960 : 860 }}>
              <thead>
                <tr style={{ background: '#0f172a' }}>
                  {['Item','HSN','Qty','Unit','Price',
                    ...(moduleSettings.itemDiscountEnabled ? ['Disc'] : []),
                    'GST%','Amount',''].map(h => (
                    <th key={h} style={{ padding: '8px 10px', fontSize: 10, fontWeight: 800,
                      color: '#475569', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {lines.map((l: any, idx: number) => (
                  <tr key={l._k || l.id || idx} style={{ borderTop: '1px solid #1e293b' }}>
                    <td style={{ padding: '5px 6px', minWidth: 180 }}>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <Sel value={l.itemId || ''} onChange={e => selectItem(idx, e.target.value)}
                          style={{ ...IS, fontSize: 12, padding: '5px 7px' }}>
                          <option value="">Select…</option>
                          {items.map((i: any) => <option key={i.id} value={i.id}>{i.name}</option>)}
                        </Sel>
                        <button type="button" title="Create Item" onClick={() => setQuickCreate({ kind: 'item', lineIdx: idx })}
                          style={{ background: '#334155', border: 'none', borderRadius: 6, color: '#a5b4fc',
                            width: 26, flexShrink: 0, cursor: 'pointer', lineHeight: 1 }}>
                          <Plus size={12} />
                        </button>
                      </div>
                    </td>
                    {(['hsnCode','quantity'] as const).map(key => (
                      <td key={key} style={{ padding: '5px 4px' }}>
                        <Inp type={key === 'quantity' ? 'number' : 'text'}
                          value={(l as any)[key] ?? ''} onChange={e => recalc(idx, { [key]: key === 'quantity' ? parseFloat(e.target.value)||0 : e.target.value })}
                          style={{ ...IS, fontSize: 12, padding: '5px 7px', width: key === 'hsnCode' ? 80 : 90 }} />
                      </td>
                    ))}
                    <td style={{ padding: '5px 4px' }}>
                      {(() => {
                        const item = items.find((i: any) => i.id === l.itemId);
                        if (moduleSettings.unitsEnabled && item?.secondaryUnitId) {
                          return (
                            <Sel value={l.unitId || item.unitId || ''} onChange={e => selectLineUnit(idx, e.target.value)}
                              style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 76 }}>
                              {item.unitId && <option value={item.unitId}>{item.unitShortName || 'Unit 1'}</option>}
                              <option value={item.secondaryUnitId}>{item.secondaryUnitShortName || 'Unit 2'}</option>
                            </Sel>
                          );
                        }
                        return (
                          <Inp value={l.unit ?? ''} onChange={e => recalc(idx, { unit: e.target.value })}
                            style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 60 }} />
                        );
                      })()}
                    </td>
                    <td style={{ padding: '5px 4px' }}>
                      <Inp type="number"
                        value={l.price ?? ''} onChange={e => recalc(idx, { price: parseFloat(e.target.value)||0 })}
                        style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 90 }} />
                    </td>
                    {moduleSettings.itemDiscountEnabled && (
                      <td style={{ padding: '5px 4px' }}>
                        <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
                          <Inp type="number" min="0"
                            value={l.discount ?? ''} onChange={e => recalc(idx, { discount: parseFloat(e.target.value)||0 })}
                            style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 68 }} />
                          <button
                            onClick={() => recalc(idx, { discountType: l.discountType === 'percentage' ? 'fixed' : 'percentage', discount: 0 })}
                            title={l.discountType === 'percentage' ? 'Switch to Fixed ₹' : 'Switch to Percentage %'}
                            style={{ background: '#334155', border: 'none', borderRadius: 5, color: '#94a3b8',
                              fontSize: 10, fontWeight: 800, padding: '4px 5px', cursor: 'pointer', lineHeight: 1, flexShrink: 0 }}>
                            {l.discountType === 'percentage' ? '%' : '₹'}
                          </button>
                        </div>
                      </td>
                    )}
                    <td style={{ padding: '5px 4px' }}>
                      <Sel value={l.taxRate} onChange={e => recalc(idx, { taxRate: parseFloat(e.target.value) })}
                        style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 72 }}>
                        {[0,5,12,18,28].map(r => <option key={r} value={r}>{r}%</option>)}
                      </Sel>
                    </td>
                    <td style={{ padding: '5px 10px', fontWeight: 800, color: '#f8fafc', whiteSpace: 'nowrap' }}>
                      ₹{(l.amount || 0).toFixed(2)}
                    </td>
                    <td style={{ padding: '5px 6px' }}>
                      <button onClick={() => setLines(p => p.filter((_,i) => i !== idx))}
                        style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', lineHeight: 0 }}>
                        <X size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Btn variant="ghost" size="sm" onClick={() => setLines(p => [...p, blank()])} style={{ marginTop: 8 }}>
            <Plus size={12} /> Add Line
          </Btn>
        </div>

        {/* Totals + charges */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {/* Left column — notes, charges, bill discount */}
          <div>
            <Field label="Notes / Description"><Txt value={form.description || ''} onChange={f('description')} /></Field>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Shipping ₹"><Inp type="number" value={form.shippingCharges || ''} onChange={f('shippingCharges')} /></Field>
              <Field label="Packaging ₹"><Inp type="number" value={form.packagingCharges || ''} onChange={f('packagingCharges')} /></Field>
              <Field label="Adjustment"><Inp type="number" value={form.adjustment || ''} onChange={f('adjustment')} /></Field>
              <Field label="Paid Amount ₹"><Inp type="number" value={form.paidAmount || ''} onChange={f('paidAmount')} /></Field>
            </div>

            {/* Bill-level discount — only shown when enabled in module settings */}
            {moduleSettings.billDiscountEnabled && (
              <div style={{ marginTop: 14, background: '#0f172a', borderRadius: 10, padding: 14,
                border: '1px solid #334155' }}>
                <div style={{ fontSize: 11, fontWeight: 800, color: '#64748b', textTransform: 'uppercase',
                  letterSpacing: '.06em', marginBottom: 10 }}>Bill-Level Discount</div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, color: '#64748b', marginBottom: 4 }}>Percentage (%)</div>
                    <Inp type="number" min="0" max="100" step="0.01"
                      value={form.billDiscountPercentage || ''}
                      onChange={e => { setForm((p: any) => ({ ...p, billDiscountPercentage: e.target.value, billDiscountAmount: '' })); }}
                      placeholder="0.00"
                      style={{ ...IS, width: '100%' }} />
                  </div>
                  <div style={{ color: '#334155', fontWeight: 800, paddingBottom: 8 }}>or</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 11, color: '#64748b', marginBottom: 4 }}>Fixed Amount (₹)</div>
                    <Inp type="number" min="0" step="0.01"
                      value={form.billDiscountAmount || ''}
                      onChange={e => { setForm((p: any) => ({ ...p, billDiscountAmount: e.target.value, billDiscountPercentage: '' })); }}
                      placeholder="0.00"
                      style={{ ...IS, width: '100%' }} />
                  </div>
                </div>
                {totals.billDiscountAmount > 0 && (
                  <div style={{ marginTop: 8, fontSize: 12, color: '#4ade80' }}>
                    Applying {totals.billDiscountPercentage > 0 ? `${totals.billDiscountPercentage.toFixed(2)}%` : ''} bill discount = -{fmt(totals.billDiscountAmount)}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right column — totals summary */}
          <div style={{ background: '#0f172a', borderRadius: 12, padding: 18 }}>
            {/* Subtotal */}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#94a3b8' }}>
              <span>Subtotal</span><span>{fmt(totals.subtotal)}</span>
            </div>

            {/* Item-wise discount subtotal (only if enabled and non-zero) */}
            {moduleSettings.itemDiscountEnabled && totals.itemDiscountTotal > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#fb923c' }}>
                <span>Item Discounts</span><span>-{fmt(totals.itemDiscountTotal)}</span>
              </div>
            )}

            {/* Bill-level discount (only if enabled and non-zero) */}
            {moduleSettings.billDiscountEnabled && totals.billDiscountAmount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#fb923c' }}>
                <span>Bill Discount{totals.billDiscountPercentage > 0 ? ` (${totals.billDiscountPercentage.toFixed(2)}%)` : ''}</span>
                <span>-{fmt(totals.billDiscountAmount)}</span>
              </div>
            )}

            {/* Taxable amount — shown when any discount is active */}
            {totals.discountAmount > 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13,
                color: '#94a3b8', borderTop: '1px dashed #1e293b', paddingTop: 8 }}>
                <span>Taxable Amount</span><span>{fmt(totals.taxableAmount)}</span>
              </div>
            )}

            {/* GST */}
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#94a3b8' }}>
              <span>GST</span><span>+{fmt(totals.tax)}</span>
            </div>

            {/* Extra charges */}
            {totals.extra !== 0 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 13, color: '#94a3b8' }}>
                <span>Charges & Adj.</span><span>{totals.extra >= 0 ? '+' : ''}{fmt(totals.extra)}</span>
              </div>
            )}

            {/* Round-off */}
            {Math.abs(totals.roundOff) > 0.001 && (
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontSize: 12, color: '#64748b' }}>
                <span>Round Off</span><span>{totals.roundOff >= 0 ? '+' : ''}{totals.roundOff.toFixed(2)}</span>
              </div>
            )}

            {/* Grand Total */}
            <div style={{ borderTop: '1px solid #334155', paddingTop: 11,
              display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <span style={{ fontSize: 15, fontWeight: 800, color: '#f8fafc' }}>Total</span>
              <span style={{ fontSize: 22, fontWeight: 900, color: '#6366f1' }}>{fmt(Math.round(totals.total))}</span>
            </div>

            {/* Paid / Balance */}
            {(parseFloat(form.paidAmount) > 0) && (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 9, fontSize: 13 }}>
                  <span style={{ color: '#4ade80' }}>Paid</span>
                  <span style={{ color: '#4ade80', fontWeight: 700 }}>-{fmt(parseFloat(form.paidAmount))}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6, fontSize: 14, fontWeight: 800 }}>
                  <span style={{ color: '#f87171' }}>Balance Due</span>
                  <span style={{ color: '#f87171' }}>{fmt(Math.round(totals.total) - parseFloat(form.paidAmount))}</span>
                </div>
              </>
            )}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : form.id ? 'Update' : 'Create'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>

      <QuickCreateModal
        open={!!quickCreate}
        onClose={() => setQuickCreate(null)}
        kind={quickCreate?.kind || 'item'}
        firmId={firmId}
        toast={toast}
        onCreated={(rec: any) => quickCreate?.kind === 'item' ? handleItemCreated(rec, quickCreate.lineIdx) : handlePartyCreated(rec)}
      />
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAYMENT IN / PAYMENT OUT — bill-wise receipt & payment reconciliation (spec §9–10)
═══════════════════════════════════════════════════════════════════════════ */
function PaymentsPage({ firmId, type, toast }: { firmId: string; type: 'payment_in' | 'payment_out'; toast: any }) {
  const isIn = type === 'payment_in';
  const partyKind: 'customer' | 'supplier' = isIn ? 'customer' : 'supplier';
  const [payments, setPayments] = useState<any[]>([]);
  const [parties, setParties]   = useState<any[]>([]);
  const [banks, setBanks]       = useState<any[]>([]);
  const [modal, setModal]       = useState(false);
  const [quickCreate, setQuickCreate] = useState(false);
  const [form, setForm]         = useState<any>({});
  const [bills, setBills]       = useState<any[]>([]);
  const [alloc, setAlloc]       = useState<Record<string, number>>({});
  const [saving, setSaving]     = useState(false);

  const scopedParties = parties.filter((p: any) => p.type === partyKind || p.type === 'both');

  const load = useCallback(() => {
    apiFetch(`/payments?firmId=${firmId}&type=${type}`).then(r => setPayments(r.data || []));
    apiFetch(`/parties?firmId=${firmId}`).then(r => setParties(r.data || []));
    apiFetch(`/bank?firmId=${firmId}`).then(r => setBanks(r.data || []));
  }, [firmId, type]);

  useEffect(() => { if (firmId) load(); }, [load]);

  const openNew = () => {
    setForm({ paymentDate: todayStr(), paymentMethod: 'cash', amount: '' });
    setBills([]); setAlloc({}); setModal(true);
  };

  const selectParty = async (partyId: string) => {
    const p = parties.find((x: any) => x.id === partyId);
    setForm((f: any) => ({ ...f, partyId, partyName: p?.name || '' }));
    setAlloc({});
    if (!partyId) { setBills([]); return; }
    const r = await apiFetch(`/payments/unpaid-bills?firmId=${firmId}&partyId=${partyId}&partyType=${partyKind}`);
    setBills(r.data || []);
  };

  // Greedy oldest-bill-first allocation against the entered amount — full payment
  // clears exactly one bill, a smaller amount spreads/partially pays across
  // several, any leftover shows as advance/unadjusted (spec §9–10 examples).
  const autoAllocate = (amountStr: string) => {
    let remaining = parseFloat(amountStr) || 0;
    const next: Record<string, number> = {};
    for (const b of bills) {
      if (remaining <= 0) break;
      const take = Math.min(b.balanceAmount, remaining);
      if (take > 0) { next[b.id] = +take.toFixed(2); remaining -= take; }
    }
    setAlloc(next);
  };

  const setLineAlloc = (billId: string, v: string) => setAlloc(prev => ({ ...prev, [billId]: parseFloat(v) || 0 }));

  const allocatedTotal = Object.values(alloc).reduce((s, v) => s + (v || 0), 0);
  const amount = parseFloat(form.amount) || 0;
  const advance = +(amount - allocatedTotal).toFixed(2);

  const save = async () => {
    if (!form.partyName) { toast.error('Select a party'); return; }
    if (!amount) { toast.error('Enter an amount'); return; }
    if (allocatedTotal - amount > 0.004) { toast.error('Allocated amount exceeds payment amount'); return; }
    setSaving(true);
    const allocations = Object.entries(alloc).filter(([, v]) => v > 0).map(([documentId, amt]) => ({ documentId, amount: amt }));
    const r = await apiFetch('/payments', { method: 'POST', body: {
      firmId, type, partyId: form.partyId, partyName: form.partyName, amount,
      paymentMethod: form.paymentMethod || 'cash', bankId: form.bankId,
      receiptNumber: form.receiptNumber, paymentDate: form.paymentDate || todayStr(),
      reference: form.reference, description: form.description, allocations,
    }});
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Saved'); setModal(false); load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this payment? This reverses its bill allocations and cash/bank balance.')) return;
    await apiFetch(`/payments/${id}`, { method: 'DELETE' });
    toast.success('Deleted'); load();
  };

  const handlePartyCreated = (rec: any) => {
    setParties(prev => [...prev, rec]);
    setForm((f: any) => ({ ...f, partyId: rec.id, partyName: rec.name }));
    setBills([]); setAlloc({});
  };

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', display: 'flex', gap: 10, alignItems: 'center',
        borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <div style={{ flex: 1, fontSize: 13, color: '#64748b' }}>
          {isIn ? 'Money received from customers' : 'Money paid to suppliers'}
        </div>
        <Btn onClick={openNew}><Plus size={13} /> New {isIn ? 'Payment In' : 'Payment Out'}</Btn>
      </div>

      <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
        <Table
          cols={[
            { key: 'paymentDate', label: 'Date' },
            { key: 'partyName', label: 'Party' },
            { key: 'amount', label: 'Amount', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            { key: 'paymentMethod', label: 'Method', render: (v: string) => <Badge color={v === 'bank' ? 'blue' : 'green'}>{v}</Badge> },
            { key: 'reference', label: 'Reference' },
            { key: 'id', label: '', render: (_: any, r: any) =>
              <Btn variant="danger" size="sm" onClick={e => { e.stopPropagation(); remove(r.id); }}><Trash2 size={11} /></Btn> },
          ]}
          rows={payments}
          empty={`No ${isIn ? 'receipts' : 'payments'} yet.`}
        />
      </div>

      <Modal open={modal} onClose={() => setModal(false)} title={isIn ? 'New Payment In (Receipt)' : 'New Payment Out'} size="lg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Party" required>
              <div style={{ display: 'flex', gap: 8 }}>
                <Sel value={form.partyId || ''} onChange={e => selectParty(e.target.value)} style={{ flex: 1 }}>
                  <option value="">— Select {isIn ? 'customer' : 'vendor'} —</option>
                  {scopedParties.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </Sel>
                <Btn variant="ghost" size="sm" onClick={() => setQuickCreate(true)} style={{ flexShrink: 0 }}>
                  <Plus size={12} /> {isIn ? 'Create Customer' : 'Create Vendor'}
                </Btn>
              </div>
            </Field>
          </div>
          <Field label="Amount (₹)" required>
            <Inp type="number" value={form.amount || ''}
              onChange={e => setForm((f: any) => ({ ...f, amount: e.target.value }))} placeholder="0.00" />
          </Field>
          <Field label="Date" required><Inp type="date" value={form.paymentDate || todayStr()}
            onChange={e => setForm((f: any) => ({ ...f, paymentDate: e.target.value }))} /></Field>
          <Field label="Payment Method"><Sel value={form.paymentMethod || 'cash'}
            onChange={e => setForm((f: any) => ({ ...f, paymentMethod: e.target.value }))}>
            <option value="cash">Cash</option><option value="bank">Bank</option>
          </Sel></Field>
          {form.paymentMethod === 'bank' && (
            <Field label="Bank Account"><Sel value={form.bankId || ''}
              onChange={e => setForm((f: any) => ({ ...f, bankId: e.target.value }))}>
              <option value="">— Select —</option>
              {banks.map((b: any) => <option key={b.id} value={b.id}>{b.accountName}</option>)}
            </Sel></Field>
          )}
          <Field label="Reference / Cheque No."><Inp value={form.reference || ''}
            onChange={e => setForm((f: any) => ({ ...f, reference: e.target.value }))} /></Field>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Notes"><Inp value={form.description || ''}
              onChange={e => setForm((f: any) => ({ ...f, description: e.target.value }))} /></Field>
          </div>
        </div>

        {form.partyId && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <div style={{ fontSize: 11, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>
                Unpaid {isIn ? 'Sales Bills' : 'Purchase Bills'}
              </div>
              <Btn variant="ghost" size="sm" onClick={() => autoAllocate(form.amount)}>Auto-Allocate</Btn>
            </div>
            {bills.length === 0 ? (
              <div style={{ fontSize: 12, color: '#475569', padding: '10px 0' }}>No outstanding bills for this party.</div>
            ) : (
              <div style={{ border: '1px solid #334155', borderRadius: 10, overflow: 'hidden' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: '#0f172a' }}>
                      {['Bill No.','Date','Total','Balance','Applying'].map(h =>
                        <th key={h} style={{ padding: '8px 10px', fontSize: 10, fontWeight: 800, color: '#475569',
                          textTransform: 'uppercase', textAlign: (h === 'Applying' || h === 'Total' || h === 'Balance') ? 'right' : 'left' }}>{h}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {bills.map((b: any) => (
                      <tr key={b.id} style={{ borderTop: '1px solid #1e293b' }}>
                        <td style={{ padding: '6px 10px', color: '#a5b4fc', fontWeight: 700 }}>{b.documentNumber}</td>
                        <td style={{ padding: '6px 10px' }}>{b.documentDate}</td>
                        <td style={{ padding: '6px 10px', textAlign: 'right' }}>{fmt(b.total)}</td>
                        <td style={{ padding: '6px 10px', textAlign: 'right', color: '#f87171' }}>{fmt(b.balanceAmount)}</td>
                        <td style={{ padding: '5px 8px', textAlign: 'right' }}>
                          <Inp type="number" value={alloc[b.id] ?? ''} onChange={e => setLineAlloc(b.id, e.target.value)}
                            style={{ ...IS, fontSize: 12, padding: '5px 7px', width: 100, textAlign: 'right' }} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 24, marginTop: 10, fontSize: 12 }}>
              <span style={{ color: '#94a3b8' }}>Allocated: <strong style={{ color: '#f8fafc' }}>{fmt(allocatedTotal)}</strong></span>
              <span style={{ color: advance > 0.004 ? '#f59e0b' : '#475569' }}>
                {advance > 0.004 ? `Advance / Unadjusted: ${fmt(advance)}` : advance < -0.004 ? `Over-allocated by ${fmt(-advance)}` : 'Fully applied'}
              </span>
            </div>
          </div>
        )}

        <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
          <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>

      <QuickCreateModal open={quickCreate} onClose={() => setQuickCreate(false)} kind={partyKind}
        firmId={firmId} toast={toast} onCreated={handlePartyCreated} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   GST REPORTS — GSTR-1 (outward supplies) & GSTR-3B (summary return)
═══════════════════════════════════════════════════════════════════════════ */
function GstReports({ firmId }: { firmId: string }) {
  const [tab, setTab] = useState<'gstr1' | 'gstr3b'>('gstr1');
  const [start, setStart] = useState(todayStr().slice(0,7) + '-01');
  const [end,   setEnd]   = useState(todayStr());
  const [gstr1, setGstr1] = useState<any>(null);
  const [gstr3b, setGstr3b] = useState<any>(null);

  useEffect(() => {
    if (!firmId) return;
    const qs = `firmId=${firmId}&startDate=${start}&endDate=${end}`;
    apiFetch(`/reports/gstr1?${qs}`).then(r => setGstr1(r.data));
    apiFetch(`/reports/gstr3b?${qs}`).then(r => setGstr3b(r.data));
  }, [firmId, start, end]);

  const TabBtn = ({ id, label }: { id: 'gstr1' | 'gstr3b'; label: string }) => (
    <button onClick={() => setTab(id)} style={{
      background: tab === id ? '#6366f1' : '#1e293b', color: tab === id ? '#fff' : '#94a3b8',
      border: '1px solid ' + (tab === id ? '#6366f1' : '#334155'), borderRadius: 8, padding: '8px 16px',
      fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>{label}</button>
  );

  // Direct browser download — the backend sets Content-Disposition: attachment,
  // so opening the export URL in a new tab downloads the file instead of navigating.
  const exportReport = (format: 'xlsx' | 'json') => {
    const endpoint = tab === 'gstr1' ? '/reports/gstr1/export' : '/reports/gstr3b/export';
    window.open(`${API_BASE}${endpoint}?firmId=${firmId}&startDate=${start}&endDate=${end}&format=${format}`, '_blank');
  };

  const TaxRow = ({ label, v, bold }: { label: string; v: number; bold?: boolean }) => (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '9px 0', borderBottom: '1px solid #1e293b' }}>
      <span style={{ fontSize: 13, color: '#94a3b8', fontWeight: bold ? 700 : 400 }}>{label}</span>
      <span style={{ fontSize: 14, color: '#f8fafc', fontWeight: bold ? 900 : 700 }}>{fmt(v)}</span>
    </div>
  );

  return (
    <div style={{ padding: 24, overflowY: 'auto', flex: 1 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <TabBtn id="gstr1" label="GSTR-1" />
        <TabBtn id="gstr3b" label="GSTR-3B" />
        <div style={{ flex: 1 }} />
        <Inp type="date" value={start} onChange={e => setStart(e.target.value)} style={{ ...IS, width: 155 }} />
        <span style={{ color: '#64748b' }}>→</span>
        <Inp type="date" value={end} onChange={e => setEnd(e.target.value)} style={{ ...IS, width: 155 }} />
        <Btn variant="ghost" onClick={() => exportReport('xlsx')}><Download size={13} /> Export Excel</Btn>
        <Btn variant="ghost" onClick={() => exportReport('json')}><Download size={13} /> Export JSON</Btn>
      </div>
      <div style={{ fontSize: 11, color: '#64748b', marginBottom: 20 }}>
        Computed from your sales/purchase ledger for reference — verify against the GST portal before filing.
        Reverse charge, exempt/nil-rated/non-GST supplies, advances and amendments aren't modelled.
      </div>

      {tab === 'gstr1' && gstr1 && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(170px,1fr))', gap: 14, marginBottom: 24 }}>
            <StatCard label="Taxable Value" value={fmt(gstr1.summary.taxableValue)} icon={IndianRupee} color="#6366f1" />
            <StatCard label="IGST" value={fmt(gstr1.summary.igst)} icon={FileCheck} color="#8b5cf6" />
            <StatCard label="CGST" value={fmt(gstr1.summary.cgst)} icon={FileCheck} color="#0ea5e9" />
            <StatCard label="SGST" value={fmt(gstr1.summary.sgst)} icon={FileCheck} color="#14b8a6" />
            <StatCard label="Total Tax" value={fmt(gstr1.summary.totalTax)} icon={PieChart} color="#10b981" />
            <StatCard label="Total Invoices" value={String(gstr1.summary.totalInvoices)} icon={Receipt} color="#f59e0b" />
          </div>

          <SectionTable title="B2B Invoices (Table 4A) — supplies to registered persons"
            cols={[
              { key: 'documentNumber', label: 'Invoice No.' }, { key: 'documentDate', label: 'Date' },
              { key: 'partyName', label: 'Party' }, { key: 'partyGstin', label: 'GSTIN' },
              { key: 'placeOfSupply', label: 'Place of Supply' },
              { key: 'taxableValue', label: 'Taxable ₹', align: 'right', render: (v: number) => fmt(v) },
              { key: 'igst', label: 'IGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'cgst', label: 'CGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'sgst', label: 'SGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'invoiceValue', label: 'Invoice ₹', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            ]} rows={gstr1.b2b} empty="No B2B invoices in this period." />

          <SectionTable title="B2C Large (Table 5) — unregistered, interstate, invoice value > ₹2.5L"
            cols={[
              { key: 'documentNumber', label: 'Invoice No.' }, { key: 'documentDate', label: 'Date' },
              { key: 'placeOfSupply', label: 'Place of Supply' },
              { key: 'taxableValue', label: 'Taxable ₹', align: 'right', render: (v: number) => fmt(v) },
              { key: 'igst', label: 'IGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'invoiceValue', label: 'Invoice ₹', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            ]} rows={gstr1.b2cLarge} empty="No B2C Large invoices in this period." />

          <SectionTable title="B2C Small (Table 7) — consolidated by place of supply & rate"
            cols={[
              { key: 'placeOfSupply', label: 'Place of Supply' },
              { key: 'taxRate', label: 'Rate', align: 'center', render: (v: number) => `${v}%` },
              { key: 'taxableValue', label: 'Taxable ₹', align: 'right', render: (v: number) => fmt(v) },
              { key: 'igst', label: 'IGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'cgst', label: 'CGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'sgst', label: 'SGST', align: 'right', render: (v: number) => fmt(v) },
            ]} rows={gstr1.b2cSmall} empty="No B2C Small supplies in this period." />

          <SectionTable title="Credit Notes (Table 9B) — sales returns"
            cols={[
              { key: 'documentNumber', label: 'Note No.' }, { key: 'documentDate', label: 'Date' },
              { key: 'partyName', label: 'Party' }, { key: 'partyGstin', label: 'GSTIN' },
              { key: 'taxableValue', label: 'Taxable ₹', align: 'right', render: (v: number) => fmt(v) },
              { key: 'igst', label: 'IGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'cgst', label: 'CGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'sgst', label: 'SGST', align: 'right', render: (v: number) => fmt(v) },
            ]} rows={gstr1.creditNotes} empty="No credit notes in this period." />

          <SectionTable title="HSN-wise Summary (Table 12)"
            cols={[
              { key: 'hsnCode', label: 'HSN/SAC' }, { key: 'description', label: 'Description' },
              { key: 'unit', label: 'UQC' }, { key: 'quantity', label: 'Qty', align: 'right', render: (v: number) => fmtN(v) },
              { key: 'taxRate', label: 'Rate', align: 'center', render: (v: number) => `${v}%` },
              { key: 'taxableValue', label: 'Taxable ₹', align: 'right', render: (v: number) => fmt(v) },
              { key: 'igst', label: 'IGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'cgst', label: 'CGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'sgst', label: 'SGST', align: 'right', render: (v: number) => fmt(v) },
              { key: 'totalValue', label: 'Total ₹', align: 'right', render: (v: number) => <strong>{fmt(v)}</strong> },
            ]} rows={gstr1.hsnSummary} empty="No items in this period." />
        </>
      )}

      {tab === 'gstr3b' && gstr3b && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, maxWidth: 900 }}>
          <div style={{ background: '#1e293b', borderRadius: 14, padding: 22, border: '1px solid #334155' }}>
            <h3 style={{ margin: '0 0 4px', fontSize: 15, fontWeight: 900, color: '#f8fafc' }}>3.1 Outward Taxable Supplies</h3>
            <div style={{ fontSize: 11, color: '#64748b', marginBottom: 14 }}>Net of credit notes (sales returns)</div>
            <TaxRow label="Taxable Value" v={gstr3b.outwardSupplies.taxableValue} bold />
            <TaxRow label="IGST" v={gstr3b.outwardSupplies.igst} />
            <TaxRow label="CGST" v={gstr3b.outwardSupplies.cgst} />
            <TaxRow label="SGST" v={gstr3b.outwardSupplies.sgst} />
          </div>

          <div style={{ background: '#1e293b', borderRadius: 14, padding: 22, border: '1px solid #334155' }}>
            <h3 style={{ margin: '0 0 4px', fontSize: 15, fontWeight: 900, color: '#f8fafc' }}>4. Eligible ITC</h3>
            <div style={{ fontSize: 11, color: '#64748b', marginBottom: 14 }}>All other ITC, net of purchase returns</div>
            <TaxRow label="Taxable Value" v={gstr3b.itc.taxableValue} bold />
            <TaxRow label="IGST" v={gstr3b.itc.igst} />
            <TaxRow label="CGST" v={gstr3b.itc.cgst} />
            <TaxRow label="SGST" v={gstr3b.itc.sgst} />
          </div>

          <div style={{ background: '#1e293b', borderRadius: 14, padding: 22, border: '1px solid #334155', gridColumn: 'span 2' }}>
            <h3 style={{ margin: '0 0 4px', fontSize: 15, fontWeight: 900, color: '#f8fafc' }}>6.1 Net Tax Payable</h3>
            <div style={{ fontSize: 11, color: '#64748b', marginBottom: 14 }}>
              Output tax minus ITC per head — the portal applies IGST credit set-off against CGST/SGST automatically, which this simplified view does not.
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 14 }}>
              <StatCard label="IGST Payable" value={fmt(gstr3b.netTaxPayable.igst)} icon={IndianRupee} color="#8b5cf6" />
              <StatCard label="CGST Payable" value={fmt(gstr3b.netTaxPayable.cgst)} icon={IndianRupee} color="#0ea5e9" />
              <StatCard label="SGST Payable" value={fmt(gstr3b.netTaxPayable.sgst)} icon={IndianRupee} color="#14b8a6" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SectionTable({ title, cols, rows, empty }: { title: string; cols: Col[]; rows: any[]; empty: string }) {
  return (
    <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden', marginBottom: 20 }}>
      <div style={{ padding: '14px 18px', borderBottom: '1px solid #334155' }}>
        <span style={{ fontSize: 12, fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '.06em' }}>{title}</span>
      </div>
      <Table cols={cols} rows={rows} empty={empty} />
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   REPORTS
═══════════════════════════════════════════════════════════════════════════ */
function Reports({ firmId, subView }: any) {
  const [data, setData] = useState<any>(null);
  const [start, setStart] = useState(todayStr().slice(0,7) + '-01');
  const [end,   setEnd]   = useState(todayStr());

  const EP: Record<string, string> = {
    report_pl:          '/reports/profit-loss',
    report_stock:       '/reports/stock-summary',
    report_outstanding: '/reports/party-outstanding',
    report_daybook:     '/reports/day-book',
  };

  useEffect(() => {
    if (subView === 'report_gst') return; // GstReports fetches its own two endpoints
    if (!firmId || !EP[subView]) return;
    apiFetch(`${EP[subView]}?firmId=${firmId}&startDate=${start}&endDate=${end}&date=${todayStr()}`).then(r => setData(r.data));
  }, [firmId, subView, start, end]);

  if (subView === 'report_gst') return <GstReports firmId={firmId} />;

  const DatePicker = () => (
    <div style={{ display: 'flex', gap: 10, marginBottom: 20, alignItems: 'center' }}>
      <Inp type="date" value={start} onChange={e => setStart(e.target.value)} style={{ ...IS, width: 155 }} />
      <span style={{ color: '#64748b' }}>→</span>
      <Inp type="date" value={end} onChange={e => setEnd(e.target.value)} style={{ ...IS, width: 155 }} />
    </div>
  );

  if (subView === 'report_pl') return (
    <div style={{ padding: 24 }}>
      <DatePicker />
      {data && (
        <div style={{ background: '#1e293b', borderRadius: 16, padding: 28, maxWidth: 480, border: '1px solid #334155' }}>
          <h2 style={{ margin: '0 0 22px', fontSize: 18, fontWeight: 900, color: '#f8fafc' }}>Profit & Loss</h2>
          {[
            { l: 'Gross Sales',    v: data.sales,        c: '#4ade80' },
            { l: 'Sale Returns',   v: -data.saleReturns, c: '#f87171' },
            { l: 'Net Sales',      v: data.netSales,     c: '#f8fafc', bold: true },
            { l: 'Purchases',      v: -data.purchases,   c: '#f87171' },
            { l: 'Gross Profit',   v: data.grossProfit,  c: data.grossProfit >= 0 ? '#4ade80' : '#f87171', bold: true },
            { l: 'Expenses',       v: -data.expenses,    c: '#f87171' },
            { l: 'Net Profit',     v: data.netProfit,    c: data.netProfit >= 0 ? '#4ade80' : '#ef4444', bold: true },
          ].map(({ l, v, c, bold }) => (
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '11px 0',
              borderBottom: '1px solid #1e293b' }}>
              <span style={{ fontSize: 14, color: '#94a3b8', fontWeight: bold ? 700 : 400 }}>{l}</span>
              <span style={{ fontSize: 15, color: c, fontWeight: bold ? 900 : 700 }}>{fmt(Math.abs(v))}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  if (subView === 'report_stock') return (
    <div style={{ padding: 22 }}>
      <Table
        cols={[
          { key: 'name',         label: 'Item', render: (v: string, r: any) =>
            <div><div style={{ fontWeight: 700 }}>{v}</div>
              <div style={{ fontSize: 11, color: '#475569' }}>{r.categoryName || '—'}</div></div> },
          { key: 'currentStock', label: 'Stock', align: 'right',
            render: (v: number, r: any) =>
              <span style={{ fontWeight: 800, color: v <= (r.minStockLevel||0) ? '#ef4444' : '#4ade80' }}>
                {fmtN(v||0)}
              </span> },
          { key: 'minStockLevel', label: 'Min',    align: 'right' },
          { key: 'purchasePrice', label: 'Cost ₹', align: 'right', render: (v: number) => fmt(v) },
          { key: 'salePrice',     label: 'Sale ₹', align: 'right', render: (v: number) => fmt(v) },
          { key: 'id', label: 'Stock Value', align: 'right',
            render: (_: any, r: any) => fmt((r.currentStock||0) * (r.purchasePrice||0)) },
        ]}
        rows={Array.isArray(data) ? data : []}
      />
    </div>
  );

  if (subView === 'report_outstanding') return (
    <div style={{ padding: 22 }}>
      <Table
        cols={[
          { key: 'partyName',   label: 'Party' },
          { key: 'invoiceCount',label: 'Invoices', align: 'center' },
          { key: 'outstanding', label: 'Outstanding', align: 'right',
            render: (v: number) => <span style={{ fontWeight: 800, color: '#f87171' }}>{fmt(v)}</span> },
        ]}
        rows={Array.isArray(data) ? data : []}
      />
    </div>
  );

  return (
    <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>
      Select a date range above and a report from the sidebar.
      {!EP[subView] && <div style={{ marginTop: 8, fontSize: 13 }}>Report view: <code>{subView}</code></div>}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   HR & PAYROLL
═══════════════════════════════════════════════════════════════════════════ */
function HR({ firmId, subView, toast }: any) {
  const [emps,  setEmps]  = useState<any[]>([]);
  const [modal, setModal] = useState(false);
  const [form,  setForm]  = useState<any>({});
  const [saving, setSaving] = useState(false);
  const [payrollResult, setPayrollResult] = useState<any>(null);

  const loadEmps = useCallback(() => {
    apiFetch(`/hr/employees?firmId=${firmId}`).then(r => setEmps(r.data || []));
  }, [firmId]);

  useEffect(() => { if (firmId) loadEmps(); }, [loadEmps]);

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));

  const saveEmp = async () => {
    if (!form.firstName) { toast.error('First name required'); return; }
    setSaving(true);
    const r = form.id
      ? await apiFetch(`/hr/employees/${form.id}`, { method: 'PUT', body: { ...form, firmId } })
      : await apiFetch('/hr/employees', { method: 'POST', body: { ...form, firmId } });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Employee saved'); setModal(false); loadEmps();
  };

  const runPayroll = async () => {
    const d = new Date();
    setSaving(true);
    const r = await apiFetch('/hr/payroll/run', { method: 'POST',
      body: { firmId, month: d.getMonth() + 1, year: d.getFullYear() } });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Payroll generated'); setPayrollResult(r.data);
  };

  if (subView === 'employees') return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', borderBottom: '1px solid #1e293b', flexShrink: 0 }}>
        <Btn onClick={() => { setForm({}); setModal(true); }}><Plus size={13} /> Add Employee</Btn>
      </div>
      <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
        <Table
          cols={[
            { key: 'firstName', label: 'Name', render: (v: string, r: any) =>
              <div><div style={{ fontWeight: 700 }}>{v} {r.lastName || ''}</div>
                <div style={{ fontSize: 11, color: '#475569' }}>{r.employeeCode || r.designation || '—'}</div></div> },
            { key: 'department',  label: 'Department' },
            { key: 'designation', label: 'Designation' },
            { key: 'phone',       label: 'Phone' },
            { key: 'salary',      label: 'Salary', align: 'right', render: (v: number) => fmt(v) },
            { key: 'salaryType',  label: 'Type', render: (v: string) => <Badge color="purple">{v}</Badge> },
            { key: 'status', label: 'Status', render: (v: string) =>
              <Badge color={v === 'active' ? 'green' : 'red'}>{v}</Badge> },
            { key: 'id', label: '', render: (_: any, r: any) =>
              <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); setForm(r); setModal(true); }}>
                <Edit size={11} />
              </Btn> },
          ]}
          rows={emps}
        />
      </div>
      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? 'Edit Employee' : 'Add Employee'} size="lg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="First Name" required><Inp value={form.firstName || ''} onChange={f('firstName')} /></Field>
          <Field label="Last Name"><Inp value={form.lastName || ''} onChange={f('lastName')} /></Field>
          <Field label="Employee Code"><Inp value={form.employeeCode || ''} onChange={f('employeeCode')} /></Field>
          <Field label="Phone"><Inp value={form.phone || ''} onChange={f('phone')} /></Field>
          <Field label="Email"><Inp value={form.email || ''} onChange={f('email')} /></Field>
          <Field label="Department"><Inp value={form.department || ''} onChange={f('department')} /></Field>
          <Field label="Designation"><Inp value={form.designation || ''} onChange={f('designation')} /></Field>
          <Field label="Joining Date"><Inp type="date" value={form.joiningDate || ''} onChange={f('joiningDate')} /></Field>
          <Field label="Monthly Salary (₹)" required><Inp type="number" value={form.salary || ''} onChange={f('salary')} /></Field>
          <Field label="Salary Type"><Sel value={form.salaryType || 'monthly'} onChange={f('salaryType')}>
            <option value="monthly">Monthly</option><option value="daily">Daily</option>
          </Sel></Field>
          <Field label="PAN Number"><Inp value={form.panNumber || ''} onChange={f('panNumber')} /></Field>
          <Field label="Aadhar Number"><Inp value={form.aadharNumber || ''} onChange={f('aadharNumber')} /></Field>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
          <Btn onClick={saveEmp} disabled={saving}>{saving ? 'Saving…' : 'Save Employee'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>
    </div>
  );

  if (subView === 'payroll') return (
    <div style={{ padding: 24 }}>
      <Btn onClick={runPayroll} disabled={saving} style={{ marginBottom: 20 }}>
        <Calculator size={14} /> {saving ? 'Processing…' : `Run Payroll · ${new Date().toLocaleString('en-IN',{month:'long',year:'numeric'})}`}
      </Btn>
      {payrollResult && (
        <>
          <div style={{ marginBottom: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontWeight: 800, color: '#f8fafc' }}>Payroll Summary</span>
            <span style={{ color: '#4ade80', fontWeight: 800 }}>Total: {fmt(payrollResult.totalAmount)}</span>
          </div>
          <Table
            cols={[
              { key: 'employeeName', label: 'Employee' },
              { key: 'basicSalary',  label: 'Basic',    align: 'right', render: (v: number) => fmt(v) },
              { key: 'presentDays',  label: 'Days',     align: 'center' },
              { key: 'earnedSalary', label: 'Earned',   align: 'right', render: (v: number) => fmt(v) },
              { key: 'netSalary',    label: 'Net Salary', align: 'right',
                render: (v: number) => <span style={{ color: '#4ade80', fontWeight: 800 }}>{fmt(v)}</span> },
            ]}
            rows={payrollResult.items || []}
          />
        </>
      )}
    </div>
  );

  return <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>Select a module from HR & Payroll.</div>;
}

/* ══════════════════════════════════════════════════════════════════════════
   SETTINGS → MODULE MANAGEMENT → MULTIPLE SERIES
═══════════════════════════════════════════════════════════════════════════ */
const SERIES_TXN_TYPES_SAFE: [string, string][] = [
  ['sale_invoice', 'Sales Invoice'], ['sale_return', 'Sales Return'],
  ['sale_order', 'Sales Order'], ['sale_quotation', 'Quotation'], ['delivery_challan', 'Sales Challan'],
  ['purchase_invoice', 'Purchase Invoice'], ['purchase_return', 'Purchase Return'],
  ['purchase_order', 'Purchase Order'],
  ['expense', 'Expense'],
];

function SeriesManagement({ firmId, toast }: any) {
  const [series, setSeries] = useState<any[]>([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState<any>({});
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    apiFetch(`/series?firmId=${firmId}`).then(r => setSeries(r.data || []));
  }, [firmId]);

  useEffect(() => { if (firmId) load(); }, [load]);

  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));

  const save = async () => {
    if (!form.name || !form.prefix || !form.transactionType) {
      toast.error('Series name, prefix and transaction type are required'); return;
    }
    setSaving(true);
    const body = { ...form, firmId, numberLength: parseInt(form.numberLength) || 4,
      startingNumber: parseInt(form.startingNumber) || 1 };
    const r = form.id
      ? await apiFetch(`/series/${form.id}`, { method: 'PUT', body })
      : await apiFetch('/series', { method: 'POST', body });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Series saved'); setModal(false); load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this series? (Only allowed if it has never generated a number — otherwise deactivate it instead.)')) return;
    const r = await apiFetch(`/series/${id}`, { method: 'DELETE' });
    if (r.error) { toast.error(r.error); return; }
    toast.success('Series deleted'); load();
  };

  const toggleActive = async (s: any) => {
    const r = await apiFetch(`/series/${s.id}`, { method: 'PUT', body: { ...s, isActive: !s.isActive } });
    if (r.error) { toast.error(r.error); return; }
    load();
  };

  const groupedByType = SERIES_TXN_TYPES_SAFE.map(([type, label]) => ({
    type, label, items: series.filter(s => s.transactionType === type)
  }));

  return (
    <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 800, color: '#f8fafc', display: 'flex', alignItems: 'center', gap: 8 }}>
            <Layers size={16} color="#6366f1" /> Multiple Series
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 3 }}>
            Create independent numbering series per transaction type. Each series keeps its own counter.
          </div>
        </div>
        <Btn onClick={() => {
          setForm({ transactionType: 'sale_invoice', numberLength: 4, startingNumber: 1, isActive: true });
          setModal(true);
        }}>
          <Plus size={13} /> New Series
        </Btn>
      </div>

      {groupedByType.map(({ type, label, items: rows }) => rows.length > 0 && (
        <div key={type} style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: '#475569', textTransform: 'uppercase',
            letterSpacing: '.06em', marginBottom: 8 }}>{label}</div>
          <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'hidden' }}>
            <Table
              cols={[
                { key: 'isDefault', label: '', render: (v: number) => v ? <Star size={13} color="#f59e0b" fill="#f59e0b" /> : null },
                { key: 'name', label: 'Series Name' },
                { key: 'prefix', label: 'Prefix' },
                { key: 'currentNumber', label: 'Next Number', align: 'right',
                  render: (v: number, r: any) => {
                    const padded = String(v).padStart(r.numberLength, '0');
                    return <span style={{ fontFamily: 'monospace', color: '#a5b4fc' }}>
                      {r.includeFinancialYearInNumber && r.financialYear ? `${r.prefix}/${r.financialYear}/${padded}` : `${r.prefix}-${padded}`}
                    </span>;
                  } },
                { key: 'isActive', label: 'Status', render: (v: number) =>
                  <Badge color={v ? 'green' : 'gray'}>{v ? 'Active' : 'Inactive'}</Badge> },
                { key: 'id', label: '', render: (_: any, r: any) =>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); setForm(r); setModal(true); }}>
                      <Edit size={11} />
                    </Btn>
                    <Btn variant="ghost" size="sm" onClick={e => { e.stopPropagation(); toggleActive(r); }}>
                      {r.isActive ? 'Deactivate' : 'Activate'}
                    </Btn>
                    <Btn variant="danger" size="sm" onClick={e => { e.stopPropagation(); remove(r.id); }}>
                      <Trash2 size={11} />
                    </Btn>
                  </div> },
              ]}
              rows={rows}
            />
          </div>
        </div>
      ))}
      {series.length === 0 && (
        <div style={{ padding: 40, textAlign: 'center', color: '#64748b', background: '#1e293b', borderRadius: 14, border: '1px solid #334155' }}>
          No series created yet. Existing documents keep using the default firm-level numbering until you add one.
        </div>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title={form.id ? 'Edit Series' : 'New Series'} size="lg">
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <Field label="Series Name" required><Inp value={form.name || ''} onChange={f('name')} placeholder="e.g. Retail Invoice" /></Field>
          <Field label="Prefix / Code" required><Inp value={form.prefix || ''} onChange={f('prefix')} placeholder="e.g. RET" /></Field>
          <Field label="Transaction Type" required>
            <Sel value={form.transactionType || 'sale_invoice'} onChange={f('transactionType')} disabled={!!form.id}>
              {SERIES_TXN_TYPES_SAFE.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </Sel>
          </Field>
          <Field label="Starting Number"><Inp type="number" value={form.startingNumber ?? 1} onChange={f('startingNumber')} disabled={!!form.id} /></Field>
          <Field label="Number Length"><Inp type="number" value={form.numberLength ?? 4} onChange={f('numberLength')} placeholder="4" /></Field>
          <Field label="Financial Year"><Inp value={form.financialYear || ''} onChange={f('financialYear')} placeholder="26-27" /></Field>
          <Field label="Include FY in Number">
            <Sel value={form.includeFinancialYearInNumber ? '1' : '0'} onChange={e => setForm((p: any) => ({ ...p, includeFinancialYearInNumber: e.target.value === '1' }))}>
              <option value="0">No — e.g. RET-00001</option>
              <option value="1">Yes — e.g. INV/26-27/00001</option>
            </Sel>
          </Field>
          <Field label="Reset Numbering Yearly">
            <Sel value={form.resetYearly ? '1' : '0'} onChange={e => setForm((p: any) => ({ ...p, resetYearly: e.target.value === '1' }))}>
              <option value="0">Continue across years</option>
              <option value="1">Reset to starting number each financial year</option>
            </Sel>
          </Field>
          <Field label="Default Series for this type">
            <Sel value={form.isDefault ? '1' : '0'} onChange={e => setForm((p: any) => ({ ...p, isDefault: e.target.value === '1' }))}>
              <option value="0">No</option>
              <option value="1">Yes — auto-select on new transactions</option>
            </Sel>
          </Field>
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
          <Btn onClick={save} disabled={saving}>{saving ? 'Saving…' : form.id ? 'Update Series' : 'Create Series'}</Btn>
          <Btn variant="ghost" onClick={() => setModal(false)}>Cancel</Btn>
        </div>
      </Modal>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   SETTINGS → MODULE MANAGEMENT → PER-MODULE TOGGLES
   (Multi-Series / Units & Conversion, independently for every module)
═══════════════════════════════════════════════════════════════════════════ */
const DEFAULT_MODULE_SETTINGS: ModuleSettings = { multiSeriesEnabled: true, unitsEnabled: true, itemDiscountEnabled: true, billDiscountEnabled: true };

function ModuleSettingsPage({ firmId, toast }: any) {
  const [all, setAll] = useState<Record<string, ModuleSettings>>({});

  const load = useCallback(() => {
    apiFetch(`/settings/${firmId}/modules`).then(r => { if (r.data) setAll(r.data); });
  }, [firmId]);

  useEffect(() => { if (firmId) load(); }, [load]);

  const toggle = async (moduleKey: string, key: keyof ModuleSettings) => {
    const current: ModuleSettings = all[moduleKey] || { ...DEFAULT_MODULE_SETTINGS };
    const r = await apiFetch(`/settings/${firmId}/modules/${moduleKey}`, {
      method: 'PUT', body: { [key]: !current[key] },
    });
    if (r.error) { toast.error(r.error); return; }
    setAll((p: any) => ({ ...p, [moduleKey]: r.data }));
    toast.success('Saved');
  };

  // Columns: which keys apply to which modules
  const cols: { key: keyof ModuleSettings; label: string; exclude?: string[] }[] = [
    { key: 'multiSeriesEnabled', label: 'Multi-Series',       exclude: ['items'] },
    { key: 'unitsEnabled',        label: 'Units & Conversion' },
    { key: 'itemDiscountEnabled', label: 'Item Discount',      exclude: ['items'] },  // items module doesn't use billing discounts
    { key: 'billDiscountEnabled', label: 'Bill Discount',      exclude: ['items'] },
  ];

  return (
    <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
      <div style={{ marginBottom: 18 }}>
        <div style={{ fontSize: 16, fontWeight: 800, color: '#f8fafc' }}>Module Settings</div>
        <div style={{ fontSize: 12, color: '#64748b', marginTop: 3 }}>
          Enable or disable features independently for each module. Changes apply immediately and never affect other modules.
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 14, flexWrap: 'wrap' }}>
        {cols.map(c => (
          <div key={c.key} style={{ fontSize: 11, color: '#64748b', display: 'flex', alignItems: 'center', gap: 5 }}>
            <span style={{ width: 8, height: 8, borderRadius: 2, background: '#6366f1', display: 'inline-block' }} />
            {c.label}
          </div>
        ))}
      </div>

      <div style={{ background: '#1e293b', borderRadius: 14, border: '1px solid #334155', overflow: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 600 }}>
          <thead>
            <tr style={{ background: '#0f172a' }}>
              <th style={{ padding: '10px 16px', textAlign: 'left', fontSize: 10, fontWeight: 800,
                color: '#475569', textTransform: 'uppercase', letterSpacing: '.06em' }}>Module</th>
              {cols.map(c => (
                <th key={c.key} style={{ padding: '10px 14px', textAlign: 'center', fontSize: 10, fontWeight: 800,
                  color: '#475569', textTransform: 'uppercase', letterSpacing: '.06em', whiteSpace: 'nowrap' }}>{c.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {MODULE_KEYS.map(mk => {
              const s: ModuleSettings = all[mk] || { ...DEFAULT_MODULE_SETTINGS };
              const isBilling = mk !== 'items';
              return (
                <tr key={mk} style={{ borderTop: '1px solid #0f172a' }}>
                  <td style={{ padding: '11px 16px', fontSize: 13, color: '#e2e8f0', fontWeight: 700 }}>
                    {MODULE_LABELS[mk]}
                    {!isBilling && <span style={{ fontSize: 10, color: '#475569', fontWeight: 500, marginLeft: 8 }}>(Inventory)</span>}
                  </td>
                  {cols.map(c => {
                    const excluded = c.exclude?.includes(mk);
                    return (
                      <td key={c.key} style={{ padding: '11px 14px', textAlign: 'center' }}>
                        {excluded
                          ? <span style={{ color: '#1e293b', fontSize: 12 }}>—</span>
                          : (
                            <label style={{ cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                              <input type="checkbox" checked={!!s[c.key]}
                                onChange={() => toggle(mk, c.key)}
                                style={{ cursor: 'pointer', width: 15, height: 15, accentColor: '#6366f1' }} />
                            </label>
                          )
                        }
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div style={{ marginTop: 16, fontSize: 11, color: '#475569' }}>
        <strong style={{ color: '#64748b' }}>Item Discount</strong> — per-line discount column in billing forms. &nbsp;|&nbsp;
        <strong style={{ color: '#64748b' }}>Bill Discount</strong> — overall discount applied to the entire bill total. &nbsp;|&nbsp;
        <strong style={{ color: '#64748b' }}>Units &amp; Conversion</strong> — dual-unit selection on each billing line.
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   MODULE MANAGEMENT — show/hide every nav module for the current firm
   Each toggle calls PUT /settings/:firmId/visibility and is reflected
   immediately in the sidebar (via the visibility state in WayBook).
═══════════════════════════════════════════════════════════════════════════ */
function ModuleManagementPage({ firmId, toast, visibility, onVisibilityChange }: any) {
  const [saving, setSaving] = useState<string | null>(null);
  const vis: VisibilityMap = visibility || DEFAULT_VISIBILITY;

  const toggleOne = async (key: VisibilityKey) => {
    const newVal = !vis[key];
    setSaving(key);
    const r = await apiFetch(`/settings/${firmId}/visibility/${key}`, {
      method: 'PUT', body: { visible: newVal },
    });
    setSaving(null);
    if (r.error) { toast?.error(r.error); return; }
    onVisibilityChange?.(r.data);
    toast?.success(`${VISIBILITY_LABELS[key]} ${newVal ? 'enabled' : 'disabled'}`);
  };

  const toggleGroup = async (keys: VisibilityKey[], enable: boolean) => {
    const updates: any = {};
    for (const k of keys) updates[k] = enable;
    setSaving('__group__');
    const r = await apiFetch(`/settings/${firmId}/visibility`, {
      method: 'PUT', body: updates,
    });
    setSaving(null);
    if (r.error) { toast?.error(r.error); return; }
    onVisibilityChange?.(r.data);
    toast?.success(`${enable ? 'Enabled' : 'Disabled'} ${keys.length} modules`);
  };

  const enableAll = async () => {
    const all: any = {};
    for (const k of ALL_VISIBILITY_KEYS) all[k] = true;
    setSaving('__all__');
    const r = await apiFetch(`/settings/${firmId}/visibility`, { method: 'PUT', body: all });
    setSaving(null);
    if (r.error) { toast?.error(r.error); return; }
    onVisibilityChange?.(r.data);
    toast?.success('All modules enabled');
  };

  const totalEnabled = ALL_VISIBILITY_KEYS.filter(k => vis[k] !== false).length;

  return (
    <div style={{ flex: 1, padding: 22, overflowY: 'auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 800, color: '#f8fafc', display: 'flex', alignItems: 'center', gap: 8 }}>
            <Sliders size={17} color="#6366f1" /> Module Management
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 4 }}>
            Show or hide any module from the sidebar. Disabled modules are fully hidden — their data is never deleted.
            Currently <strong style={{ color: '#a5b4fc' }}>{totalEnabled} of {ALL_VISIBILITY_KEYS.length}</strong> modules enabled.
          </div>
        </div>
        <button onClick={enableAll} disabled={saving !== null}
          style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px',
            background: '#1e293b', border: '1px solid #334155', borderRadius: 8,
            color: '#94a3b8', fontSize: 12, fontWeight: 700, cursor: 'pointer', flexShrink: 0 }}>
          <RefreshCw size={12} /> Enable All
        </button>
      </div>

      {/* Group cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {VISIBILITY_GROUPS.map(group => {
          const groupEnabled = group.keys.filter(k => vis[k] !== false).length;
          const allOn  = groupEnabled === group.keys.length;
          const allOff = groupEnabled === 0;
          return (
            <div key={group.label} style={{ background: '#1e293b', borderRadius: 14,
              border: '1px solid #334155', overflow: 'hidden' }}>
              {/* Group header */}
              <div style={{ padding: '12px 18px', borderBottom: '1px solid #0f172a',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ width: 10, height: 10, borderRadius: 3,
                    background: group.color, display: 'inline-block', flexShrink: 0 }} />
                  <span style={{ fontSize: 13, fontWeight: 800, color: '#e2e8f0' }}>{group.label}</span>
                  <span style={{ fontSize: 11, color: '#475569', fontWeight: 500 }}>
                    {groupEnabled}/{group.keys.length} enabled
                  </span>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  {!allOn && (
                    <button onClick={() => toggleGroup(group.keys, true)} disabled={saving !== null}
                      style={{ fontSize: 11, padding: '4px 10px', background: 'rgba(99,102,241,.15)',
                        border: '1px solid #4338ca', borderRadius: 6, color: '#a5b4fc',
                        cursor: 'pointer', fontWeight: 700 }}>
                      Enable All
                    </button>
                  )}
                  {!allOff && (
                    <button onClick={() => toggleGroup(group.keys, false)} disabled={saving !== null}
                      style={{ fontSize: 11, padding: '4px 10px', background: 'rgba(239,68,68,.1)',
                        border: '1px solid #7f1d1d', borderRadius: 6, color: '#f87171',
                        cursor: 'pointer', fontWeight: 700 }}>
                      Disable All
                    </button>
                  )}
                </div>
              </div>
              {/* Module rows */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))' }}>
                {group.keys.map((key, i) => {
                  const enabled = vis[key] !== false;
                  const isSaving = saving === key || saving === '__group__' || saving === '__all__';
                  return (
                    <div key={key}
                      style={{ padding: '13px 18px', display: 'flex', alignItems: 'center',
                        justifyContent: 'space-between', gap: 12,
                        borderTop: i === 0 ? 'none' : undefined,
                        borderRight: '1px solid #0f172a',
                        borderBottom: '1px solid #0f172a',
                        opacity: isSaving ? 0.6 : 1, transition: 'opacity .15s' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        {enabled
                          ? <Eye size={13} color="#22c55e" />
                          : <EyeOff size={13} color="#475569" />}
                        <span style={{ fontSize: 13, color: enabled ? '#e2e8f0' : '#475569',
                          fontWeight: enabled ? 600 : 400 }}>
                          {VISIBILITY_LABELS[key]}
                        </span>
                      </div>
                      {/* Toggle switch */}
                      <button
                        onClick={() => toggleOne(key)}
                        disabled={isSaving}
                        title={enabled ? 'Click to disable' : 'Click to enable'}
                        style={{
                          width: 42, height: 22, borderRadius: 11, border: 'none',
                          background: enabled ? '#6366f1' : '#1e293b',
                          boxShadow: enabled ? '0 0 0 1px #4338ca' : '0 0 0 1px #334155',
                          cursor: isSaving ? 'not-allowed' : 'pointer',
                          position: 'relative', transition: 'background .2s', flexShrink: 0,
                          padding: 0,
                        }}>
                        <span style={{
                          position: 'absolute', top: 3, left: enabled ? 23 : 3,
                          width: 16, height: 16, borderRadius: '50%',
                          background: enabled ? '#fff' : '#475569',
                          transition: 'left .2s, background .2s',
                          display: 'block',
                        }} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: 18, padding: '12px 16px', background: '#0f172a',
        borderRadius: 10, border: '1px solid #1e293b', fontSize: 11, color: '#475569' }}>
        <strong style={{ color: '#64748b' }}>Note:</strong> Hiding a module removes it from the sidebar
        and prevents navigation to it. All data (invoices, stock, HR records) is preserved — re-enable
        the module at any time to access it again. Dashboard and Settings are always visible.
      </div>
    </div>
  );
}

function SettingsPage({ firmId, toast, visibility, onVisibilityChange }: any) {
  const [tab, setTab] = useState<'general' | 'series' | 'feature_modules' | 'module_mgmt'>('general');
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ padding: '14px 22px', display: 'flex', gap: 8, borderBottom: '1px solid #1e293b', flexShrink: 0, flexWrap: 'wrap' }}>
        {([
          ['general',        'General'],
          ['series',         'Multiple Series'],
          ['feature_modules','Feature Toggles'],
          ['module_mgmt',    'Module Management'],
        ] as [string, string][]).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k as any)}
            style={{ background: tab === k ? '#1e293b' : 'none', border: tab === k ? '1px solid #334155' : '1px solid transparent',
              color: tab === k ? '#f8fafc' : '#64748b',
              padding: '7px 14px', borderRadius: 8, fontSize: 13, fontWeight: 700, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 6 }}>
            {k === 'module_mgmt' && <Sliders size={12} />}
            {l}
            {k === 'module_mgmt' && (
              <span style={{ fontSize: 10, background: '#6366f1', color: '#fff',
                borderRadius: 4, padding: '1px 5px', fontWeight: 800 }}>NEW</span>
            )}
          </button>
        ))}
      </div>
      {tab === 'general' && (
        <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>🔧</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#94a3b8', marginBottom: 6 }}>General Settings</div>
          <div style={{ fontSize: 13 }}>Firm profile is managed from the setup screen. Backend API ready — additional general settings UI coming soon.</div>
        </div>
      )}
      {tab === 'series'         && <SeriesManagement firmId={firmId} toast={toast} />}
      {tab === 'feature_modules'&& <ModuleSettingsPage firmId={firmId} toast={toast} />}
      {tab === 'module_mgmt'    && (
        <ModuleManagementPage
          firmId={firmId} toast={toast}
          visibility={visibility}
          onVisibilityChange={onVisibilityChange}
        />
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   FIRM SETUP (first-run)
═══════════════════════════════════════════════════════════════════════════ */
function FirmSetup({ onDone, toast }: any) {
  const [form, setForm] = useState<Record<string, string>>({ currency: 'INR', invoicePrefix: 'INV', financialYear: '2024-25' });
  const [saving, setSaving] = useState(false);
  const f = (k: string) => (e: any) => setForm(p => ({ ...p, [k]: e.target.value }));

  const create = async () => {
    if (!form.name) { toast.error('Business name is required'); return; }
    const gErr = gstinError((form as any).gstin || '');
    if (gErr) { toast.error(gErr); return; }
    const mErr = mobileError((form as any).phone || '');
    if (mErr) { toast.error(mErr); return; }
    setSaving(true);
    const r = await apiFetch('/firms', { method: 'POST', body: form });
    setSaving(false);
    if (r.error) { toast.error(r.error); return; }
    toast.success('Welcome to WayBook!');
    onDone(r.data);
  };

  const STATES = ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat',
    'Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra',
    'Rajasthan','Tamil Nadu','Telangana','Uttar Pradesh','West Bengal','Delhi'];

  return (
    <div style={{ minHeight: '100vh', background: '#0a0f1e', display: 'flex',
      alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <div style={{ background: '#1e293b', borderRadius: 20, padding: 40, width: '100%',
        maxWidth: 560, border: '1px solid #334155' }}>
        <div style={{ textAlign: 'center', marginBottom: 30 }}>
          <div style={{ width: 54, height: 54, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
            borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 14px' }}>
            <BookOpen size={26} color="#fff" />
          </div>
          <h1 style={{ fontSize: 26, fontWeight: 900, color: '#f8fafc', margin: '0 0 6px' }}>WayBook</h1>
          <p style={{ color: '#64748b', margin: 0, fontSize: 14 }}>Complete GST Billing & Accounting Software</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Business Name" required>
              <Inp value={(form as any).name || ''} onChange={f('name')} placeholder="Acme Trading Co." />
            </Field>
          </div>
          <Field label="GSTIN"><Inp value={(form as any).gstin || ''} onChange={f('gstin')} placeholder="22AAAAA0000A1Z5" /></Field>
          <Field label="Phone"><Inp value={(form as any).phone || ''} onChange={f('phone')} placeholder="+91 98765 43210" /></Field>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Email"><Inp value={(form as any).email || ''} onChange={f('email')} placeholder="you@business.com" /></Field>
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <Field label="Address"><Inp value={(form as any).address || ''} onChange={f('address')} /></Field>
          </div>
          <Field label="City"><Inp value={(form as any).city || ''} onChange={f('city')} /></Field>
          <Field label="State"><Sel value={(form as any).state || ''} onChange={f('state')}>
            <option value="">Select state</option>
            {STATES.map(s => <option key={s} value={s}>{s}</option>)}
          </Sel></Field>
          <Field label="Invoice Prefix"><Inp value={form.invoicePrefix} onChange={f('invoicePrefix')} /></Field>
          <Field label="Financial Year"><Sel value={form.financialYear} onChange={f('financialYear')}>
            <option value="2023-24">2023-24</option>
            <option value="2024-25">2024-25</option>
            <option value="2025-26">2025-26</option>
          </Sel></Field>
        </div>

        <Btn onClick={create} disabled={saving} size="lg"
          style={{ width: '100%', justifyContent: 'center', marginTop: 22 }}>
          {saving ? 'Setting up…' : '🚀  Create Firm & Get Started'}
        </Btn>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   MAIN APP
═══════════════════════════════════════════════════════════════════════════ */
const TITLES: Record<string, string> = {
  dashboard:'Dashboard', ledger:'Ledger', parties:'Parties', items:'Items', expenses:'Expenses',
  accounting_entries:'Accounting Entries',
  bank:'Banking', godowns:'Godowns/Warehouses', settings:'Settings',
  sale_invoice:'Sales Invoice', sale_order:'Sale Order', sale_return:'Sale Return',
  sale_quotation:'Quotation', delivery_challan:'Delivery Challan',
  purchase_invoice:'Purchase Bill', purchase_order:'Purchase Order', purchase_return:'Purchase Return',
  payment_in:'Payment In', payment_out:'Payment Out',
  employees:'Employees', attendance:'Attendance', payroll:'Payroll',
  report_pl:'Profit & Loss', report_stock:'Stock Summary',
  report_gst:'GST', report_outstanding:'Outstanding', report_daybook:'Day Book',
};
const DOC_TYPES = ['sale_invoice','sale_order','sale_return','sale_quotation','delivery_challan',
  'purchase_invoice','purchase_order','purchase_return'];
const HR_VIEWS  = ['employees','attendance','payroll'];
const RPT_VIEWS = ['report_pl','report_stock','report_gst','report_outstanding','report_daybook'];

export default function WayBook() {
  const [firms,   setFirms]   = useState<any[]>([]);
  const [firmId,  setFirmId]  = useState<string>('');
  const [firm,    setFirm]    = useState<any>(null);
  const [active,  setActive]  = useState('dashboard');
  const [collapsed, setCollapsed] = useState(false);
  const [ready,   setReady]   = useState(false);
  const { toasts, removeToast, toast } = useToast();

  // Load visibility settings — drives sidebar filtering
  const { visibility, setVisibility, reload: reloadVisibility } = useVisibility(firmId);

  // When firmId changes reload visibility
  useEffect(() => { if (firmId) reloadVisibility(); }, [firmId]); // eslint-disable-line

  const handleVisibilityChange = (newVis: VisibilityMap) => {
    setVisibility({ ...DEFAULT_VISIBILITY, ...newVis });
  };

  useEffect(() => {
    apiFetch('/firms').then(r => {
      const list = r.data || [];
      setFirms(list);
      if (list.length) { setFirmId(list[0].id); setFirm(list[0]); }
      setReady(true);
    });
  }, []);

  useEffect(() => {
    if (firmId && firms.length) setFirm(firms.find(f => f.id === firmId) || firms[0]);
  }, [firmId, firms]);

  if (!ready) return (
    <div style={{ minHeight: '100vh', background: '#0a0f1e', display: 'flex',
      alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center', color: '#64748b' }}>
        <div style={{ width: 46, height: 46, background: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
          borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
          <BookOpen size={22} color="#fff" />
        </div>
        <div style={{ fontWeight: 700 }}>Starting WayBook…</div>
      </div>
    </div>
  );

  if (firms.length === 0) return (
    <>
      <FirmSetup toast={toast} onDone={(newFirm: any) => {
        setFirms([newFirm]); setFirmId(newFirm.id); setFirm(newFirm); setActive('dashboard');
      }} />
      <Toasts toasts={toasts} remove={removeToast} />
    </>
  );

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#0a0f1e',
      fontFamily: "'Inter', system-ui, sans-serif", overflow: 'hidden' }}>
      <Sidebar active={active} setActive={setActive} firm={firm} collapsed={collapsed} visibility={visibility} />

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Header */}
        <div style={{ height: 56, background: '#0a0f1e', borderBottom: '1px solid #1e293b',
          display: 'flex', alignItems: 'center', padding: '0 22px', gap: 14, flexShrink: 0 }}>
          <button onClick={() => setCollapsed(p => !p)}
            style={{ background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', lineHeight: 0 }}>
            <Menu size={18} />
          </button>
          <h1 style={{ margin: 0, fontSize: 17, fontWeight: 900, color: '#f8fafc', flex: 1 }}>
            {TITLES[active] || active}
          </h1>
          {firms.length > 1 && (
            <select value={firmId} onChange={e => setFirmId(e.target.value)}
              style={{ ...IS, width: 180, fontSize: 12, padding: '6px 10px' }}>
              {firms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
          )}
          <div style={{ fontSize: 12, color: '#334155', fontWeight: 600 }}>
            {new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })}
          </div>
        </div>

        {/* Content */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minHeight: 0 }}>
          {active === 'dashboard' && <Dashboard firmId={firmId} onNavigate={setActive} />}
          {active === 'items'     && <Items firmId={firmId} toast={toast} />}
          {active === 'parties'   && <Parties firmId={firmId} toast={toast} />}
          {active === 'ledger'    && <Ledger firmId={firmId} onNavigate={setActive} />}
          {active === 'accounting_entries' && <AccountingEntries firmId={firmId} />}
          {(active === 'payment_in' || active === 'payment_out') && <PaymentsPage firmId={firmId} type={active} toast={toast} />}
          {DOC_TYPES.includes(active) && <Documents firmId={firmId} docType={active} toast={toast} />}
          {HR_VIEWS.includes(active)  && <HR firmId={firmId} subView={active} toast={toast} />}
          {RPT_VIEWS.includes(active) && <Reports firmId={firmId} subView={active} />}
          {active === 'settings' && <SettingsPage firmId={firmId} toast={toast} visibility={visibility} onVisibilityChange={handleVisibilityChange} />}
          {['bank','godowns','expenses'].includes(active) && (
            <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>🔧</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: '#94a3b8', marginBottom: 6 }}>{TITLES[active]}</div>
              <div style={{ fontSize: 13 }}>Backend API ready — frontend module coming soon.</div>
            </div>
          )}
        </div>
      </div>

      <Toasts toasts={toasts} remove={removeToast} />
    </div>
  );
}

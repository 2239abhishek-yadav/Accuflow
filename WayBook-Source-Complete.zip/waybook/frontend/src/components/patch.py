import re

with open('WayBook.tsx', 'r') as f:
    content = f.read()

old = '''async function apiFetch(path: string, opts: RequestInit & { body?: any } = {}) {
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      ...opts,
      headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
    });
    return await res.json();
  } catch (e: any) {
    return { error: e.message };
  }
}'''

new = '''interface ApiFetchOpts { method?: string; body?: unknown; headers?: Record<string, string>; }
async function apiFetch(path: string, opts: ApiFetchOpts = {}) {
  try {
    const init: RequestInit = {
      method: opts.method || \'GET\',
      headers: { \'Content-Type\': \'application/json\', ...(opts.headers || {}) },
      ...(opts.body !== undefined ? { body: JSON.stringify(opts.body) } : {}),
    };
    const res = await fetch(`${API_BASE}${path}`, init);
    return await res.json();
  } catch (e: any) {
    return { error: e.message };
  }
}'''

if old in content:
    content = content.replace(old, new, 1)
    print("Replaced apiFetch")
else:
    print("NOT FOUND")

with open('WayBook.tsx', 'w') as f:
    f.write(content)

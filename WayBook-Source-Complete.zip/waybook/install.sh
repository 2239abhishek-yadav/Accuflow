#!/bin/bash
set -e
echo "🔧 Installing WayBook dependencies..."
npm install
echo "📦 Installing backend..."
cd backend && npm install && npm run build && cd ..
echo "🎨 Installing frontend..."
cd frontend && npm install && cd ..
echo ""
echo "✅ Installation complete!"
echo ""
echo "To start in development mode:"
echo "  npm run dev"
echo ""
echo "To start backend only:"
echo "  cd backend && npm start"
echo ""
echo "To start frontend only (web):"
echo "  cd frontend && npm run dev"
echo "  Then open http://localhost:3000"
